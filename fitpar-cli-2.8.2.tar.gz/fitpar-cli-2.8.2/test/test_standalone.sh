#!/bin/sh
# ============================================================================
#  Tests of the standalone program bin/fitpar (needs only sh and awk).
#      sh test/test_standalone.sh [path/to/fitpar]
#  Every case runs in a scratch folder; exit status 0 when all pass.
# ============================================================================
FITPAR=${1:-bin/fitpar}
case "$FITPAR" in /*) ;; *) FITPAR="$(pwd)/$FITPAR" ;; esac
if [ ! -x "$FITPAR" ]; then
    echo "test_standalone: $FITPAR not found"; exit 1
fi
command -v awk > /dev/null 2>&1 || { echo "test_standalone: awk not found, skipped"; exit 0; }

T=$(mktemp -d 2>/dev/null || echo /tmp/fitpar_test_$$)
mkdir -p "$T"
NPASS=0; NFAIL=0
pass() { NPASS=$((NPASS + 1)); echo "  ok    $1"; }
fail() { NFAIL=$((NFAIL + 1)); echo "  FAIL  $1"; [ -f out.txt ] && sed 's/^/        | /' out.txt | tail -15; }

# value of parameter $1 in fitpar_best.txt
best() { awk -v n="$1" '$1 == n { print $2 }' fitpar_best.txt; }
# |a - b| <= tol ?
near() { awk -v a="$1" -v b="$2" -v t="$3" 'BEGIN { d = a - b; if (d < 0) d = -d; exit !(d <= t) }'; }

newcase() { rm -rf "$T/case"; mkdir -p "$T/case"; cd "$T/case" || exit 1; }

echo "standalone program: $FITPAR"

# 1 ---- built-in function, local method --------------------------------------
newcase
cat > fit.inp << 'EOF'
function = rosenbrock
method   = nelder-mead
parameters
  x1  -1.2  -5  5
  x2   1.0  -5  5
end
EOF
if "$FITPAR" fit.inp > out.txt 2>&1 && near "$(best x1)" 1 1e-4 && near "$(best x2)" 1 1e-4; then
    pass "built-in Rosenbrock, Nelder-Mead"; else fail "built-in Rosenbrock, Nelder-Mead"; fi

# 2 ---- external objective (awk), unbounded and one-sided parameters ----------
newcase
cat > fit.inp << 'EOF'
command = awk 'BEGIN {OFMT = "%.17g"} {v[$1] = $2} END {print (v["a"] - 3)^2 + (v["b"] + 1)^2 + (v["c"] - 2)^2}' params.txt > result.txt
method  = nelder-mead
parameters
  a  0                 # no bounds
  b  0   -10   inf     # lower bound only
  c  5   -inf  10      # upper bound only
end
EOF
if "$FITPAR" fit.inp > out.txt 2>&1 && near "$(best a)" 3 1e-3 && near "$(best b)" -1 1e-3 \
   && near "$(best c)" 2 1e-3; then
    pass "external objective, infinite bounds"; else fail "external objective, infinite bounds"; fi

# 3 ---- default method with infinite bounds is local; global refuses -----------
"$FITPAR" fit.inp method=foctopus > out.txt 2>&1
if [ $? -eq 1 ] && grep -q "needs finite lower and upper bounds" out.txt; then
    pass "global method rejects infinite bounds"; else fail "global method rejects infinite bounds"; fi

# 4 ---- model mode, inline data, log and fixed parameters ----------------------
newcase
cat > fit.inp << 'EOF'
# y = A exp(-k x) + c, written by awk for x = 0..9
command = awk 'BEGIN {OFMT = "%.17g"} {v[$1] = $2} END {for (x = 0; x < 10; x++) print v["A"] * exp(-v["k"] * x) + v["c"]}' params.txt > result.txt
mode    = model
parameters
  A   1     0.1   100   log
  k   0.1   0     5
  c   0.5   fixed
end
data
# y = 3 exp(-0.4 x) + 0.5, to 10 decimals
3.5000000000
2.5109601381
1.8479868924
1.4035826357
1.1056895540
0.9060058497
0.7721538599
0.6824301879
0.6222866119
0.5819711673
end
EOF
if "$FITPAR" fit.inp > out.txt 2>&1 && near "$(best A)" 3 1e-6 && near "$(best k)" 0.4 1e-6 \
   && near "$(best c)" 0.5 0 && grep -q "fixed" out.txt; then
    pass "model mode, inline data, log + fixed"; else fail "model mode, inline data, log + fixed"; fi

# 5 ---- residuals mode with params_format = values, data columns ---------------
newcase
printf '%s\n' "# x y sigma" "1 2.1 0.1" "2 3.9 0.1" "3 6.2 0.1" "4 7.8 0.1" "5 10.1 0.1" > line.dat
cat > fit.inp << 'EOF'
# straight line: residuals (a + b x - y) / sigma computed by awk
command = awk 'BEGIN {OFMT = "%.17g"} NR == FNR {p[FNR] = $1; next} /^#/ {next} {print (p[1] + p[2] * $1 - $2) / $3}' params.txt line.dat > result.txt
mode          = residuals
params_format = values
parameters
  a  0  -10  10
  b  1  -10  10
end
EOF
# least squares by hand: b = 1.99, a = 0.05
if "$FITPAR" fit.inp > out.txt 2>&1 && near "$(best a)" 0.05 1e-7 && near "$(best b)" 1.99 1e-7 \
   && grep -q "+/- 1 sigma" out.txt; then
    pass "residuals mode, values format, error bars"; else fail "residuals mode, values format, error bars"; fi

# 6 ---- data file with columns, template with an END line ---------------------
newcase
printf '%s\n' "# t  y  sigma" "0 1.0 0.01" "1 3.0 0.01" "2 5.0 0.01" > d.dat
cat > sim.tpl << 'EOF'
SLOPE {m}
OFFSET {q}
END
EOF
cat > fit.inp << 'EOF'
command       = awk 'BEGIN {OFMT = "%.17g"} $1 == "SLOPE" {m = $2} $1 == "OFFSET" {q = $2} END {for (t = 0; t < 3; t++) print q + m * t}' sim.inp > result.txt
mode          = model
params_file   = sim.inp
template_file = sim.tpl
data_file     = d.dat
y_column      = 2
sigma_column  = 3
parameters
  m  1  -5  5
  q  0  -5  5
end
EOF
if "$FITPAR" fit.inp > out.txt 2>&1 && near "$(best m)" 2 1e-6 && near "$(best q)" 1 1e-6 \
   && grep -q "^END" sim.inp; then
    pass "template file, data columns"; else fail "template file, data columns"; fi

# 7 ---- inline template block ending with "end template" -----------------------
sed -e 's/^template_file.*$//' fit.inp > fit2.inp
cat >> fit2.inp << 'EOF'
template
SLOPE {m}
OFFSET {q}
END
end template
EOF
if "$FITPAR" fit2.inp > out.txt 2>&1 && near "$(best m)" 2 1e-6 && grep -q "^END" sim.inp; then
    pass "inline template block"; else fail "inline template block"; fi

# 8 ---- parallel evaluations in work folders, copy_files -----------------------
newcase
cat > obj.awk << 'EOF'
BEGIN {OFMT = "%.17g"} {v[$1] = $2} END {print (v["a"] - 1)^2 + (v["b"] - 2)^2 + 10 * (1 - cos(6.2831853 * (v["a"] - 1)))}
EOF
cat > fit.inp << 'EOF'
command        = awk -f obj.awk params.txt > result.txt
copy_files     = obj.awk
method         = de
max_feval      = 1500
seed           = 3
parallel       = true
max_concurrent = 3
parameters
  a  0  -5  5
  b  0  -5  5
end
EOF
# (a fitpar built without OpenMP says so and uses slot00 only)
if "$FITPAR" fit.inp > out.txt 2>&1 && near "$(best a)" 1 1e-3 && near "$(best b)" 2 1e-3 \
   && [ -f fitpar_work/slot00/obj.awk ] \
   && { grep -q "without OpenMP" out.txt || [ -f fitpar_work/slot02/params.txt ]; }; then
    pass "parallel work folders, copy_files"; else fail "parallel work folders, copy_files"; fi
cp fitpar_best.txt best_parallel.txt
"$FITPAR" fit.inp parallel=false > out.txt 2>&1
if cmp -s fitpar_best.txt best_parallel.txt; then
    pass "parallel and serial runs agree"; else fail "parallel and serial runs agree"; fi

# 9 ---- {home}: run a script that stays in this folder -------------------------
sed -e 's/^copy_files.*$//' -e 's|awk -f obj.awk|awk -f {home}/obj.awk|' fit.inp > fit3.inp
if "$FITPAR" fit3.inp > out.txt 2>&1 && near "$(best a)" 1 1e-3 && ! grep -q "failed:" out.txt; then
    pass "{home} placeholder"; else fail "{home} placeholder"; fi

# 10 ---- failures: during the run (counted), at the start (stop) ---------------
newcase
cat > fit.inp << 'EOF'
# fails (prints nan) whenever x > 2
command = awk 'BEGIN {OFMT = "%.17g"} {x = $2} END {if (x > 2) print "nan"; else print (x - 1)^2}' params.txt > result.txt
method  = nelder-mead
parameters
  x  0  -5  5
end
EOF
if "$FITPAR" fit.inp > out.txt 2>&1 && near "$(best x)" 1 1e-4; then
    pass "failed evaluations are skipped"; else fail "failed evaluations are skipped"; fi
"$FITPAR" fit.inp "command=exit 3" > out.txt 2>&1
if [ $? -eq 1 ] && grep -q "exit status 3" out.txt && grep -q "test evaluation at the start point failed" out.txt; then
    pass "failing command stops at the start"; else fail "failing command stops at the start"; fi
"$FITPAR" fit.inp "command=echo hello > result.txt" > out.txt 2>&1
if [ $? -eq 1 ] && grep -q "no number" out.txt; then
    pass "result without a number"; else fail "result without a number"; fi

# 11 ---- input errors ------------------------------------------------------------
newcase
printf '%s\n' "function = sphere" "parameters" "  x 0 -1 1" > a.inp
"$FITPAR" a.inp > out.txt 2>&1
if [ $? -eq 1 ] && grep -q 'no "end" line' out.txt; then pass "missing end"; else fail "missing end"; fi
printf '%s\n' "function = sphere" "parameters" "  x 5 -1 1" "end" > b.inp
"$FITPAR" b.inp > out.txt 2>&1
if [ $? -eq 1 ] && grep -q "line 3" out.txt; then pass "start outside bounds"; else fail "start outside bounds"; fi
printf '%s\n' "function = sphere" "parameters" "  x 0.5 -1 1" "end" > c.inp
"$FITPAR" c.inp max_fevl=10 > out.txt 2>&1
if [ $? -eq 1 ] && grep -q "unknown option" out.txt && ! grep -q "Backtrace" out.txt; then
    pass "unknown key, clean exit"; else fail "unknown key, clean exit"; fi
"$FITPAR" c.inp max_feval=abc > out.txt 2>&1
if [ $? -eq 1 ]; then pass "bad option value"; else fail "bad option value"; fi
printf '%s\n' "command = true" "mode = model" "parameters" "  x 0.5 -1 1" "end" > d.inp
"$FITPAR" d.inp > out.txt 2>&1
if [ $? -eq 1 ] && grep -q "needs data" out.txt; then pass "model without data"; else fail "model without data"; fi

# 12 ---- quoting, budgets, interrupts, file endings ------------------------------
newcase
printf '%s\n' 'awk '"'"'{v[$1] = $2} END {printf "%.17g", (v["x"] - 2)^2}'"'"' params.txt > result.txt' > run.sh
cat > fit.inp << 'EOF'
# quoted words in the command; result.txt has no newline at the end
command   = 'sh' 'run.sh'
method    = nelder-mead
max_feval = 40
parameters
  x  0  -5  5
end
EOF
"$FITPAR" fit.inp > out.txt 2>&1
n=$(awk -F, 'NR > 1' fitpar_history.csv | wc -l | tr -d ' ')
if near "$(best x)" 2 1e-2 && ! grep -q "failed:" out.txt && [ "$n" -le 41 ]; then
    pass "quoted command, no final newline, max_feval kept"; else fail "quoted command, no final newline, max_feval kept"; fi
"$FITPAR" fit.inp "command=exit 130" > out.txt 2>&1
if [ $? -eq 130 ] && grep -q "interrupted" out.txt; then
    pass "exit status 130 stops fitpar"; else fail "exit status 130 stops fitpar"; fi
printf '%s\n' "function = sphere" "parameters" "  x 0.5 -1 1" "method = de" > k.inp
"$FITPAR" k.inp > out.txt 2>&1
if [ $? -eq 1 ] && grep -q 'is an "end" line missing' out.txt; then
    pass "setting inside a block"; else fail "setting inside a block"; fi
printf '%s\n' "function = sphere" "parameters" "  data 0.5 -1 1" "end" > r.inp
"$FITPAR" r.inp > out.txt 2>&1
if [ $? -eq 1 ] && grep -q "keyword of the input file" out.txt; then
    pass "keyword as a name"; else fail "keyword as a name"; fi

# 13 ---- as many data values as parameters, fewer, and fractions -------------------
newcase
cat > fit.inp << 'EOF'
# two values, two parameters: an exact fit, uncertainties from the sigmas alone
command = awk 'BEGIN {OFMT = "%.17g"} {v[$1] = $2} END {print v["a"]; print v["b"]}' params.txt > result.txt
mode    = model
parameters
  a  0.5  -5  5
  b  0.5  -5  5
end
data
  1.0  0.1
  2.0  0.2
end
EOF
if "$FITPAR" fit.inp > out.txt 2>&1 && near "$(best a)" 1 1e-6 && near "$(best b)" 2 1e-6 \
   && grep -q "dof         : 0" out.txt && grep -q "1.0000E-01" out.txt && grep -q "2.0000E-01" out.txt; then
    pass "dof 0: absolute uncertainties"; else fail "dof 0: absolute uncertainties"; fi
sed -e 's/print v\["a"\]; print v\["b"\]/print v["a"] + v["c"]; print v["b"] + v["c"]/' \
    -e 's/^  b  0.5  -5  5$/  b  0.5  -5  5\
  c  0.1  -5  5/' fit.inp > fit3.inp
"$FITPAR" fit3.inp > out.txt 2>&1
if grep -q "fewer data values" out.txt && grep -q "undetermined" out.txt; then
    pass "more parameters than data"; else fail "more parameters than data"; fi
cat > frac.inp << 'EOF'
# three fractions of one population: they add up to 1
command = awk 'BEGIN {OFMT = "%.17g"} {v[$1] = $2} END {print v["p"]; print v["q"]; print 1 - v["p"] - v["q"]}' params.txt > result.txt
mode    = model
parameters
  p  0.3  0  1
  q  0.3  0  1
end
data
  0.50  0.03
  0.30  0.03
  0.20  0.03
end
EOF
if "$FITPAR" frac.inp > out.txt 2>&1 && grep -q "add up to 1" out.txt && near "$(best p)" 0.5 1e-4; then
    pass "fractions that add up to 1"; else fail "fractions that add up to 1"; fi

# 14 ---- information commands ---------------------------------------------------
if "$FITPAR" --version > out.txt 2>&1 && grep -q "^fitpar [0-9]" out.txt; then pass "--version"; else fail "--version"; fi
if "$FITPAR" --options > out.txt 2>&1 && grep -q "max_feval" out.txt && grep -q "foc_nbipop" out.txt; then
    pass "--options"; else fail "--options"; fi
"$FITPAR" --example > ex.inp 2>&1
if grep -q "^parameters" ex.inp; then pass "--example"; else fail "--example"; fi

cd / && rm -rf "$T"
echo " standalone tests: $((NPASS + NFAIL))   failures: $NFAIL"
[ "$NFAIL" -eq 0 ]
