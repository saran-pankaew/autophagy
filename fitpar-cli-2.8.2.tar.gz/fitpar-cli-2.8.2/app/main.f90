!> fitpar: fit the parameters of any program.  See docs/fitpar-manual.md.
program fitpar_standalone
   use fitpar_app, only: app_main
   implicit none
   call app_main()
end program fitpar_standalone
