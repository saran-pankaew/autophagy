!> FitPar standalone program: fit parameters without writing any Fortran.
!>
!> The objective is computed by an external command (any program or script):
!> for each trial point FitPar writes the parameter values to a file, runs the
!> command, and reads one number (the objective) or a vector (residuals, or
!> model values compared with data) back from a result file.  Built-in test
!> functions allow a first run with no external program at all.
!>
!> Everything is set in one plain-text input file; see the fitpar manual (docs/fitpar-manual.md).
module fitpar_app
   use fitpar
   use fitpar_option_keys
   !$ use omp_lib
   implicit none
   private
   public :: app_cfg, app_main

   integer, parameter :: LNAME = 32, LLINE = 4096
   integer, parameter :: MODE_OBJ = 1, MODE_RES = 2, MODE_MODEL = 3

   type :: app_cfg
      character(len=:), allocatable :: input_file, command, func, mode_name
      character(len=:), allocatable :: params_file, result_file, workdir
      character(len=:), allocatable :: history_file, output_file, best_file
      character(len=:), allocatable :: params_format, number_format, data_file
      character(len=:), allocatable :: template_file, command_output, run_name
      ! parallel runs: files copied into every work folder, and the way back
      character(len=:), allocatable :: copy_files, home_rel
      ! how the local polish after a global search ended ('' = no polish here)
      character(len=:), allocatable :: polish_msg
      integer :: mode = MODE_OBJ
      ! parameters: all of them, and the map from free (optimised) ones
      integer :: np = 0, nfree = 0
      character(len=LNAME), allocatable :: pname(:)
      real(wp), allocatable :: pstart(:), plo(:), phi(:)
      logical, allocatable  :: plog(:), pfix(:)
      integer, allocatable  :: ifree(:)
      ! data for mode = model
      integer :: ndata = 0, m = 0, y_column = 0, sigma_column = 0
      real(wp), allocatable :: y(:), sy(:)
      ! template lines
      integer :: ntpl = 0
      character(len=LLINE), allocatable :: tpl(:)
      ! inline data block, parsed once y_column / sigma_column are known
      character(len=LLINE), allocatable :: dlines(:)
      ! run state
      logical :: ignore_exit = .false., final_run = .true., parallel = .false.
      logical :: windows = .false.
      ! uncertainties: scaled by chi2/dof (default) or from the given sigmas alone
      logical :: abs_sigma = .false.
      integer :: nslots = 1, neval = 0, nfail = 0, hist_unit = -1, nwarn = 0, nfail_fit = 0
      ! progress: a line whenever the best value improves, at most once a second
      logical :: progress = .true., verbose_set = .false., have_hist = .false., feval_set = .false.
      logical :: dr_set = .false.
      ! sigmas given with the data; why the uncertainties became absolute
      logical :: have_sigma = .false.
      integer :: abs_why = 0           ! 0 asked for (or not absolute), 1 dof <= 0, 2 chi2/dof ~ 0
      ! the start point's result, reused when the method evaluates it again
      logical :: have_start = .false.
      real(wp), allocatable :: u_start(:), v_start(:)
      integer :: nreused = 0
      real(wp) :: best = huge(1.0_wp)
      integer(int64) :: clock0 = 0, last_print = -1, clock_rate = 1
   end type app_cfg

contains

   ! ======================================================================
   !  main
   ! ======================================================================
   subroutine app_main()
      type(app_cfg), target, save :: cfg
      type(opt_options) :: o
      type(opt_problem) :: prob
      type(opt_result)  :: res, pres
      type(opt_options) :: po
      real(wp), allocatable :: u0(:), lo(:), hi(:), vals(:), xp(:)
      integer :: nargs, i, nv, st, j, gid, user_max
      character(len=LLINE) :: arg
      character(len=256) :: msg
      logical :: ok, finite_bounds, ptmp
      integer(int64) :: c0, c1, cr
      real(wp) :: tsec

      nargs = command_argument_count()
      if (nargs == 0) then
         call usage(); return
      end if
      call get_command_argument(1, arg)
      select case (trim(arg))
      case ('-h', '--help');     call usage(); return
      case ('--version', '-v');  write (*, '(a)') 'fitpar '//fitpar_version; return
      case ('--options')
         o = opt_options()
         o%verbose = 0                       ! what fitpar uses unless verbose is set
         write (*, '(a)') ' Settings of the methods: key, default, meaning.  Set any of them in the'
         write (*, '(a)') ' input file as  key = value,  or on the command line as  key=value.'
         write (*, '(a)') ' Unless you set them, fitpar chooses method (and so max_feval for a global'
         write (*, '(a)') ' method) and, in fits, local_method = dfogn; see the manual.'
         call list_options(6, o); return
      case ('--example');        call print_example(); return
      end select

      ! ---- read the input file and the command-line overrides -------------
      cfg%input_file = trim(arg)
      call set_defaults(cfg)
      o = opt_options()
      call read_input(cfg, o, ok, msg)
      if (.not. ok) call fail(msg)
      do i = 2, nargs
         call get_command_argument(i, arg)
         call apply_key_value(cfg, o, trim(arg), ok, msg, .true.)
         if (.not. ok) call fail('command line: '//trim(msg))
      end do
      call finish_setup(cfg, o, ok, msg)
      if (.not. ok) call fail(msg)

      ! ---- internal variables: free parameters, log10 where flagged ---------
      allocate (u0(cfg%nfree), lo(cfg%nfree), hi(cfg%nfree))
      do j = 1, cfg%nfree
         i = cfg%ifree(j)
         u0(j) = to_internal(cfg, i, cfg%pstart(i))
         lo(j) = to_internal(cfg, i, cfg%plo(i))
         hi(j) = to_internal(cfg, i, cfg%phi(i))
      end do
      finite_bounds = all(abs(lo) < 0.5_wp * opt_huge) .and. all(abs(hi) < 0.5_wp * opt_huge)
      if (.not. finite_bounds .and. is_global_method(method_id(o%method))) &
         call fail('method "'//trim(o%method)//'" is a global method and needs finite lower and '// &
                   'upper bounds for every free parameter')

      call open_history(cfg)
      call print_setup(cfg, o)
      call system_clock(cfg%clock0, cfg%clock_rate)

      ! ---- one evaluation at the start point, before anything else ----------
      write (*, '(/,a)') ' test evaluation at the start point ...'
      call system_clock(c0, cr)
      ptmp = cfg%progress; cfg%progress = .false.
      call evaluate(cfg, u0, vals, nv, st, .true.)
      cfg%progress = ptmp
      call system_clock(c1)
      tsec = real(c1 - c0, wp) / real(max(cr, 1_int64), wp)
      if (st /= 0) call fail('the test evaluation at the start point failed (details above). '// &
                             'Run the command by hand in this folder to see why.')
      select case (cfg%mode)
      case (MODE_OBJ)
         write (*, '(a,a)') '   objective = ', snum(vals(1))
      case (MODE_RES)
         if (cfg%m == 0) cfg%m = nv
         if (nv /= cfg%m) call fail('the result file holds a different number of residuals than "residuals" says')
         write (*, '(a,i0,a,a)') '   ', nv, ' residuals, chi2 = ', snum(sum(vals(1:nv)**2))
      case (MODE_MODEL)
         cfg%m = cfg%ndata
         if (nv /= cfg%ndata) then
            write (msg, '(a,i0,a,i0,a)') 'the model wrote ', nv, ' values but there are ', cfg%ndata, ' data points'
            call fail(msg)
         end if
         write (*, '(a,i0,a,a)') '   ', nv, ' model values, chi2 = ', snum(sum(((vals(1:nv) - cfg%y) / cfg%sy)**2))
         ! fractions of one population (cells in each fate, ...) add up to 1,
         ! so one of them carries no information of its own
         if (nv >= 2 .and. all(cfg%y >= 0 .and. cfg%y <= 1) .and. abs(sum(cfg%y) - 1) < 0.011_wp &
             .and. abs(sum(vals(1:nv)) - 1) < 1.0e-6_wp) then
            write (*, '(a)') '   note: the data and the model values both add up to 1 (fractions of one'
            write (*, '(a,i0,a)') '   population?): only ', nv - 1, ' of them are independent, and chi2/dof and the'
            write (*, '(a)') '   scaled uncertainties count one value too many.  Leave one out, or set'
            write (*, '(a)') '   uncertainties = absolute (manual, section 5).'
         end if
      end select
      write (*, '(a,a)') '   one evaluation took ', duration(tsec)
      cfg%u_start = u0; cfg%v_start = vals(1:nv); cfg%have_start = .true.
      if (tsec > 0.05_wp) write (*, '(a,i0,a,a)') '   max_feval = ', o%max_feval, &
         ' allows up to ', trim(duration(tsec * o%max_feval / real(merge(cfg%nslots, 1, cfg%parallel), wp)))

      ! ---- the fit ----------------------------------------------------------
      if (cfg%mode == MODE_OBJ) then
         call prob%init(cfg%nfree, fun=cb_fun, lb=lo, ub=hi, ctx=cfg, name=cfg%run_name)
      else
         call prob%init(cfg%nfree, res=cb_res, m=cfg%m, lb=lo, ub=hi, ctx=cfg, name=cfg%run_name)
      end if
      write (*, '(/,a)') ' fitting ...'
      ! no more data than free parameters: chi2/dof is undefined, so the
      ! uncertainties can only come from the given sigmas
      if (cfg%mode /= MODE_OBJ .and. cfg%m - cfg%nfree <= 0 .and. .not. cfg%abs_sigma) then
         cfg%abs_sigma = .true.; cfg%abs_why = 1
      end if
      ! residuals in units of sigma: the steps that measure the slopes for the
      ! uncertainties should move them by about 1
      if (cfg%mode /= MODE_OBJ .and. (cfg%abs_sigma .or. (cfg%mode == MODE_MODEL .and. cfg%have_sigma)) &
          .and. .not. cfg%dr_set) o%dfogn_stats_dr = 1.0_wp
      ! the test at the start point counts against max_feval; when the method
      ! asks for the start point again it is not run again, so the commands
      ! run never exceed max_feval
      user_max = o%max_feval
      o%max_feval = max(1, user_max - 1)
      call optimize(prob, u0, o, res)
      o%max_feval = user_max
      ! a global search keeps restarting until the budget is spent; say so,
      ! rather than how its last restart happened to end
      if (is_global_method(method_id(o%method)) .and. res%nfev >= o%max_feval - 1) &
         write (res%message, '(a,i0,a)') 'global search used its budget (max_feval = ', o%max_feval, ')'

      ! ---- a global search usually ends on its budget, and FitPar then skips
      !      its local polish; a fit needs it for the error bars, so run it here
      if (cfg%mode /= MODE_OBJ .and. o%polish .and. is_global_method(method_id(o%method)) &
          .and. .not. res%has_stats .and. allocated(res%x)) then
         po = o
         po%method = o%local_method
         po%max_feval = o%polish_feval
         if (po%max_feval <= 0) po%max_feval = max(500, o%max_feval / 5)
         if (cfg%progress) write (*, '(a,a,a,i0,a)') ' polishing with ', trim(po%method), &
            ' (at most ', po%max_feval, ' evaluations) ...'
         xp = res%x
         call optimize(prob, xp, po, pres)
         cfg%polish_msg = trim(pres%message)
         ! a polish that ends a hair above the global value (the global search
         ! often converges fully) is still used, for its fit statistics
         if (allocated(pres%x) .and. pres%f <= res%f + 1.0e-9_wp * abs(res%f)) then
            pres%method = trim(res%method)//' + '//trim(pres%method)
            pres%message = res%message
            res = pres
         else
            cfg%polish_msg = cfg%polish_msg//' (no improvement: the global result is kept)'
         end if
      end if
      call system_clock(c1)
      tsec = real(c1 - cfg%clock0, wp) / real(max(cfg%clock_rate, 1_int64), wp)
      gid = cfg%neval
      cfg%nfail_fit = cfg%nfail                 ! the final run below is not part of the fit

      ! ---- run the model once more at the best point, in this folder --------
      if (cfg%final_run .and. allocated(res%x)) then
         cfg%parallel = .false.; cfg%have_start = .false.
         call evaluate(cfg, res%x, vals, nv, st, .false.)
         if (st /= 0) write (*, '(a)') ' note: the final run at the best point failed; the result below is still valid'
      end if
      call report(cfg, res, gid, tsec)
      if (cfg%have_hist) close (cfg%hist_unit)
   end subroutine app_main

   subroutine fail(msg)
      character(len=*), intent(in) :: msg
      write (*, '(/,a,a)') ' fitpar: ', trim(msg)
      stop 1, quiet=.true.   ! a plain exit status 1, without a backtrace
   end subroutine fail

   ! ======================================================================
   !  input
   ! ======================================================================
   subroutine set_defaults(cfg)
      type(app_cfg), intent(inout) :: cfg
      cfg%command = ''; cfg%func = ''; cfg%mode_name = 'objective'
      cfg%params_file = 'params.txt'; cfg%result_file = 'result.txt'
      cfg%workdir = 'fitpar_work'; cfg%history_file = 'fitpar_history.csv'
      cfg%output_file = 'fitpar_result.txt'; cfg%best_file = 'fitpar_best.txt'
      cfg%params_format = 'names'; cfg%number_format = '(es24.16e3)'
      cfg%data_file = ''; cfg%template_file = ''; cfg%command_output = 'show'
      cfg%run_name = ''; cfg%copy_files = ''; cfg%home_rel = '.'; cfg%polish_msg = ''
      cfg%windows = is_windows()
   end subroutine set_defaults

   !> Read key = value lines and the parameters / data / template blocks.
   subroutine read_input(cfg, o, ok, msg)
      type(app_cfg), intent(inout)     :: cfg
      type(opt_options), intent(inout) :: o
      logical, intent(out)             :: ok
      character(len=*), intent(out)    :: msg
      character(len=LLINE) :: line, raw
      character(len=LLINE), allocatable :: datalines(:), tmp(:)
      character(len=LNAME) :: ktok(3)
      integer :: u, ios, sect, lno, nd, nk
      character(len=LNAME) :: first
      ok = .true.; msg = ''
      open (newunit=u, file=cfg%input_file, status='old', action='read', iostat=ios)
      if (ios /= 0) then
         ok = .false.; msg = 'cannot open the input file "'//cfg%input_file//'"'; return
      end if
      allocate (datalines(64), cfg%tpl(64)); nd = 0; cfg%ntpl = 0
      sect = 0; lno = 0
      do
         read (u, '(a)', iostat=ios) raw
         if (ios /= 0) exit
         lno = lno + 1
         if (sect == 3) then                 ! template: verbatim, up to "end template"
            if (is_end_template(raw)) then
               sect = 0; cycle
            end if
            if (cfg%ntpl == size(cfg%tpl)) then
               allocate (tmp(2 * size(cfg%tpl))); tmp(1:cfg%ntpl) = cfg%tpl(1:cfg%ntpl)
               call move_alloc(tmp, cfg%tpl)
            end if
            cfg%ntpl = cfg%ntpl + 1; cfg%tpl(cfg%ntpl) = raw
            cycle
         end if
         line = adjustl(strip_comment(raw))
         if (len_trim(line) == 0) cycle
         first = lower(first_token(line))
         call split(line, ktok, nk)
         if (index(line, '=') == 0 .and. (nk == 1 .or. (nk == 2 .and. trim(first) == 'end'))) then
            select case (trim(first))
            case ('parameters', 'parameter', 'params')
               if (sect /= 0) then
                  ok = .false.; msg = 'line '//itoa(lno)//': "'//trim(first)//'" inside a block: '// &
                                      'is an "end" line missing?'; close (u); return
               end if
               sect = 1; cycle
            case ('data')
               if (sect /= 0) then
                  ok = .false.; msg = 'line '//itoa(lno)//': "data" inside a block: is an "end" line missing?'
                  close (u); return
               end if
               sect = 2; cycle
            case ('template')
               if (sect /= 0) then
                  ok = .false.; msg = 'line '//itoa(lno)//': "template" inside a block: is an "end" line missing?'
                  close (u); return
               end if
               sect = 3; cycle
            case ('end')
               if (sect == 0) then
                  ok = .false.; msg = 'line '//itoa(lno)//': "end" without a parameters or data block'
                  close (u); return
               end if
               sect = 0; cycle
            end select
         end if
         if ((sect == 1 .or. sect == 2) .and. index(line, '=') > 0) then
            ok = .false.
            msg = 'line '//itoa(lno)//': "'//trim(line)//'" inside a '// &
                  trim(merge('parameters', 'data      ', sect == 1))//' block: is an "end" line missing?'
            close (u); return
         end if
         select case (sect)
         case (1)
            call add_parameter(cfg, line, ok, msg)
            if (.not. ok) then
               msg = 'line '//itoa(lno)//': '//trim(msg); close (u); return
            end if
         case (2)
            if (nd == size(datalines)) then
               allocate (tmp(2 * size(datalines))); tmp(1:nd) = datalines(1:nd)
               call move_alloc(tmp, datalines)
            end if
            nd = nd + 1; datalines(nd) = line
         case default
            call apply_key_value(cfg, o, trim(line), ok, msg, .false.)
            if (.not. ok) then
               msg = 'line '//itoa(lno)//': '//trim(msg); close (u); return
            end if
         end select
      end do
      close (u)
      if (sect == 3) then
         ok = .false.; msg = 'the template block has no "end template" line'; return
      else if (sect == 1 .or. sect == 2) then
         ok = .false.; msg = 'a parameters or data block has no "end" line'; return
      end if
      if (nd > 0) cfg%dlines = datalines(1:nd)
   end subroutine read_input

   !> "end template" (any case and spacing, # comment allowed) closes a template
   !> block; a plain "end" does not, since input formats often contain one.
   logical function is_end_template(raw)
      character(len=*), intent(in) :: raw
      character(len=LNAME) :: tok(4)
      integer :: n
      call split(lower(strip_comment(raw)), tok, n)
      is_end_template = .false.
      if (n == 2) is_end_template = (trim(tok(1)) == 'end' .and. trim(tok(2)) == 'template')
      if (n == 1) is_end_template = (trim(tok(1)) == 'endtemplate')
   end function is_end_template

   !> One "key = value" setting: a program key, or any FitPar option.
   subroutine apply_key_value(cfg, o, kv, ok, msg, from_cmdline)
      type(app_cfg), intent(inout)     :: cfg
      type(opt_options), intent(inout) :: o
      character(len=*), intent(in)     :: kv
      logical, intent(out)             :: ok
      character(len=*), intent(out)    :: msg
      logical, intent(in)              :: from_cmdline
      character(len=:), allocatable :: key, val
      integer :: k, ios
      ok = .true.; msg = ''
      k = index(kv, '=')
      if (k == 0) then
         ok = .false.
         if (from_cmdline) then
            msg = 'expected key=value, got "'//kv//'"'
         else
            msg = 'expected "key = value", got "'//kv//'"'
         end if
         return
      end if
      key = lower(trim(adjustl(kv(1:k - 1))))
      val = strip_quotes(trim(adjustl(kv(k + 1:))))
      select case (key)
      case ('command');           cfg%command = val
      case ('function');          cfg%func = lower(val)
      case ('mode');              cfg%mode_name = lower(val)
      case ('params_file');       cfg%params_file = val
      case ('result_file');       cfg%result_file = val
      case ('workdir');           cfg%workdir = val
      case ('history_file');      cfg%history_file = val
      case ('output_file');       cfg%output_file = val
      case ('best_file');         cfg%best_file = val
      case ('params_format');     cfg%params_format = lower(val)
      case ('number_format');     cfg%number_format = val
      case ('data_file');         cfg%data_file = val
      case ('template_file');     cfg%template_file = val
      case ('command_output');    cfg%command_output = lower(val)
      case ('name');              cfg%run_name = val
      case ('copy_files');        cfg%copy_files = val
      case ('residuals');         read (val, *, iostat=ios) cfg%m; if (ios /= 0) ok = .false.
      case ('y_column');          read (val, *, iostat=ios) cfg%y_column; if (ios /= 0) ok = .false.
      case ('sigma_column');      read (val, *, iostat=ios) cfg%sigma_column; if (ios /= 0) ok = .false.
      case ('ignore_exit_status'); call to_logical(val, cfg%ignore_exit, ok)
      case ('final_run');         call to_logical(val, cfg%final_run, ok)
      case ('progress');          call to_logical(val, cfg%progress, ok)
      case ('uncertainties')
         select case (lower(val))
         case ('scaled');   cfg%abs_sigma = .false.
         case ('absolute'); cfg%abs_sigma = .true.
         case default
            ok = .false.; msg = 'uncertainties must be "scaled" or "absolute", not "'//val//'"'; return
         end select
      case default
         if (key == 'verbose') cfg%verbose_set = .true.
         if (key == 'max_feval') cfg%feval_set = .true.
         if (key == 'dfogn_stats_dr') cfg%dr_set = .true.
         call set_option(o, key, val, ok, msg)
         if (.not. ok .and. index(msg, 'unknown option') > 0) &
            msg = trim(msg)//' (fitpar --options lists all of them)'
         return
      end select
      if (.not. ok) msg = 'cannot read "'//val//'" as the value of '//key
   end subroutine apply_key_value

   !> name  start  [lower upper]  [log] [fixed]
   subroutine add_parameter(cfg, line, ok, msg)
      type(app_cfg), intent(inout)  :: cfg
      character(len=*), intent(in)  :: line
      logical, intent(out)          :: ok
      character(len=*), intent(out) :: msg
      character(len=LLINE) :: tok(12)
      integer :: nt, i, nnum
      real(wp) :: v(3), vv
      logical :: islog, isfix
      ok = .true.; msg = ''
      call split(line, tok, nt)
      if (nt < 2) then
         ok = .false.; msg = 'a parameter line needs at least a name and a start value'; return
      end if
      ! names go into templates as {name} and into the history file's header
      if (len_trim(tok(1)) > LNAME .or. verify(trim(tok(1)), &
          'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-') /= 0 .or. &
          index('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', tok(1)(1:1)) == 0) then
         ok = .false.
         msg = 'parameter name "'//trim(tok(1))//'": use a letter, then letters, digits, _ . or -, '// &
               'at most 32 characters'
         return
      end if
      select case (lower(tok(1)))
      case ('end', 'data', 'template', 'parameters', 'parameter', 'params')
         ok = .false.; msg = '"'//trim(tok(1))//'" is a keyword of the input file, not a parameter name'
         return
      end select
      islog = .false.; isfix = .false.; nnum = 0
      do i = 2, nt
         select case (lower(tok(i)))
         case ('log', 'log10');  islog = .true.
         case ('fixed', 'fix');  isfix = .true.
         case default
            call read_bound(tok(i), vv, ok)
            if (.not. ok) then
               msg = 'parameter '//trim(tok(1))//': "'//trim(tok(i))//'" is neither a number nor a flag '// &
                     '(log, fixed)'
               return
            end if
            if (nnum == 3) then
               ok = .false.; msg = 'too many numbers on the parameter line of '//trim(tok(1)); return
            end if
            nnum = nnum + 1
            v(nnum) = vv
            ! "none" leaves a side open: -inf as the lower bound, +inf as the upper
            if (nnum == 2 .and. lower(tok(i)) == 'none') v(nnum) = -opt_huge
         end select
      end do
      if (nnum == 1) then
         v(2) = -opt_huge; v(3) = opt_huge
      else if (nnum /= 3) then
         ok = .false.; msg = 'parameter '//trim(tok(1))//': give start, lower and upper (or start only)'; return
      end if
      if (v(2) > v(3)) then
         ok = .false.; msg = 'parameter '//trim(tok(1))//': lower bound above upper bound'; return
      end if
      if (.not. isfix .and. (v(1) < v(2) .or. v(1) > v(3))) then
         ok = .false.; msg = 'parameter '//trim(tok(1))//': start value outside its bounds'; return
      end if
      if (islog .and. (v(1) <= 0 .or. v(2) <= 0)) then
         ok = .false.; msg = 'parameter '//trim(tok(1))//': a log-scaled parameter needs a positive start '// &
                             'value and a positive lower bound'; return
      end if
      do i = 1, cfg%np
         if (lower(cfg%pname(i)) == lower(tok(1))) then
            ok = .false.; msg = 'parameter '//trim(tok(1))//' is defined twice'; return
         end if
      end do
      call grow_params(cfg)
      cfg%np = cfg%np + 1
      cfg%pname(cfg%np) = tok(1)(1:LNAME); cfg%pstart(cfg%np) = v(1)
      cfg%plo(cfg%np) = v(2); cfg%phi(cfg%np) = v(3)
      cfg%plog(cfg%np) = islog; cfg%pfix(cfg%np) = isfix
   end subroutine add_parameter

   subroutine grow_params(cfg)
      type(app_cfg), intent(inout) :: cfg
      character(len=LNAME), allocatable :: n2(:)
      real(wp), allocatable :: a(:)
      logical, allocatable :: l(:)
      integer :: c
      if (.not. allocated(cfg%pname)) then
         allocate (cfg%pname(16), cfg%pstart(16), cfg%plo(16), cfg%phi(16), cfg%plog(16), cfg%pfix(16))
         return
      end if
      c = size(cfg%pname)
      if (cfg%np < c) return
      allocate (n2(2 * c)); n2(1:c) = cfg%pname; call move_alloc(n2, cfg%pname)
      allocate (a(2 * c)); a(1:c) = cfg%pstart; call move_alloc(a, cfg%pstart)
      allocate (a(2 * c)); a(1:c) = cfg%plo; call move_alloc(a, cfg%plo)
      allocate (a(2 * c)); a(1:c) = cfg%phi; call move_alloc(a, cfg%phi)
      allocate (l(2 * c)); l(1:c) = cfg%plog; call move_alloc(l, cfg%plog)
      allocate (l(2 * c)); l(1:c) = cfg%pfix; call move_alloc(l, cfg%pfix)
   end subroutine grow_params

   subroutine read_bound(tok, v, ok)
      character(len=*), intent(in) :: tok
      real(wp), intent(out) :: v
      logical, intent(out) :: ok
      integer :: ios
      ok = .true.
      select case (lower(tok))
      case ('-inf', '-infinity', '-none'); v = -opt_huge
      case ('inf', '+inf', 'infinity', 'none'); v = opt_huge
      case default
         if (.not. is_number(tok)) then
            ok = .false.; return
         end if
         read (tok, *, iostat=ios) v
         ok = (ios == 0)
      end select
   end subroutine read_bound

   !> Checks that need every key: mode, data, template, slots, method defaults.
   subroutine finish_setup(cfg, o, ok, msg)
      type(app_cfg), intent(inout)     :: cfg
      type(opt_options), intent(inout) :: o
      logical, intent(out)             :: ok
      character(len=*), intent(out)    :: msg
      integer :: j, k
      logical :: omp_on
      character(len=24), parameter :: dflt = 'auto'
      ok = .true.; msg = ''
      select case (cfg%mode_name)
      case ('objective', 'scalar', 'f');    cfg%mode = MODE_OBJ
      case ('residuals', 'residual', 'r');  cfg%mode = MODE_RES
      case ('model', 'data');               cfg%mode = MODE_MODEL
      case default
         ok = .false.; msg = 'mode must be objective, residuals or model'; return
      end select
      if (cfg%np == 0) then
         ok = .false.; msg = 'no parameters: add a "parameters" ... "end" block'; return
      end if
      if (len(cfg%func) > 0 .and. len(cfg%command) > 0) then
         ok = .false.; msg = 'give either "function" (built-in test) or "command", not both'; return
      end if
      if (len(cfg%func) == 0 .and. len(cfg%command) == 0) then
         ok = .false.; msg = 'no objective: set "command = ..." (or "function = ..." for a built-in test)'; return
      end if
      if (len(cfg%func) > 0) then
         if (cfg%mode /= MODE_OBJ) then
            ok = .false.; msg = 'built-in test functions are scalar objectives (mode = objective)'; return
         end if
         if (builtin(cfg%func, [(0.0_wp, k=1, 2)], .true.) < 0) then
            ok = .false.; msg = 'unknown built-in function "'//cfg%func// &
                                '" (sphere, rosenbrock, rastrigin, ackley, styblinski, griewank)'; return
         end if
      end if
      ! free parameters
      cfg%nfree = count(.not. cfg%pfix(1:cfg%np))
      if (cfg%nfree == 0) then
         ok = .false.; msg = 'every parameter is fixed; nothing to fit'; return
      end if
      allocate (cfg%ifree(cfg%nfree)); k = 0
      do j = 1, cfg%np
         if (.not. cfg%pfix(j)) then
            k = k + 1; cfg%ifree(k) = j
         end if
      end do
      if (cfg%y_column < 0 .or. cfg%sigma_column < 0) then
         ok = .false.; msg = 'y_column and sigma_column are column numbers: 1, 2, 3, ...'; return
      end if
      block
         character(len=80) :: b
         integer :: ios
         write (b, cfg%number_format, iostat=ios) 1.0_wp
         if (ios /= 0 .or. index(cfg%number_format, '(') /= 1) then
            ok = .false.
            msg = 'number_format "'//cfg%number_format//'" is not a Fortran format for a real number, '// &
                  'such as (es24.16e3)'
            return
         end if
      end block
      ! data for mode = model
      if (cfg%mode == MODE_MODEL) then
         call load_data(cfg, ok, msg); if (.not. ok) return
      else if (len(cfg%data_file) > 0 .or. allocated(cfg%dlines)) then
         ok = .false.; msg = 'data are only used with mode = model'; return
      end if
      ! template
      if (len(cfg%template_file) > 0) then
         if (cfg%ntpl > 0) then
            ok = .false.; msg = 'give either a template block or template_file, not both'; return
         end if
         call load_template(cfg, ok, msg); if (.not. ok) return
      end if
      if (cfg%ntpl > 0) call check_template(cfg)
      select case (cfg%params_format)
      case ('names', 'values')
      case default
         ok = .false.; msg = 'params_format must be names or values'; return
      end select
      select case (cfg%command_output)
      case ('show', 'hide', 'log')
      case default
         ok = .false.; msg = 'command_output must be show, hide or log'; return
      end select
      if (method_id(o%method) < 0) then
         ok = .false.
         msg = 'unknown method "'//trim(o%method)//'"; methods: foctopus de cmaes pso sa direct mlsl '// &
               'multistart basinhop ga mac dfogn lm nelder-mead bobyqa newuoa powell pattern mads '// &
               'lbfgsb bfgs cg sqp trust-ncg'
         return
      end if
      if (method_id(o%local_method) < 0) then
         ok = .false.; msg = 'unknown local_method "'//trim(o%local_method)//'"'; return
      end if
      ! a method suited to an external, derivative-free objective unless one was set
      if (trim(o%method) == trim(dflt)) then
         if (cfg%mode == MODE_OBJ) then
            if (all(abs(cfg%plo(cfg%ifree)) < 0.5_wp * opt_huge) .and. &
                all(abs(cfg%phi(cfg%ifree)) < 0.5_wp * opt_huge)) then
               o%method = 'foctopus'
            else
               o%method = 'nelder-mead'
            end if
         else
            o%method = 'dfogn'
         end if
         write (*, '(a)') ' method not set: using '//trim(o%method)//' (set "method = ..." to choose)'
      end if
      if (cfg%mode /= MODE_OBJ .and. trim(o%local_method) == 'lbfgsb') o%local_method = 'dfogn'
      if (cfg%mode == MODE_OBJ .and. (method_id(o%method) == method_id('dfogn') .or. &
                                      method_id(o%method) == method_id('lm'))) then
         ok = .false.
         msg = 'method '//trim(o%method)//' fits residuals: use mode = residuals or mode = model, '// &
               'or another method'
         return
      end if
      ! the program prints its own setup, progress and result; the library's
      ! header and summary come back with verbose = 1 or more
      if (.not. cfg%verbose_set) o%verbose = 0
      ! a global search runs until its budget is spent: FitPar's default budget
      ! (200 000) suits functions in code, not programs that take seconds
      if (.not. cfg%feval_set .and. is_global_method(method_id(o%method))) then
         o%max_feval = 1000 * cfg%nfree
         write (*, '(a,i0,a)') ' max_feval not set: using ', o%max_feval, &
            ' for the global search (1000 per free parameter; set "max_feval = ..." to choose)'
      end if
      ! parallel evaluation: one work folder per thread
      cfg%parallel = o%parallel
      cfg%nslots = 1
      omp_on = .false.
      !$ omp_on = .true.
      if (cfg%parallel .and. .not. omp_on) &
         write (*, '(a)') ' note: this fitpar was built without OpenMP, so the evaluations run one at a time'
      if (cfg%parallel) then
         cfg%nslots = o%max_concurrent
         !$ if (cfg%nslots <= 0) cfg%nslots = omp_get_max_threads()
         if (cfg%nslots <= 0 .or. .not. omp_on) cfg%nslots = 1
         if (len(cfg%func) == 0) then
            call relative_home(cfg%workdir, cfg%home_rel, ok)
            if (.not. ok) then
               msg = 'workdir must be a relative path below this folder, without "..": "'//cfg%workdir//'"'
               return
            end if
            if (cfg%windows) cfg%home_rel = winpath(cfg%home_rel)
            call make_slot_dirs(cfg, ok, msg); if (.not. ok) return
         end if
      else if (len(cfg%copy_files) > 0) then
         write (*, '(a)') ' note: copy_files is only used with parallel = true'
      end if
   end subroutine finish_setup

   !> The path back from workdir/slotNN to this folder: "../.." for workdir = fitpar_work.
   subroutine relative_home(workdir, home, ok)
      character(len=*), intent(in) :: workdir
      character(len=:), allocatable, intent(out) :: home
      logical, intent(out) :: ok
      character(len=LLINE) :: w
      character(len=LNAME) :: tok(64)
      integer :: i, n
      ok = .false.; home = '.'
      w = workdir
      if (len_trim(w) == 0) return
      if (w(1:1) == '/' .or. w(1:1) == '\' .or. index(w, ':') > 0) return
      do i = 1, len_trim(w)
         if (w(i:i) == '/' .or. w(i:i) == '\') w(i:i) = ' '
      end do
      call split(w, tok, n)
      home = '..'                                    ! out of slotNN
      do i = 1, n
         if (trim(tok(i)) == '..') return
         if (trim(tok(i)) /= '.') home = home//'/..'
      end do
      ok = .true.
   end subroutine relative_home

   subroutine load_data(cfg, ok, msg)
      type(app_cfg), intent(inout)  :: cfg
      logical, intent(out)          :: ok
      character(len=*), intent(out) :: msg
      character(len=LLINE), allocatable :: lines(:), tmp(:)
      character(len=LLINE) :: line
      character(len=64) :: tok(64)
      integer :: n, u, ios, i, nt, ncol, yc, sc
      real(wp) :: vy, vs
      ok = .true.; msg = ''
      if (len(cfg%data_file) > 0 .and. allocated(cfg%dlines)) then
         ok = .false.; msg = 'give either a data block or data_file, not both'; return
      end if
      if (len(cfg%data_file) > 0) then
         open (newunit=u, file=cfg%data_file, status='old', action='read', iostat=ios)
         if (ios /= 0) then
            ok = .false.; msg = 'cannot open data_file "'//cfg%data_file//'"'; return
         end if
         allocate (lines(256)); n = 0
         do
            read (u, '(a)', iostat=ios) line
            if (ios /= 0) exit
            line = adjustl(strip_comment(line))
            if (len_trim(line) == 0) cycle
            if (n == size(lines)) then
               allocate (tmp(2 * n)); tmp(1:n) = lines(1:n); call move_alloc(tmp, lines)
            end if
            n = n + 1; lines(n) = line
         end do
         close (u)
      else if (allocated(cfg%dlines)) then
         n = size(cfg%dlines); allocate (lines(n)); lines = cfg%dlines
      else
         ok = .false.; msg = 'mode = model needs data: a "data" ... "end" block or data_file'; return
      end if
      if (n == 0) then
         ok = .false.; msg = 'the data contain no rows'; return
      end if
      call split(lines(1), tok, ncol)
      yc = cfg%y_column; sc = cfg%sigma_column
      if (yc == 0) then
         select case (ncol)
         case (1); yc = 1; sc = 0
         case (2); yc = 1; sc = 2
         case default
            ok = .false.; msg = 'the data have more than two columns: set y_column (and sigma_column)'; return
         end select
      end if
      cfg%ndata = n
      cfg%have_sigma = sc > 0
      allocate (cfg%y(n), cfg%sy(n))
      do i = 1, n
         call split(lines(i), tok, nt)
         if (nt < max(yc, sc)) then
            write (msg, '(a,i0,a)') 'data row ', i, ' has too few columns'; ok = .false.; return
         end if
         read (tok(yc), *, iostat=ios) vy
         if (ios /= 0 .or. .not. is_number(tok(yc))) then
            write (msg, '(a,i0)') 'cannot read the y value on data row ', i; ok = .false.; return
         end if
         vs = 1.0_wp
         if (sc > 0) then
            read (tok(sc), *, iostat=ios) vs
            if (ios /= 0 .or. .not. is_number(tok(sc)) .or. vs <= 0) then
               write (msg, '(a,i0)') 'the sigma value must be positive; data row ', i; ok = .false.; return
            end if
         end if
         cfg%y(i) = vy; cfg%sy(i) = vs
      end do
   end subroutine load_data

   subroutine load_template(cfg, ok, msg)
      type(app_cfg), intent(inout)  :: cfg
      logical, intent(out)          :: ok
      character(len=*), intent(out) :: msg
      character(len=LLINE) :: line
      character(len=LLINE), allocatable :: tmp(:)
      integer :: u, ios
      ok = .true.; msg = ''
      open (newunit=u, file=cfg%template_file, status='old', action='read', iostat=ios)
      if (ios /= 0) then
         ok = .false.; msg = 'cannot open template_file "'//cfg%template_file//'"'; return
      end if
      cfg%ntpl = 0
      do
         read (u, '(a)', iostat=ios) line
         if (ios /= 0) exit
         if (cfg%ntpl == size(cfg%tpl)) then
            allocate (tmp(2 * cfg%ntpl)); tmp(1:cfg%ntpl) = cfg%tpl(1:cfg%ntpl); call move_alloc(tmp, cfg%tpl)
         end if
         cfg%ntpl = cfg%ntpl + 1; cfg%tpl(cfg%ntpl) = line
      end do
      close (u)
   end subroutine load_template

   !> One work folder per parallel slot, each with a copy of copy_files.
   !> Warn about {word} in the template that is not a parameter name or {id}:
   !> most likely a misspelt name, which would then never change.
   subroutine check_template(cfg)
      type(app_cfg), intent(in) :: cfg
      integer :: j, a, b, i, nwarn
      character(len=:), allocatable :: w
      logical :: known
      nwarn = 0
      do j = 1, cfg%ntpl
         b = 0
         do
            a = index(cfg%tpl(j)(b + 1:), '{')
            if (a == 0) exit
            a = a + b
            b = index(cfg%tpl(j)(a + 1:), '}')
            if (b == 0) exit
            b = a + b
            w = cfg%tpl(j)(a + 1:b - 1)
            if (len(w) == 0 .or. len(w) > LNAME) cycle
            if (verify(w, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_.-') /= 0) cycle
            known = (lower(w) == 'id')
            do i = 1, cfg%np
               if (lower(w) == lower(cfg%pname(i))) known = .true.
            end do
            if (.not. known .and. nwarn < 5) then
               write (*, '(a,i0,a)') ' note: template line ', j, ': {'//w//'} is not a parameter name; '// &
                  'it is left as it is'
               nwarn = nwarn + 1
            end if
         end do
      end do
   end subroutine check_template

   subroutine make_slot_dirs(cfg, ok, msg)
      type(app_cfg), intent(inout)  :: cfg
      logical, intent(out)          :: ok
      character(len=*), intent(out) :: msg
      integer :: s, es, cs, nf, i
      character(len=:), allocatable :: d
      character(len=LLINE) :: fl(256)
      ok = .true.; msg = ''
      call split(cfg%copy_files, fl, nf)
      do s = 0, cfg%nslots - 1
         d = slot_dir(cfg, s)
         if (cfg%windows) then
            call execute_command_line('if not exist "'//winpath(d)//'" mkdir "'//winpath(d)//'"', &
                                      exitstat=es, cmdstat=cs)
         else
            call execute_command_line('mkdir -p "'//d//'"', exitstat=es, cmdstat=cs)
         end if
         if (cs /= 0 .or. es /= 0) then
            ok = .false.; msg = 'cannot create the work folder "'//d//'"'; return
         end if
         do i = 1, nf
            call copy_file(trim(fl(i)), join_path(d, base_name(trim(fl(i)))), ok)
            if (.not. ok) then
               msg = 'copy_files: cannot copy "'//trim(fl(i))//'" into '//d; return
            end if
         end do
      end do
   end subroutine make_slot_dirs

   !> Byte-for-byte copy of one file.
   subroutine copy_file(src, dst, ok)
      character(len=*), intent(in) :: src, dst
      logical, intent(out) :: ok
      integer :: ui, uo, ios
      integer(int64) :: nbytes
      character(len=:), allocatable :: buf
      ok = .false.
      open (newunit=ui, file=src, status='old', action='read', access='stream', form='unformatted', iostat=ios)
      if (ios /= 0) return
      inquire (unit=ui, size=nbytes)
      if (nbytes < 0) then
         close (ui); return
      end if
      allocate (character(len=nbytes) :: buf)
      if (nbytes > 0) read (ui, iostat=ios) buf
      close (ui)
      if (ios /= 0) return
      open (newunit=uo, file=dst, status='replace', action='write', access='stream', form='unformatted', iostat=ios)
      if (ios /= 0) return
      if (nbytes > 0) write (uo, iostat=ios) buf
      close (uo)
      ok = (ios == 0)
   end subroutine copy_file

   !> The file name without its folder.
   function base_name(path) result(b)
      character(len=*), intent(in) :: path
      character(len=:), allocatable :: b
      integer :: k
      k = max(index(path, '/', back=.true.), index(path, '\', back=.true.))
      b = path(k + 1:)
   end function base_name

   ! ======================================================================
   !  evaluation
   ! ======================================================================
   !> One evaluation of the external command (or the built-in function) at the
   !> internal point u.  st = 0: vals(1:nv) holds the result; st = 1: failed.
   subroutine evaluate(cfg, u, vals, nv, st, verbose_fail)
      type(app_cfg), intent(inout)        :: cfg
      real(wp), intent(in)                :: u(:)
      real(wp), allocatable, intent(out)  :: vals(:)
      integer, intent(out)                :: nv, st
      logical, intent(in)                 :: verbose_fail
      real(wp) :: p(cfg%np)
      integer :: slot, id, es, cs
      character(len=:), allocatable :: dir, pf, rf, cmd, why
      character(len=256) :: cmsg
      st = 0; nv = 0; why = ''
      if (cfg%have_start) then
         if (all(u == cfg%u_start)) then
            vals = cfg%v_start; nv = size(vals)
            !$omp critical (fitpar_app_count)
            cfg%nreused = cfg%nreused + 1
            !$omp end critical (fitpar_app_count)
            return
         end if
      end if
      call to_physical(cfg, u, p)
      slot = 0
      !$ if (cfg%parallel) slot = omp_get_thread_num()
      !$omp critical (fitpar_app_count)
      cfg%neval = cfg%neval + 1; id = cfg%neval
      !$omp end critical (fitpar_app_count)
      if (len(cfg%func) > 0) then
         allocate (vals(1)); vals(1) = builtin(cfg%func, p, .false.); nv = 1
         !$omp critical (fitpar_app_io)
         call log_eval(cfg, id, slot, st, vals, nv, p)
         !$omp end critical (fitpar_app_io)
         return
      end if
      ! Everything that goes through the Fortran I/O library, internal (string)
      ! writes included, runs one thread at a time: not every runtime library is
      ! safe with concurrent internal writes.  The commands themselves run in
      ! parallel, and they take nearly all of the time.
      !$omp critical (fitpar_app_io)
      if (cfg%parallel) then
         dir = slot_dir(cfg, slot)
      else
         dir = '.'
      end if
      pf = join_path(dir, cfg%params_file)
      rf = join_path(dir, cfg%result_file)
      call delete_file(rf)
      call write_params(cfg, pf, p, id)
      cmd = build_command(cfg, dir, id, slot)
      !$omp end critical (fitpar_app_io)
      es = 0; cs = 0; cmsg = ''
      call execute_command_line(cmd, wait=.true., exitstat=es, cmdstat=cs, cmdmsg=cmsg)
      !$omp critical (fitpar_app_io)
      if (es == 130 .and. .not. cfg%windows) then
         if (cfg%have_hist) flush (cfg%hist_unit)
         write (*, '(/,a)') ' fitpar: interrupted (Ctrl-C, or the command returned exit status 130).'
         if (cfg%best < huge(1.0_wp)) write (*, '(a)') ' The best point so far is in '//cfg%best_file//'.'
         stop 130, quiet=.true.
      end if
      if (cs /= 0 .and. es == 127) then
         st = 1; why = 'the command was not found (exit status 127): check the program name and the PATH'
      else if (cs /= 0) then
         st = 1; why = 'the command could not be started ('//trim(cmsg)//')'
      else if (es /= 0 .and. .not. cfg%ignore_exit) then
         st = 1; why = 'the command returned exit status '//itoa(es)
      else
         call read_numbers(rf, vals, nv, why)
         if (nv == 0) then
            st = 1
            if (len(why) == 0) why = 'no number in the result file '//rf
         else if (cfg%mode /= MODE_OBJ .and. cfg%m > 0 .and. nv /= cfg%m) then
            st = 1; why = 'the result file holds '//itoa(nv)//' numbers, '//itoa(cfg%m)//' expected'
         end if
      end if
      if (st /= 0) then
         cfg%nfail = cfg%nfail + 1
         if (verbose_fail .or. cfg%nwarn < 5) then
            cfg%nwarn = cfg%nwarn + 1
            write (*, '(a,i0,a,a)') '   evaluation ', id, ' failed: ', why
            write (*, '(a,a)') '     command: ', cmd
            if (cfg%nwarn == 5 .and. .not. verbose_fail) &
               write (*, '(a)') '     (further failures are counted, not shown; see the history file)'
         end if
      end if
      if (.not. allocated(vals)) allocate (vals(0))
      call log_eval(cfg, id, slot, st, vals, nv, p)
      !$omp end critical (fitpar_app_io)
   end subroutine evaluate

   !> The shell command of one evaluation.  It runs in the evaluation folder:
   !> here, or workdir/slotNN when parallel; {params} and {result} are the file
   !> names in that folder, {home} the way back to this folder.
   function build_command(cfg, dir, id, slot) result(cmd)
      type(app_cfg), intent(in)    :: cfg
      character(len=*), intent(in) :: dir
      integer, intent(in)          :: id, slot
      character(len=:), allocatable :: cmd
      cmd = cfg%command
      cmd = replace_all(cmd, '{params}', cfg%params_file)
      cmd = replace_all(cmd, '{result}', cfg%result_file)
      if (cfg%windows) then
         cmd = replace_all(cmd, '{dir}', trim(winpath(dir)))
      else
         cmd = replace_all(cmd, '{dir}', dir)
      end if
      if (dir /= '.') then
         cmd = replace_all(cmd, '{home}', cfg%home_rel)
      else
         cmd = replace_all(cmd, '{home}', '.')
      end if
      cmd = replace_all(cmd, '{id}', itoa(id))
      cmd = replace_all(cmd, '{slot}', itoa(slot))
      select case (cfg%command_output)
      case ('hide')
         if (cfg%windows) then
            cmd = '( '//cmd//' ) > NUL 2>&1'
         else
            cmd = '( '//cmd//' ) > /dev/null 2>&1'
         end if
      case ('log')
         cmd = '( '//cmd//' ) >> command_output.txt 2>&1'
      end select
      if (dir /= '.') then
         if (cfg%windows) then
            cmd = 'cd /d "'//trim(winpath(dir))//'" && '//cmd
         else
            cmd = 'cd "'//dir//'" && '//cmd
         end if
      end if
      ! Ctrl-C reaches the command, not fitpar (which waits with SIGINT
      ! ignored); the shell turns it into exit status 130, and fitpar stops
      if (.not. cfg%windows) cmd = 'trap ''exit 130'' INT; '//cmd
   end function build_command

   !> Objective callback for FitPar.
   subroutine cb_fun(x, f, ctx, ierr)
      real(wp), intent(in)    :: x(:)
      real(wp), intent(out)   :: f
      class(*), intent(inout) :: ctx
      integer, intent(out)    :: ierr
      real(wp), allocatable :: v(:)
      integer :: nv, st
      ierr = 0; f = opt_huge
      select type (ctx)
      type is (app_cfg)
         call evaluate(ctx, x, v, nv, st, .false.)
         if (st /= 0) then
            ierr = 1
         else
            f = v(1)
         end if
      class default
         ierr = -1
      end select
   end subroutine cb_fun

   !> Residual callback: residuals as written, or (model - y) / sigma.
   subroutine cb_res(x, r, ctx, ierr)
      real(wp), intent(in)    :: x(:)
      real(wp), intent(out)   :: r(:)
      class(*), intent(inout) :: ctx
      integer, intent(out)    :: ierr
      real(wp), allocatable :: v(:)
      integer :: nv, st
      ierr = 0; r = 0.0_wp
      select type (ctx)
      type is (app_cfg)
         call evaluate(ctx, x, v, nv, st, .false.)
         if (st /= 0 .or. nv /= size(r)) then
            ierr = 1; return
         end if
         if (ctx%mode == MODE_MODEL) then
            r = (v(1:nv) - ctx%y) / ctx%sy
         else
            r = v(1:nv)
         end if
      class default
         ierr = -1
      end select
   end subroutine cb_res

   subroutine write_params(cfg, pf, p, id)
      type(app_cfg), intent(in)    :: cfg
      character(len=*), intent(in) :: pf
      real(wp), intent(in)         :: p(:)
      integer, intent(in)          :: id
      integer :: u, i, j
      character(len=:), allocatable :: line
      open (newunit=u, file=pf, status='replace', action='write')
      if (cfg%ntpl > 0) then
         do j = 1, cfg%ntpl
            line = trim(cfg%tpl(j))
            if (index(line, '{') > 0) then
               do i = 1, cfg%np
                  line = replace_ci(line, '{'//trim(cfg%pname(i))//'}', fmtnum(cfg, p(i)))
               end do
               line = replace_ci(line, '{id}', itoa(id))
            end if
            write (u, '(a)') line
         end do
      else if (cfg%params_format == 'values') then
         do i = 1, cfg%np
            write (u, '(a)') fmtnum(cfg, p(i))
         end do
      else
         do i = 1, cfg%np
            write (u, '(a,1x,a)') cfg%pname(i)(1:max(len_trim(cfg%pname(i)), 12)), fmtnum(cfg, p(i))
         end do
      end if
      close (u)
   end subroutine write_params

   !> Every number in a text file, in order; lines starting with # are skipped.
   !> Lines of any length and any number of values per line are accepted.
   subroutine read_numbers(fn, vals, nv, why)
      character(len=*), intent(in)       :: fn
      real(wp), allocatable, intent(out) :: vals(:)
      integer, intent(out)               :: nv
      character(len=:), allocatable, intent(out) :: why
      character(len=:), allocatable :: line
      real(wp), allocatable :: tmp(:)
      real(wp) :: v
      integer :: u, ios, i, i0, n
      nv = 0; why = ''
      allocate (vals(64))
      open (newunit=u, file=fn, status='old', action='read', iostat=ios)
      if (ios /= 0) then
         why = 'the result file '//fn//' was not written'; return
      end if
      do
         call read_line(u, line, ios)
         if (ios /= 0) exit
         n = len_trim(line)
         if (n == 0) cycle
         i = verify(line, ' '//achar(9))
         if (i == 0) cycle                                ! blanks and tabs only
         if (line(i:i) == '#') cycle
         i = 1
         do while (i <= n)
            if (index(' ,;'//achar(9), line(i:i)) > 0) then
               i = i + 1; cycle
            end if
            i0 = i
            do while (i <= n)
               if (index(' ,;'//achar(9), line(i:i)) > 0) exit
               i = i + 1
            end do
            if (.not. is_number(line(i0:i - 1))) then
               if (is_nonfinite_word(line(i0:i - 1))) then
                  why = 'the result file contains "'//line(i0:i - 1)//'"'; nv = 0; close (u); return
               end if
               cycle
            end if
            read (line(i0:i - 1), *, iostat=ios) v
            if (ios /= 0) cycle
            if (v /= v .or. abs(v) > opt_huge) then
               why = 'the result file contains a non-finite value'; nv = 0; close (u); return
            end if
            if (nv == size(vals)) then
               allocate (tmp(2 * nv)); tmp(1:nv) = vals(1:nv); call move_alloc(tmp, vals)
            end if
            nv = nv + 1; vals(nv) = v
         end do
      end do
      close (u)
   end subroutine read_numbers

   !> One line of any length.
   subroutine read_line(u, line, ios)
      integer, intent(in) :: u
      character(len=:), allocatable, intent(out) :: line
      integer, intent(out) :: ios
      character(len=1024) :: buf
      integer :: sz
      line = ''
      do
         read (u, '(a)', advance='no', iostat=ios, size=sz) buf
         line = line//buf(1:sz)
         if (ios /= 0) exit
      end do
      if (is_iostat_eor(ios)) ios = 0
   end subroutine read_line

   ! ======================================================================
   !  built-in test functions (the standard bounded forms)
   ! ======================================================================
   !> Value of a built-in function, or -1 for an unknown name when check = .true.
   real(wp) function builtin(name, x, check) result(f)
      character(len=*), intent(in) :: name
      real(wp), intent(in) :: x(:)
      logical, intent(in) :: check
      real(wp), parameter :: pi = acos(-1.0_wp)
      integer :: n, i
      n = size(x)
      select case (name)
      case ('sphere');      f = sum(x**2)
      case ('rosenbrock');  f = sum(100.0_wp * (x(2:) - x(:n - 1)**2)**2 + (1.0_wp - x(:n - 1))**2)
      case ('rastrigin');   f = 10.0_wp * n + sum(x**2 - 10.0_wp * cos(2.0_wp * pi * x))
      case ('ackley')
         f = -20.0_wp * exp(-0.2_wp * sqrt(sum(x**2) / n)) - exp(sum(cos(2.0_wp * pi * x)) / n) &
             + 20.0_wp + exp(1.0_wp)
      case ('styblinski', 'styblinski-tang')
         f = 0.5_wp * sum(x**4 - 16.0_wp * x**2 + 5.0_wp * x) + 39.16616570377142_wp * n
      case ('griewank')
         f = 1.0_wp + sum(x**2) / 4000.0_wp - product([(cos(x(i) / sqrt(real(i, wp))), i=1, n)])
      case default
         f = -1.0_wp; return
      end select
      if (check) f = 0.0_wp
   end function builtin

   ! ======================================================================
   !  history and report
   ! ======================================================================
   subroutine open_history(cfg)
      type(app_cfg), intent(inout) :: cfg
      integer :: i, ios
      character(len=:), allocatable :: h
      if (len(cfg%history_file) == 0 .or. lower(cfg%history_file) == 'none') return
      open (newunit=cfg%hist_unit, file=cfg%history_file, status='replace', action='write', iostat=ios)
      if (ios /= 0) then
         write (*, '(a)') ' note: cannot write the history file '//cfg%history_file; return
      end if
      cfg%have_hist = .true.
      select case (cfg%mode)
      case (MODE_OBJ); h = 'eval,slot,status,objective'
      case default;    h = 'eval,slot,status,chi2'
      end select
      do i = 1, cfg%np
         h = h//','//trim(cfg%pname(i))
      end do
      write (cfg%hist_unit, '(a)') h
   end subroutine open_history

   !> One line in the history file, and a progress line when the best value
   !> improves (at most one a second).  Callers hold critical (fitpar_app_io).
   subroutine log_eval(cfg, id, slot, st, vals, nv, p)
      type(app_cfg), intent(inout) :: cfg
      integer, intent(in) :: id, slot, st, nv
      real(wp), intent(in) :: vals(:), p(:)
      real(wp) :: v
      character(len=:), allocatable :: line
      integer :: i
      integer(int64) :: now
      v = opt_huge
      if (st == 0 .and. nv > 0) then
         select case (cfg%mode)
         case (MODE_OBJ);   v = vals(1)
         case (MODE_RES);   v = sum(vals(1:nv)**2)
         case (MODE_MODEL)
            if (nv == cfg%ndata) v = sum(((vals(1:nv) - cfg%y) / cfg%sy)**2)
         end select
      end if
      if (cfg%have_hist) then
         line = itoa(id)//','//itoa(slot)//','//trim(merge('ok    ', 'failed', st == 0))//','
         if (st == 0) line = line//gnum(v)
         do i = 1, size(p)
            line = line//','//gnum(p(i))
         end do
         write (cfg%hist_unit, '(a)') line
         flush (cfg%hist_unit)
      end if
      if (st == 0 .and. v < cfg%best) then
         cfg%best = v
         call write_best(cfg, p)          ! kept current, so an interrupted run leaves it
         call system_clock(now)
         if (cfg%progress .and. (cfg%last_print < 0 .or. now - cfg%last_print >= cfg%clock_rate)) then
            cfg%last_print = now
            write (*, '(a,i9,a,a,a,a)') '   evaluation', id, '   best ', &
               trim(merge('objective ', 'chi2      ', cfg%mode == MODE_OBJ)), ' = '//snum(v), &
               '   ('//duration(real(now - cfg%clock0, wp) / real(cfg%clock_rate, wp))//')'
         end if
      end if
   end subroutine log_eval

   subroutine print_setup(cfg, o)
      type(app_cfg), intent(in) :: cfg
      type(opt_options), intent(in) :: o
      integer :: i, w
      write (*, '(a)') ' ======================================================================'
      write (*, '(a)') ' fitpar '//fitpar_version//'   input: '//cfg%input_file
      write (*, '(a)') ' ======================================================================'
      if (len(cfg%func) > 0) then
         write (*, '(a)') ' objective : built-in function '//cfg%func
      else
         write (*, '(a)') ' command   : '//cfg%command
      end if
      select case (cfg%mode)
      case (MODE_OBJ);   write (*, '(a)') ' mode      : objective (one number per evaluation)'
      case (MODE_RES);   write (*, '(a)') ' mode      : residuals (minimise their sum of squares)'
      case (MODE_MODEL); write (*, '(a,i0,a)') ' mode      : model values against ', cfg%ndata, ' data points'
      end select
      write (*, '(a,a,a,i0)') ' method    : ', trim(o%method), '   max_feval = ', o%max_feval
      if (cfg%parallel .and. len(cfg%func) > 0) then
         write (*, '(a,i0,a)') ' parallel  : ', cfg%nslots, ' evaluations at a time'
      else if (cfg%parallel) then
         write (*, '(a,i0,a)') ' parallel  : ', cfg%nslots, &
            ' evaluations at a time, each in its own folder under '//cfg%workdir
      end if
      write (*, '(a,i0,a,i0,a)') ' parameters: ', cfg%np, ' (', cfg%nfree, ' free)'
      w = 12
      do i = 1, cfg%np
         w = max(w, len_trim(cfg%pname(i)))
      end do
      write (*, '(3x,a)') pad('name', w)//'  '//pad('start', 13)//'range'
      do i = 1, cfg%np
         if (cfg%pfix(i)) then
            write (*, '(3x,a)') pad(cfg%pname(i), w)//'  '//pad(snum(cfg%pstart(i)), 13)//'fixed'
         else
            write (*, '(3x,a)') pad(cfg%pname(i), w)//'  '//pad(snum(cfg%pstart(i)), 13)// &
               '['//bnum(cfg%plo(i))//', '//bnum(cfg%phi(i))//']'//trim(merge('   log scale', '            ', cfg%plog(i)))
         end if
      end do
   end subroutine print_setup

   subroutine report(cfg, res, nev, tsec)
      type(app_cfg), intent(inout)  :: cfg
      type(opt_result), intent(in)  :: res
      integer, intent(in) :: nev
      real(wp), intent(in) :: tsec
      real(wp) :: p(cfg%np), s, lo, hi, uj, wid
      integer :: u, i, j, k, unitlist(2), ui, w, ndof
      character(len=24) :: note
      character(len=:), allocatable :: sig
      logical :: stats, allfail
      call to_physical(cfg, res%x, p)
      ! every evaluation after the test at the start failed: there is no fit
      allfail = nev > 1 .and. cfg%nfail_fit >= nev - 1
      stats = res%has_stats .and. allocated(res%sigma) .and. .not. allfail
      ! degrees of freedom: data values less free parameters
      ndof = cfg%m - cfg%nfree
      ! the model meets data with given sigmas exactly: scaling by chi2/dof
      ! would turn every uncertainty into 0
      if (stats .and. ndof > 0 .and. cfg%mode == MODE_MODEL .and. cfg%have_sigma .and. &
          .not. cfg%abs_sigma) then
         if (2.0_wp * res%f / ndof < 1.0e-6_wp) then
            cfg%abs_sigma = .true.; cfg%abs_why = 2
         end if
      end if
      w = 16
      do i = 1, cfg%np
         w = max(w, len_trim(cfg%pname(i)))
      end do
      unitlist(1) = 6
      open (newunit=u, file=cfg%output_file, status='replace', action='write')
      unitlist(2) = u
      do ui = 1, 2
         k = unitlist(ui)
         write (k, '(/,a)') ' ======================================================================'
         write (k, '(a)') ' fitpar result   (input: '//cfg%input_file//')'
         write (k, '(a)') ' ======================================================================'
         write (k, '(a,a)') ' method      : ', trim(res%method)
         write (k, '(a,a)') ' status      : ', trim(res%message)
         if (len(cfg%polish_msg) > 0) write (k, '(a,a)') ' polish      : ', cfg%polish_msg
         write (k, '(a,i0,a,i0,a,a)') ' evaluations : ', nev, ' (', cfg%nfail_fit, ' failed) in ', duration(tsec)
         if (allfail) then
            write (k, '(a)') ' WARNING: every evaluation after the test at the start point failed, so the'
            write (k, '(a)') ' result is the start point.  See the messages above and the history file.'
         end if
         select case (cfg%mode)
         case (MODE_OBJ)
            write (k, '(a,a)') ' objective   : ', trim(adjustl(fmtx(res%f, '(es20.12)')))
         case default
            write (k, '(a,a)') ' chi2        : ', trim(adjustl(fmtx(2.0_wp * res%f, '(es20.12)')))
            if (stats .and. ndof > 0) then
               write (k, '(a,i0,a,a)') ' dof         : ', ndof, '      chi2/dof = ', rnum(2.0_wp * res%f / ndof, 4)
            else if (stats .and. ndof == 0) then
               write (k, '(a,i0,a)') ' dof         : ', ndof, '      (as many data values as free parameters)'
            else if (stats) then
               write (k, '(a,i0,a)') ' dof         : ', ndof, '     (fewer data values than free parameters)'
            end if
         end select
         if (stats) then
            write (k, '(/,a)') ' '//pad('parameter', w)//'  '//pad('value', 18)//'   '//pad('+/- 1 sigma', 24)//'note'
         else
            write (k, '(/,a)') ' '//pad('parameter', w)//'  '//pad('value', 18)//'   note'
         end if
         do i = 1, cfg%np
            note = ''; sig = ''
            if (cfg%pfix(i)) then
               note = 'fixed'
            else
               j = findloc(cfg%ifree, i, 1)
               lo = to_internal(cfg, i, cfg%plo(i)); hi = to_internal(cfg, i, cfg%phi(i)); uj = res%x(j)
               wid = 1.0_wp                        ! the scale of "at a bound"
               if (abs(lo) < 0.5_wp * opt_huge .and. abs(hi) < 0.5_wp * opt_huge) wid = max(1.0_wp, hi - lo)
               if (abs(lo) < 0.5_wp * opt_huge) then
                  if (abs(uj - lo) <= 1.0e-6_wp * wid) note = 'AT LOWER BOUND'
               end if
               if (abs(hi) < 0.5_wp * opt_huge) then
                  if (abs(uj - hi) <= 1.0e-6_wp * wid) note = 'AT UPPER BOUND'
               end if
               if (stats) then
                  if (cfg%abs_sigma .and. allocated(res%sigma_abs)) then
                     s = res%sigma_abs(j)
                  else
                     s = res%sigma(j)
                  end if
                  s = min(s, 300.0_wp)                          ! 10**s must not overflow
                  if (res%rank < cfg%nfree .and. sig0(res, j)) then
                     sig = 'undetermined'
                  else if (cfg%plog(i) .and. 10.0_wp**s < 1.1_wp) then
                     sig = '+/- '//rnum(100.0_wp * (10.0_wp**s - 1.0_wp), 2)//' %  (log10 '//rnum(s, 2)//')'
                  else if (cfg%plog(i)) then
                     sig = 'x/ '//rnum(10.0_wp**s, 4)//'  (log10 '//rnum(s, 3)//')'
                  else
                     sig = trim(adjustl(fmtx(s, '(es12.4)')))
                  end if
               end if
            end if
            if (stats) then
               write (k, '(1x,a,1x,a,3x,a,a)') pad(cfg%pname(i), w), vnum(p(i)), pad(sig, 24), trim(note)
            else
               write (k, '(1x,a,1x,a,3x,a)') pad(cfg%pname(i), w), vnum(p(i)), trim(note)
            end if
         end do
         if (stats .and. cfg%nfree > 1 .and. allocated(res%corr)) then
            write (k, '(/,a)') ' correlation matrix of the free parameters'
            if (cfg%nfree <= 12) then
               do j = 1, cfg%nfree
                  write (k, '(1x,a,1x,a)') pad(cfg%pname(cfg%ifree(j)), w), corr_row(res, j, cfg%nfree)
               end do
            else if (ui == 1) then
               write (k, '(a)') ' (more than 12 free parameters: the full matrix is in '//cfg%output_file//')'
            else
               write (k, '(a)') ' (more than 12 free parameters: the full matrix is below)'
            end if
         end if
         if (stats .and. ndof < 0) then
            write (k, '(/,a,i0,a,i0,a)') ' WARNING: there are fewer data values (', cfg%m, ') than free parameters (', &
               cfg%nfree, '),'
            write (k, '(a)') ' so the data cannot determine them all: the values above are one of many'
            write (k, '(a)') ' equally good fits.  Fix parameters until no more are free than there are'
            write (k, '(a)') ' independent data values, or add data (other conditions, doses, times).'
         else if (stats .and. res%rank < cfg%nfree) then
            write (k, '(/,a,i0,a,i0,a)') ' WARNING: the Jacobian has rank ', res%rank, ' with ', cfg%nfree, &
               ' free parameters: the data'
            write (k, '(a)') ' do not determine every parameter here.  "undetermined" uncertainties are'
            write (k, '(a)') ' unbounded, and the fit may be stuck: try a global method, other start'
            write (k, '(a)') ' values, or fix a parameter.'
         end if
         if (stats .and. cfg%mode /= MODE_OBJ) then
            if (cfg%abs_sigma .and. cfg%abs_why == 1) then
               write (k, '(/,a)') ' The uncertainties are from the Jacobian at the optimum and the given sigmas'
               write (k, '(a)') ' alone: with no more data values than free parameters, chi2/dof cannot'
               write (k, '(a)') ' scale them.'
            else if (cfg%abs_sigma .and. cfg%abs_why == 2) then
               write (k, '(/,a)') ' The uncertainties are from the Jacobian at the optimum and the given sigmas'
               write (k, '(a)') ' alone: the model meets the data exactly (chi2/dof ~ 0), and scaling by'
               write (k, '(a)') ' chi2/dof would make them 0.'
            else if (cfg%abs_sigma) then
               write (k, '(/,a)') ' The uncertainties are from the Jacobian at the optimum and the given sigmas'
               write (k, '(a)') ' alone (uncertainties = absolute: not scaled by chi2/dof).'
            else
               write (k, '(/,a)') ' The uncertainties are from the Jacobian at the optimum, scaled by chi2/dof'
               write (k, '(a)') ' (set uncertainties = absolute to use the given sigmas alone).'
            end if
         end if
         if (any(cfg%plog(1:cfg%np) .and. .not. cfg%pfix(1:cfg%np)) .and. stats) write (k, '(a)') &
            ' For log-scaled parameters the uncertainty is a factor, value x/ factor'// &
            new_line('a')//' (shown as a percentage when it is below 10 %).'
         if (ui == 2 .and. stats .and. allocated(res%corr) .and. cfg%nfree > 12) then
            write (k, '(/,a)') ' correlation matrix (lower triangle, free parameters in order)'
            do j = 1, cfg%nfree
               write (k, '(a)') corr_row(res, j, cfg%nfree)
            end do
         end if
         if (cfg%have_hist) then
            write (k, '(/,a)') ' best parameters written to '//cfg%best_file// &
               '; every evaluation is in '//cfg%history_file
         else
            write (k, '(/,a)') ' best parameters written to '//cfg%best_file
         end if
      end do
      close (u)
      call write_best(cfg, p)
   end subroutine report

   subroutine write_best(cfg, p)
      type(app_cfg), intent(in) :: cfg
      real(wp), intent(in) :: p(:)
      integer :: u, i
      open (newunit=u, file=cfg%best_file, status='replace', action='write')
      do i = 1, cfg%np
         write (u, '(a,1x,a)') cfg%pname(i)(1:max(len_trim(cfg%pname(i)), 12)), fmtnum(cfg, p(i))
      end do
      close (u)
   end subroutine write_best

   ! ======================================================================
   !  parameter transforms
   ! ======================================================================
   real(wp) function to_internal(cfg, i, v) result(u)
      type(app_cfg), intent(in) :: cfg
      integer, intent(in) :: i
      real(wp), intent(in) :: v
      if (cfg%plog(i)) then
         if (v >= 0.5_wp * opt_huge) then
            u = opt_huge
         else
            u = log10(v)
         end if
      else
         u = v
      end if
   end function to_internal

   subroutine to_physical(cfg, u, p)
      type(app_cfg), intent(in) :: cfg
      real(wp), intent(in) :: u(:)
      real(wp), intent(out) :: p(:)
      integer :: j, i
      p = cfg%pstart(1:cfg%np)
      do j = 1, cfg%nfree
         i = cfg%ifree(j)
         if (cfg%plog(i)) then
            p(i) = 10.0_wp**u(j)
         else
            p(i) = u(j)
         end if
      end do
   end subroutine to_physical

   ! ======================================================================
   !  small text utilities
   ! ======================================================================
   pure function lower(s) result(t)
      character(len=*), intent(in) :: s
      character(len=len(s)) :: t
      integer :: i
      t = s
      do i = 1, len(t)
         if (t(i:i) >= 'A' .and. t(i:i) <= 'Z') t(i:i) = achar(iachar(t(i:i)) + 32)
      end do
   end function lower

   !> Remove a # comment (not inside quotes).
   function strip_comment(s) result(t)
      character(len=*), intent(in) :: s
      character(len=len(s)) :: t
      integer :: i
      character :: q
      t = s; q = ' '
      do i = 1, len_trim(s)
         if (q == ' ') then
            if (s(i:i) == '"' .or. s(i:i) == "'") then
               q = s(i:i)
            else if (s(i:i) == '#') then
               t = s(1:i - 1); return
            end if
         else if (s(i:i) == q) then
            q = ' '
         end if
      end do
   end function strip_comment

   function strip_quotes(s) result(t)
      character(len=*), intent(in) :: s
      character(len=:), allocatable :: t
      integer :: n
      n = len_trim(s)
      if (n >= 2) then                     ! "a b" -> a b, but not "a" "b" or 'x' y 'z'
         if ((s(1:1) == '"' .or. s(1:1) == "'") .and. s(n:n) == s(1:1)) then
            if (index(s(2:n - 1), s(1:1)) == 0) then
               t = s(2:n - 1); return
            end if
         end if
      end if
      t = s(1:n)
   end function strip_quotes

   function first_token(s) result(t)
      character(len=*), intent(in) :: s
      character(len=LNAME) :: t
      integer :: k
      k = scan(trim(s), ' ,='//achar(9))
      if (k == 0) then
         t = trim(s)
      else
         t = s(1:k - 1)
      end if
   end function first_token

   !> Split on blanks, tabs, commas and semicolons.
   subroutine split(s, tok, n)
      character(len=*), intent(in)  :: s
      character(len=*), intent(out) :: tok(:)
      integer, intent(out) :: n
      integer :: i, i0
      logical :: in
      n = 0; in = .false.; i0 = 1
      tok = ''
      do i = 1, len_trim(s) + 1
         if (i <= len_trim(s)) then
            if (index(' ,;'//achar(9), s(i:i)) == 0) then
               if (.not. in) then
                  in = .true.; i0 = i
               end if
               cycle
            end if
         end if
         if (in) then
            in = .false.
            if (n < size(tok)) then
               n = n + 1; tok(n) = s(i0:i - 1)
            end if
         end if
      end do
   end subroutine split

   logical function is_number(s)
      character(len=*), intent(in) :: s
      is_number = .false.
      if (len_trim(s) == 0) return
      if (verify(trim(s), '0123456789+-.eEdD') /= 0) return
      is_number = scan(s, '0123456789') > 0
   end function is_number

   logical function is_nonfinite_word(s)
      character(len=*), intent(in) :: s
      select case (lower(trim(s)))
      case ('nan', '-nan', '+nan', 'inf', '-inf', '+inf', 'infinity', '-infinity', '+infinity')
         is_nonfinite_word = .true.
      case default
         is_nonfinite_word = .false.
      end select
   end function is_nonfinite_word

   subroutine to_logical(v, b, ok)
      character(len=*), intent(in) :: v
      logical, intent(out) :: b, ok
      ok = .true.
      select case (lower(trim(v)))
      case ('true', '.true.', 't', 'yes', 'y', 'on', '1'); b = .true.
      case ('false', '.false.', 'f', 'no', 'n', 'off', '0'); b = .false.
      case default; ok = .false.; b = .false.
      end select
   end subroutine to_logical

   function replace_all(s, a, b) result(t)
      character(len=*), intent(in) :: s, a, b
      character(len=:), allocatable :: t
      integer :: k, i0
      t = ''; i0 = 1
      do
         k = index(s(i0:), a)
         if (k == 0) exit
         t = t//s(i0:i0 + k - 2)//b
         i0 = i0 + k - 1 + len(a)
         if (i0 > len(s)) exit
      end do
      if (i0 <= len(s)) t = t//s(i0:)
   end function replace_all

   !> replace_all, but a matches without regard to case
   function replace_ci(s, a, b) result(t)
      character(len=*), intent(in) :: s, a, b
      character(len=:), allocatable :: t, ls, la
      integer :: k, i0
      ls = lower(s); la = lower(a)
      t = ''; i0 = 1
      do
         k = index(ls(i0:), la)
         if (k == 0) exit
         t = t//s(i0:i0 + k - 2)//b
         i0 = i0 + k - 1 + len(a)
         if (i0 > len(s)) exit
      end do
      if (i0 <= len(s)) t = t//s(i0:)
   end function replace_ci

   function itoa(i) result(t)
      integer, intent(in) :: i
      character(len=:), allocatable :: t
      character(len=24) :: b
      write (b, '(i0)') i; t = trim(b)
   end function itoa

   function gnum(x) result(t)
      real(wp), intent(in) :: x
      character(len=:), allocatable :: t
      character(len=40) :: b
      write (b, '(es23.15e3)') x; t = trim(adjustl(b))
   end function gnum

   !> Up to 7 significant digits, fixed notation where it is short.
   function snum(x) result(t)
      real(wp), intent(in) :: x
      character(len=:), allocatable :: t
      character(len=40) :: b
      integer :: k
      if (x == 0) then
         t = '0'; return
      end if
      if (abs(x) >= 1.0e-3_wp .and. abs(x) < 1.0e6_wp) then
         write (b, '(f0.' // itoa(max(0, 6 - floor(log10(abs(x))))) // ')') x
         t = trim(adjustl(b))
         if (index(t, '.') > 0) then
            k = len(t)
            do while (t(k:k) == '0')
               k = k - 1
            end do
            if (t(k:k) == '.') k = k - 1
            t = t(1:k)
         end if
         if (t(1:1) == '.') t = '0'//t
         if (len(t) >= 2) then
            if (t(1:2) == '-.') t = '-0'//t(2:)
         end if
      else
         write (b, '(es14.6e3)') x; t = trim(adjustl(b))
         k = index(t, 'E')
         do while (k > 2 .and. t(k - 1:k - 1) == '0')
            t = t(1:k - 2)//t(k:); k = k - 1
         end do
         if (t(k - 1:k - 1) == '.') t = t(1:k - 2)//t(k:)
         t = replace_all(t, 'E+00', 'E+'); t = replace_all(t, 'E-00', 'E-')
         t = replace_all(t, 'E+0', 'E+'); t = replace_all(t, 'E-0', 'E-')
      end if
   end function snum

   !> x rounded to nd significant digits, written as by snum
   function rnum(x, nd) result(t)
      real(wp), intent(in) :: x
      integer, intent(in)  :: nd
      character(len=:), allocatable :: t
      real(wp) :: q
      if (x == 0 .or. .not. (abs(x) < huge(x))) then
         t = snum(x); return
      end if
      q = 10.0_wp**(floor(log10(abs(x))) - nd + 1)
      t = snum(anint(x / q) * q)
   end function rnum

   !> s left-justified in a field of at least n characters
   function pad(s, n) result(t)
      character(len=*), intent(in) :: s
      integer, intent(in) :: n
      character(len=:), allocatable :: t
      t = trim(s)
      if (len(t) < n) t = t//repeat(' ', n - len(t))
   end function pad

   function bnum(x) result(t)
      real(wp), intent(in) :: x
      character(len=:), allocatable :: t
      if (x <= -0.5_wp * opt_huge) then
         t = '-inf'
      else if (x >= 0.5_wp * opt_huge) then
         t = 'inf'
      else
         t = snum(x)
      end if
   end function bnum

   function fmtx(x, f) result(t)
      real(wp), intent(in) :: x
      character(len=*), intent(in) :: f
      character(len=:), allocatable :: t
      character(len=60) :: b
      write (b, f) x; t = trim(adjustl(b))
   end function fmtx

   !> Row j of the correlation matrix, lower triangle, 7 characters an entry;
   !> "-" where a parameter is undetermined (rank-deficient Jacobian, sigma 0).
   function corr_row(res, j, nfree) result(t)
      type(opt_result), intent(in) :: res
      integer, intent(in) :: j, nfree
      character(len=:), allocatable :: t
      integer :: i
      logical :: undet_j, undet_i
      t = ''
      undet_j = res%rank < nfree .and. sig0(res, j)
      do i = 1, j
         undet_i = res%rank < nfree .and. sig0(res, i)
         if (undet_i .or. undet_j) then
            t = t//'      -'
         else
            t = t//fmtx7(clean0(res%corr(j, i)))
         end if
      end do
   end function corr_row

   !> Do the data leave parameter j undetermined?
   logical function sig0(res, j)
      type(opt_result), intent(in) :: res
      integer, intent(in) :: j
      if (allocated(res%undetermined)) then
         sig0 = res%undetermined(j)
      else if (allocated(res%sigma_abs)) then
         sig0 = res%sigma_abs(j) <= 0
      else
         sig0 = res%sigma(j) <= 0
      end if
   end function sig0

   function fmtx7(x) result(t)
      real(wp), intent(in) :: x
      character(len=7) :: t
      write (t, '(f7.3)') x
   end function fmtx7

   !> correlations for printing: no "-0.000"
   pure elemental function clean0(c) result(d)
      real(wp), intent(in) :: c
      real(wp) :: d
      d = c
      if (abs(c) < 5.0e-4_wp) d = 0.0_wp
   end function clean0

   !> a parameter value for the result table: 19 characters, sign column kept
   function vnum(x) result(t)
      real(wp), intent(in) :: x
      character(len=:), allocatable :: t
      t = fmtx(x, '(es19.12)')
      if (t(1:1) /= '-') t = ' '//t
      t = pad(t, 19)
   end function vnum

   function fmtnum(cfg, x) result(t)
      type(app_cfg), intent(in) :: cfg
      real(wp), intent(in) :: x
      character(len=:), allocatable :: t
      character(len=80) :: b
      integer :: ios
      write (b, cfg%number_format, iostat=ios) x
      if (ios /= 0) write (b, '(es24.16e3)') x
      t = trim(adjustl(b))
   end function fmtnum

   function slot_dir(cfg, s) result(d)
      type(app_cfg), intent(in) :: cfg
      integer, intent(in) :: s
      character(len=:), allocatable :: d
      character(len=8) :: b
      write (b, '(i2.2)') s
      d = cfg%workdir//'/slot'//trim(b)
   end function slot_dir

   function join_path(d, f) result(p)
      character(len=*), intent(in) :: d, f
      character(len=:), allocatable :: p
      if (d == '.' .or. len(d) == 0) then
         p = f
      else
         p = d//'/'//f
      end if
   end function join_path

   function winpath(p) result(q)
      character(len=*), intent(in) :: p
      character(len=len(p)) :: q
      integer :: i
      q = p
      do i = 1, len(q)
         if (q(i:i) == '/') q(i:i) = '\'
      end do
   end function winpath

   logical function is_windows()
      character(len=32) :: v
      integer :: st
      call get_environment_variable('OS', v, status=st)
      is_windows = (st == 0 .and. index(v, 'Windows') > 0)
   end function is_windows

   subroutine delete_file(fn)
      character(len=*), intent(in) :: fn
      integer :: u, ios
      open (newunit=u, file=fn, status='old', iostat=ios)
      if (ios == 0) close (u, status='delete')
   end subroutine delete_file

   function duration(sec) result(t)
      real(wp), intent(in) :: sec
      character(len=:), allocatable :: t
      if (sec < 1) then
         t = trim(adjustl(fmtx(sec, '(f6.3)')))//' s'
      else if (sec < 120) then
         t = fmtx(sec, '(f0.1)')//' s'
      else if (sec < 7200) then
         t = itoa(nint(sec / 60))//' min'
      else if (sec < 172800) then
         t = fmtx(sec / 3600, '(f0.1)')//' h'
      else
         t = fmtx(sec / 86400, '(f0.1)')//' days'
      end if
   end function duration

   ! ======================================================================
   !  help
   ! ======================================================================
   subroutine usage()
      write (*, '(a)') 'fitpar '//fitpar_version//' -- fit the parameters of any program'
      write (*, '(a)') ''
      write (*, '(a)') 'usage:  fitpar input.inp [key=value ...]   run the fit described in input.inp'
      write (*, '(a)') '        fitpar --example                   print a commented starter input file'
      write (*, '(a)') '        fitpar --options                   list the settings of the methods, with defaults'
      write (*, '(a)') '        fitpar --version'
      write (*, '(a)') ''
      write (*, '(a)') 'key=value arguments override the input file, e.g.  fitpar fit.inp max_feval=500'
      write (*, '(a)') 'The manual: fitpar-manual.pdf (in the doc folder of the fitpar package).'
   end subroutine usage

   subroutine print_example()
      character(len=*), parameter :: L(*) = [character(len=78) :: &
         '# fitpar input file.  Run it with:  fitpar fit.inp', &
         '# Comments start with #.  The manual: fitpar-manual.pdf', &
         '#', &
         '# For every trial point fitpar writes the parameters to params.txt (one', &
         '# "name value" line each), runs the command, and reads result.txt.', &
         '', &
         'command = python3 model.py        # your program or script', &
         '', &
         '# What the command writes to result.txt:', &
         '#   objective   one number, to be minimised', &
         '#   residuals   numbers whose sum of squares is minimised', &
         '#   model       model values, compared with data as (model - y) / sigma', &
         'mode = objective', &
         '', &
         '# method    = foctopus            # leave out and fitpar chooses', &
         '# max_feval = 2000                # most evaluations to spend', &
         '', &
         'parameters', &
         '#  name     start     lower     upper    [log] [fixed]', &
         '   a        1.0       0.0       10.0', &
         '   k        0.5       1e-3      1e3      log', &
         'end', &
         '', &
         '# With mode = model:  data_file = data.dat   (columns: y, or y and sigma)']
      integer :: i
      do i = 1, size(L)
         write (*, '(a)') trim(L(i))
      end do
   end subroutine print_example

end module fitpar_app
