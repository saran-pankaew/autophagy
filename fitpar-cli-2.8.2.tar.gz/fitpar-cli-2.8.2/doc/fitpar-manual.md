# fitpar — user manual

Fit the parameters of any program from the command line. Version 2.8.1.

`fitpar` is a ready-to-run program. You describe
the fit in a short input file — which command computes the model, which
parameters to vary and within which limits, and what to compare the result
with — and `fitpar` does the rest: it chooses trial points, runs your command
for each of them, reads what the command wrote, and reports the best
parameters with their uncertainties and correlations. The command can be
anything that runs from a terminal: a Python script, a compiled simulation
code, a shell script that calls three programs in a row.

```text
   fit.inp  -->  fitpar   1. chooses a trial point
                          2. writes the parameters    -->  params.txt
                          3. runs your command        -->  (any program)
                          4. reads its result         <--  result.txt
                          5. repeats until done
                 and reports   fitpar_result.txt  fitpar_best.txt  fitpar_history.csv
```

The first part of this manual is seven worked examples, from a built-in test
function to a parallel global search and a stochastic Boolean network; every one is in the `examples` folder
and runs in seconds. The rest is the reference.

---

## Contents

1. [Getting started](#1-getting-started)
2. [Seven examples](#2-seven-examples)
3. [How fitpar works](#3-how-fitpar-works)
4. [The input file](#4-the-input-file)
5. [Objective, residuals or model: the three modes](#5-objective-residuals-or-model-the-three-modes)
6. [Choosing a method](#6-choosing-a-method)
7. [Running in parallel](#7-running-in-parallel)
8. [Output files](#8-output-files)
9. [When something goes wrong](#9-when-something-goes-wrong)
10. [Reference](#10-reference)

---

## 1. Getting started

### What you need

- A Fortran compiler, once, to build `fitpar`: gfortran 13 or newer is the
  tested choice; Intel's ifx works on Linux.
- Python 3 (`python3`) for the model scripts of the examples. Your own model
  needs whatever it needs; `fitpar` itself needs nothing else.

### Build

In the `fitpar` folder (unpacked from `fitpar-cli-2.8.1.tar.gz`):

```bash
./build.sh           # builds bin/fitpar
./build.sh test      # ... and runs its 25 tests (a minute or two)
```

`build.sh` finds the compiler (`gfortran`, `gfortran-16`, …, or the one
named in `FC=`), tunes the code for the processor where the compiler can, and
uses OpenMP for parallel runs where the compiler has it. Then put `bin` on
your `PATH`, or copy `bin/fitpar` to a folder that is on it:

```bash
export PATH="$PWD/bin:$PATH"   # this terminal only; add it to ~/.zshrc or ~/.bashrc to keep it
fitpar --version               # fitpar 2.8.1
fitpar                         # a short help text
fitpar --example               # a commented starter input file
```

### Linux

Install gfortran with the system's package manager —
`sudo apt install gfortran` (Debian, Ubuntu), `sudo dnf install gcc-gfortran`
(Fedora) — and run `./build.sh`.

### macOS

`fitpar` runs on Macs with Apple Silicon (M1 to M4) and with Intel
processors. It is built from the sources with gfortran; Intel's Fortran
compilers no longer support macOS.

- **Apple Silicon.** Install Apple's Command Line Tools and, with Homebrew,
  GCC, which contains gfortran:

  ```bash
  xcode-select --install     # once, if the Command Line Tools are not there yet
  brew install gcc           # gfortran
  ./build.sh test
  ```

  The installer packages of the gfortran-for-macOS project
  (`github.com/fxcoudert/gfortran-for-macOS`) are an alternative to Homebrew;
  they put the compiler under `/usr/local/gfortran`.
- **Intel Mac.** Homebrew no longer ships ready-built GCC for Intel Macs, so
  `brew install gcc` would compile GCC itself, which takes hours. Use the
  gfortran 14.2 installer for Intel of gfortran-for-macOS (macOS 14 and 15),
  or MacPorts (`sudo port install gcc14`; the compiler is `gfortran-mp-14`).
  `build.sh` finds either.
- The Python examples run with the `python3` of the Command Line Tools.
- Everything else — the shell commands, Ctrl-C, parallel runs — works as on
  Linux. (This version was tested on Linux only.)

### Windows

Use WSL, the Windows Subsystem for Linux, and follow the Linux steps. A
native Windows build (with MSYS2's gfortran) runs the commands through
`cmd.exe`; that path is in place but was not tested.

### The examples at a glance

| Folder | What it shows | Time |
|----------------------|----------------------------------------------------------------|----------|
| `1-builtin` | the input file, a built-in test function, no external program | 0.03 s |
| `2-own-objective` | your own objective in a Python script: `params.txt` in, `result.txt` out | 3 s |
| `3-curve-fit` | a curve fitted to data, with uncertainties and correlations | 1 s |
| `4-arrhenius` | residuals computed by the script, a log-scaled and a fixed parameter | 0.6 s |
| `5-existing-program` | a program with its own input and output format: a template and an extractor | 2 s |
| `6-parallel-global` | a trap for local methods, a global search, four evaluations at a time | 20 s |
| `7-boolean-network` | rates of a stochastic Boolean network (MaBoSS) fitted to fractions of cells; needs `pip install cmaboss` | 3 s |

Run any of them in its folder:

```bash
cd examples/3-curve-fit
fitpar fit.inp               # or, without fitpar on the PATH:  ../../bin/fitpar fit.inp
```

---

## 2. Seven examples

The outputs below come from a Linux PC. On another computer, with another
compiler or other compile flags, the last digits of the values and the
numbers of evaluations can differ a little — the rounding of the arithmetic
differs, and an iterative method then takes a slightly different path.

### 2.1 Example 1: a built-in test function

The smallest possible input file. `function =` names one of the built-in test
functions (`sphere`, `rosenbrock`, `rastrigin`, `ackley`, `styblinski`,
`griewank`), so no external program is needed; this is the way to try the
input file and the methods.

```text
# Example 1: minimise a built-in test function -- nothing else is needed.
#   fitpar fit.inp

function = rosenbrock        # built-in: sphere rosenbrock rastrigin ackley styblinski griewank
method   = nelder-mead

parameters
#  name   start   lower   upper
   x1     -1.2    -5      5
   x2      1.0    -5      5
end
```

Every parameter line is a name, a start value, and the lower and upper bounds.
`fitpar fit.inp` prints what it is going to do, evaluates the start point once
as a test, runs the fit, and reports:

```text
 ======================================================================
 fitpar result   (input: fit.inp)
 ======================================================================
 method      : Nelder-Mead
 status      : converged: relative change in f below tol_f
 evaluations : 310 (0 failed) in 0.028 s
 objective   : 2.978079242857E-22

 parameter         value                note
 x1                1.000000000008E+00
 x2                1.000000000018E+00
```

The minimum of the Rosenbrock function is at (1, 1). The same report is in
`fitpar_result.txt`; the best parameters, one `name value` line each, are in
`fitpar_best.txt`; and every single evaluation is a line of
`fitpar_history.csv`.

### 2.2 Example 2: your own objective

Now the function is computed by a program of your own — here a Python script,
but it could be anything. For every trial point `fitpar` writes the parameters
to `params.txt`, one `name value` line each, runs the command, and reads one
number from `result.txt`.

`fit.inp`:

```text
command = python3 model.py
method  = nelder-mead

parameters
#  name   start   lower   upper
   x      0.0     -5      5
   y      0.0     -5      5
end
```

`model.py`:

```python
# Himmelblau's function: four minima, all with f = 0.
# Read the parameters fitpar wrote, write the objective where fitpar reads it.
p = {name: float(value) for name, value in (line.split() for line in open('params.txt'))}
x, y = p['x'], p['y']
f = (x**2 + y - 11)**2 + (x + y**2 - 7)**2
open('result.txt', 'w').write(f'{f!r}\n')
```

What `fitpar` writes to `params.txt` — here the last one, at the best point
— with every digit of a double-precision number:

```text
x            2.9999999999469473E+000
y            1.9999999999551179E+000
```

The run:

```text
 test evaluation at the start point ...
   objective = 170
   one evaluation took 0.017 s

 fitting ...
   evaluation        2   best objective = 169.2475   (0.035 s)
   evaluation       67   best objective = 0.002049979   (1.1 s)
   evaluation      127   best objective = 5.296635E-12   (2.2 s)
   evaluation      181   best objective = 1.860064E-19   (3.2 s)
 ...
 evaluations : 185 (0 failed) in 3.3 s
 objective   : 1.860063557754E-19

 parameter         value                note
 x                 2.999999999947E+00
 y                 1.999999999955E+00
```

The progress lines appear when the best value improves, at most once a
second. Nelder–Mead found the minimum at (3, 2); from another start it would
find one of the other three. Write the result with all its digits (`repr` in
Python, `%.17g` in C, `es24.16` in Fortran): a value rounded to six digits is
a noisy objective, and methods work less well on noise.

### 2.3 Example 3: a curve fit with error bars

The commonest case: a model curve fitted to measured data. With
`mode = model` the command writes **one model value per data point** to
`result.txt`, and `fitpar` does the comparison itself: it minimises

$$\chi^2 = \sum_i \left( \frac{\mathrm{model}_i - y_i}{\sigma_i} \right)^2 .$$

`fit.inp`:

```text
command      = python3 model.py
mode         = model
data_file    = decay.dat        # columns: t  y  sigma
y_column     = 2
sigma_column = 3

parameters
#  name   start   lower    upper
   A      1.0     0        10
   k      0.1     0.001    10
   c      0.0     -1       1
end
```

`decay.dat` (21 rows; the first column is for the model script, `fitpar` uses
the columns named in the input file):

```text
#   t        y          sigma
  0.00     2.75661   0.05
  0.50     1.98605   0.05
  1.00     1.55578   0.05
  ...
```

`model.py`:

```python
# Model y(t) = A exp(-k t) + c, evaluated at the t values of decay.dat.
import math
p = {name: float(value) for name, value in (line.split() for line in open('params.txt'))}
t = [float(line.split()[0]) for line in open('decay.dat') if not line.startswith('#')]
with open('result.txt', 'w') as out:
    for ti in t:
        out.write(f"{p['A'] * math.exp(-p['k'] * ti) + p['c']!r}\n")
```

No method is set, so `fitpar` chooses `dfogn`, a derivative-free
Gauss–Newton method for exactly this kind of fit (section 6). The result:

```text
 method      : derivative-free Gauss-Newton
 status      : converged: step length below tol_x
 evaluations : 63 (0 failed) in 1.2 s
 chi2        : 2.227380427261E+01
 dof         : 18      chi2/dof = 1.237

 parameter         value                +/- 1 sigma             note
 A                 2.457121205381E+00   4.8954E-02
 k                 6.873420244116E-01   2.8403E-02
 c                 2.890079127747E-01   1.8157E-02

 correlation matrix of the free parameters
 A                  1.000
 k                  0.331  1.000
 c                 -0.189  0.616  1.000

 The uncertainties are from the Jacobian at the optimum, scaled by chi2/dof
 (set uncertainties = absolute to use the given sigmas alone).
```

How to read it:

- **chi2 / dof** is about 1 when the model describes the data within their
  error bars. Here 21 points − 3 parameters = 18 degrees of freedom, and
  χ²/dof = 1.24: a good fit. Much larger means the model or the σ values are
  wrong; much smaller, that the σ values are too large.
- **+/- 1 sigma** is the standard uncertainty of each parameter. By default it
  is scaled by χ²/dof, which makes it correct even when the σ column is only a
  relative weight (the convention of most fitting programs, e.g. SciPy's
  `curve_fit`). With `uncertainties = absolute` the σ values are taken at face
  value instead.
- **The correlation matrix** shows which parameters trade off against each
  other. k and c are correlated at 0.62: a slightly faster decay is partly
  compensated by a higher baseline.

The data were made with A = 2.5, k = 0.7, c = 0.3 and noise of σ = 0.05; all
three are recovered within about one standard uncertainty. SciPy's
`curve_fit` on the same data gives the same values to 7 digits, the same
uncertainties to 3–4 digits and the same correlations.

### 2.4 Example 4: residuals, a log-scaled and a fixed parameter

Sometimes it is easier for the script to compute the residuals itself — for
instance on a logarithmic scale. With `mode = residuals` the command writes
the residuals, any number of them, and `fitpar` minimises their sum of
squares. The model is a modified Arrhenius expression for a rate constant,

$$k(T) = A\,T^{\,n} \exp\!\left(-\frac{E_a}{RT}\right),$$

fitted to 14 rate constants known to 10 %:

```text
command = python3 model.py
mode    = residuals

parameters
#  name   start    lower    upper
   A      1e12     1e6      1e16     log
   n      0        -3       3
   Ea     20       0        300                # kJ/mol
end
```

```python
# Residuals (ln k_model - ln k_measured) / 0.10 for every row of rates.dat.
import math
R = 8.314462618e-3                                   # kJ mol-1 K-1
p = {name: float(value) for name, value in (line.split() for line in open('params.txt'))}
with open('result.txt', 'w') as out:
    for line in open('rates.dat'):
        if line.startswith('#'):
            continue
        T, k = map(float, line.split()[:2])
        lnk_model = math.log(p['A']) + p['n'] * math.log(T) - p['Ea'] / (R * T)
        out.write(f'{(lnk_model - math.log(k)) / 0.10!r}\n')
```

`A` spans ten orders of magnitude, so it carries the flag **`log`**: the
method then works with log10(A), where a step of 0.1 means the same thing
anywhere in the range. The script still receives A itself.

```text
 chi2        : 5.964471784172E+00
 dof         : 11      chi2/dof = 0.5422

 parameter         value                +/- 1 sigma             note
 A                 7.388394172481E+10   x/ 2.784  (log10 0.445)
 n                 6.861892646112E-01   1.3307E-01
 Ea                4.564538692612E+01   7.6537E-01

 correlation matrix of the free parameters
 A                  1.000
 n                 -0.999  1.000
 Ea                 0.978 -0.971  1.000
```

The uncertainty of a log-scaled parameter is a factor: A = 7.4·10¹⁰ times or
divided by 2.8. The correlations of ±0.97 to 0.999 say that these 14 points
determine a combination of A, n and Ea much better than each of them; the
true values (A = 3·10¹⁰, n = 0.8, Ea = 45) are well inside the error bars.

The usual remedy is to fix a parameter. Change the `n` line to

```text
   n      0        fixed
```

and `n` keeps the value 0 without being fitted:

```text
 chi2        : 2.038153450813E+01
 dof         : 12      chi2/dof = 1.698

 parameter         value                +/- 1 sigma             note
 A                 1.445563639579E+13   +/- 7.2 %  (log10 0.03)
 n                 0.000000000000E+00                           fixed
 Ea                4.947568230644E+01   3.2638E-01
```

The uncertainties shrink — but χ²/dof rose from 0.54 to 1.70 and Ea moved
from 45.6 to 49.5, twelve of its new standard uncertainties: fixing a
parameter at a wrong value moves the others, and χ²/dof is the warning.

### 2.5 Example 5: a program with its own input and output format

A real simulation code reads its own input file and writes its own output
file, in formats nobody wants to change. `simulate.py` stands for such a
program: it is called as

```bash
python3 simulate.py reactor.inp reactor.out
```

and needs an input file like this one:

```text
PRE-EXPONENTIAL      1.0E+08     ! 1/s
ACTIVATION-ENERGY    150.0       ! kJ/mol
RESIDENCE-TIME       1.0         ! s
TEMPERATURES         850 875 900 925 950 975 1000 1025 1050
END
```

Two things connect it to `fitpar`.

**A template** for the input file: a copy of it with the numbers to fit
replaced by the parameter names in braces. `fitpar` writes the template, with
the current values in place of `{A}` and `{Ea}`, to `params_file` before every
run. `reactor.tpl`:

```text
! reactor simulation input (template: fitpar puts the numbers in place of the names in braces)
PRE-EXPONENTIAL      {A}        ! 1/s
ACTIVATION-ENERGY    {Ea}       ! kJ/mol
RESIDENCE-TIME       1.0        ! s
TEMPERATURES         850 875 900 925 950 975 1000 1025 1050
END
```

**An extractor**: a small script that takes the numbers `fitpar` needs out of
the program's output. `reactor.out` looks like

```text
 PLUG-FLOW REACTOR, FIRST-ORDER DECOMPOSITION
 A = 7.341114e+07 1/s   Ea = 147.7022 kJ/mol   tau = 1.0 s

     T/K        k/(1/s)      remaining
    850.00   6.155537e-02   9.403009e-01
    875.00   1.118393e-01   8.941879e-01
    ...
 NORMAL TERMINATION
```

and `extract.py` copies the `remaining` column to `result.txt`:

```python
rows = []
in_table = False
for line in open('reactor.out'):
    words = line.split()
    if words[:3] == ['T/K', 'k/(1/s)', 'remaining']:
        in_table = True
    elif in_table and len(words) == 3:
        rows.append(words[2])
    elif in_table and not words:
        break
open('result.txt', 'w').write('\n'.join(rows) + '\n')
```

The command runs both, one after the other:

```text
command       = python3 simulate.py reactor.inp reactor.out && python3 extract.py
mode          = model
params_file   = reactor.inp          # the template is written to this file
template_file = reactor.tpl

data_file     = measured.dat         # T, measured fraction, its sigma
y_column      = 2
sigma_column  = 3

parameters
#  name   start    lower    upper
   A      1e6      1e3      1e15     log      # 1/s
   Ea     100      20       400               # kJ/mol
end
```

```text
 evaluations : 56 (0 failed) in 1.8 s
 chi2        : 3.771541827809E+00
 dof         : 7      chi2/dof = 0.5388

 parameter         value                +/- 1 sigma             note
 A                 7.341114219766E+07   x/ 1.279  (log10 0.107)
 Ea                1.477022193157E+02   1.9813E+00

 correlation matrix of the free parameters
 A                  1.000
 Ea                 0.999  1.000
```

(The data were made with A = 10⁸ s⁻¹ and Ea = 150 kJ/mol.) Two remarks. The
simulator prints seven significant digits, so its output is noisy at the
10⁻⁷ level; `dfogn` notices when its steps get smaller than that and stops,
and it measures the slopes for the uncertainties with steps of about one
standard uncertainty, so the noise does not spoil them (a fit of the exact
model in SciPy gives A = 7.339·10⁷ ×/÷ 1.278 and Ea = 147.70 ± 1.98).
Second, A and Ea are correlated at 0.999 — the well-known compensation of the
Arrhenius parameters over a narrow temperature range.

In your own case the command is whatever runs your code, for example
`./run_case.sh`, `mysolver.exe case.inp` or
`mpirun -np 4 ./sim input.dat && python3 post.py`.

### 2.6 Example 6: a global search, run in parallel

Where is the peak? The data are a Gaussian peak on a flat background,
101 points between 0 and 20; the model script `model.py` computes

$$y = h\,\exp\!\left(-\tfrac{1}{2}\left(\frac{x - x_0}{w}\right)^2\right) + b .$$

Started with the peak at `center = 5`, a local method sees no peak there. Run
`fitpar fit.inp method=dfogn parallel=false`:

```text
 chi2        : 2.017483346785E+03
 dof         : 97      chi2/dof = 20.8

 parameter         value                +/- 1 sigma             note
 height            0.000000000000E+00   3.3102E-01              AT LOWER BOUND
 center            4.762048841602E+00   undetermined
 width             1.050316905467E+00   undetermined
 background        1.312140000000E+00   1.0049E-01

 correlation matrix of the free parameters
 height             1.000
 center                 -      -
 width                  -      -      -
 background        -0.429      -      -  1.000

 WARNING: the Jacobian has rank 2 with 4 free parameters: the data
 do not determine every parameter here.  "undetermined" uncertainties are
 unbounded, and the fit may be stuck: try a global method, other start
 values, or fix a parameter.
```

It flattened the peak to zero height and stopped: a local minimum, and
`fitpar` says so. A global method searches the whole box instead. `fit.inp`:

```text
command        = python3 model.py
copy_files     = model.py spectrum.dat
mode           = model
data_file      = spectrum.dat
y_column       = 2
sigma_column   = 3

method         = foctopus
max_feval      = 2000
parallel       = true
max_concurrent = 4          # model runs at the same time (at most the number of cores)

parameters
#  name         start   lower   upper
   height       1       0       20
   center       5       0       20
   width        1       0.05    5
   background   0       -5      5
end
```

```text
 fitting ...
   evaluation        3   best chi2 = 5352.685   (0.058 s)
   evaluation      122   best chi2 = 584.9883   (1.1 s)
   evaluation      247   best chi2 = 117.5014   (2.2 s)
   evaluation      366   best chi2 = 101.9872   (3.2 s)
   ...
 polishing with dfogn (at most 500 evaluations) ...

 method      : foctopus + derivative-free Gauss-Newton
 status      : global search used its budget (max_feval = 2000)
 polish      : converged: step length below tol_x
 evaluations : 2037 (0 failed) in 18.1 s
 chi2        : 1.002078251731E+02
 dof         : 97      chi2/dof = 1.033

 parameter         value                +/- 1 sigma             note
 height            4.022725735667E+00   1.0934E-01
 center            1.330306145120E+01   1.8559E-02
 width             5.973873494831E-01   1.9130E-02
 background        1.013934937421E+00   2.2034E-02

 correlation matrix of the free parameters
 height             1.000
 center             0.000  1.000
 width             -0.520  0.000  1.000
 background        -0.142  0.000 -0.242  1.000
```

(In a parallel run the progress lines differ a little from run to run, since
they depend on which evaluation finishes first; the result does not.)

The peak is at 13.30 (the data were made with height 4, center 13.3,
width 0.6, background 1). A global search spends its whole budget,
`max_feval`; after it, a local polish (`dfogn`) refines the point and supplies
the uncertainties.

**Parallel.** With `parallel = true` several evaluations run at the same time,
each in its own work folder, `fitpar_work/slot00`, `slot01`, …; the command
runs inside that folder, so the files it reads and writes do not collide.
`copy_files` lists the files the command needs there: they are copied into
every work folder at the start. On the two-core machine these numbers come
from, the run took 37 s one at a time and 18–20 s with two or more at a time;
the results were identical to the last digit. See section 7.

### 2.7 Example 7: a stochastic Boolean network and cell fractions

A Boolean network decides the fate of a cell; simulated stochastically for
many cells — here with MaBoSS — it gives the fraction of cells in each fate,
which can be fitted to the fractions measured, for example by flow
cytometry. The folder holds a toy network in which stress drives a cell to
apoptosis or to autophagy (`cellfate.bnd`), a template of its MaBoSS
configuration with `{k_casp}`, `{k_auto}` and `{k_jnk}` where the rates go
(`cellfate.tpl`), and `simulate.py`, which runs MaBoSS for 10 000 cells and
writes the fractions of apoptotic and autophagic cells. `fit.inp`:

```text
command       = python3 simulate.py
mode          = model
params_file   = cellfate.cfg
template_file = cellfate.tpl

data
#  fate         fraction   sigma
   apoptosis    0.52       0.03
   autophagy    0.33       0.03
end
y_column     = 2
sigma_column = 3

parameters
#  name     start   lower   upper
   k_casp   1       0.01    100     log     # caspase activation rate
   k_auto   1       0.01    100     log     # Beclin-1 activation (autophagy) rate
   k_jnk    1       fixed                   # stress signalling rate
end
```

```text
 evaluations : 25 (0 failed) in 2.9 s
 chi2        : 0.000000000000E+00
 dof         : 0      (as many data values as free parameters)

 parameter         value                +/- 1 sigma             note
 k_casp            4.969806607430E-01   x/ 1.3  (log10 0.114)
 k_auto            5.087799542361E-01   x/ 1.385  (log10 0.141)
 k_jnk             1.000000000000E+00                           fixed

 correlation matrix of the free parameters
 k_casp             1.000
 k_auto             0.914  1.000
```

Three things to notice.

- **Fractions of one population add up to 1.** The surviving cells, 0.15,
  are 1 minus the two values fitted, so they are not a third independent
  value: two values, so at most two parameters, and `k_jnk` stays fixed. With
  as many data values as free parameters the model can meet the data
  exactly, χ² is 0, and the uncertainties come from the measured SD alone
  (section 5). Fitting all three fractions instead gives the same rates but
  uncertainties that are too small (×/1.17 and ×/1.22), and `fitpar` points
  that out; freeing `k_jnk` as well marks every rate `undetermined`.
- **Randomness.** `seed_pseudorandom = 1` in the template gives every
  evaluation the same random numbers, so the fractions change smoothly with
  the rates, and 10 000 cells keep their Monte Carlo error below 0.005,
  small against the measured SD.
- **More parameters need more data**: the fractions under another dose, at
  another time or in a knock-down, simulated by `simulate.py` and appended
  to `result.txt`, with one more row each in `data`.

The README in the folder explains how to put your own MaBoSS model (or
another simulator) in place of the toy network.

### 2.8 Changing settings from the command line

Every `key = value` setting can also be given after the input file name,
without spaces around the `=`; it overrides the file:

```bash
fitpar fit.inp method=foctopus max_feval=500 seed=7
fitpar fit.inp parallel=true max_concurrent=8
fitpar fit.inp "command=python3 model2.py"
```

---

## 3. How fitpar works

### 3.1 The evaluation cycle

1. `fitpar` reads the input file and the command-line settings and checks
   them; any mistake stops it here, with the line number where there is one.
2. It evaluates the **start point once, as a test**. If that fails, it stops
   and says why: there is no point in starting a long fit with a command that
   does not work. It also reports how long one evaluation took and, when that
   is noticeable, how long `max_feval` evaluations could take. The test
   counts against `max_feval`, so the command never runs more than
   `max_feval` times during the fit (the polish after a global search has
   its own budget, `polish_feval`).
3. The method asks for trial points. For each one `fitpar`
   - deletes the old result file,
   - writes the parameters to `params_file` (as `name value` lines, as bare
     values, or through a template),
   - runs the command and waits for it,
   - reads the numbers from `result_file` and checks them,
   - appends a line to `fitpar_history.csv`, and, if the point is the best so
     far, rewrites `fitpar_best.txt` and may print a progress line.
4. When the method has finished, the command is run **once more at the best
   point**, in the main folder, so that every file your program writes
   belongs to the final parameters (`final_run = false` turns this off).
5. The result is printed and written to `fitpar_result.txt`.

### 3.2 What the method sees

The methods work on the **free** parameters only; a `fixed` parameter keeps
its value and is still written to `params_file`. A parameter flagged `log` is
optimised as log10 of its value, with bounds log10(lower) and log10(upper);
your command always receives the value itself. Bounds may be infinite on
either side for local methods; global methods need finite bounds on every
free parameter.

### 3.3 Failed evaluations

An evaluation fails when the command cannot be started, returns a non-zero
exit status (unless `ignore_exit_status = true`), writes no result file, a
result without numbers, a `nan` or `inf`, or the wrong number of values.
A failed evaluation does not stop the fit: the methods treat the point as
very bad and move away from it. The first five failures are printed with
the command and the reason; all of them are marked `failed` in the history
file. So a program that crashes in some corner of the parameter space is not
a problem — but it does cost evaluations.

---

## 4. The input file

### 4.1 Syntax

- One setting per line: `key = value`. Keys are not case-sensitive; spaces
  around `=` are optional. A value that is a single quoted string loses its
  quotes (`name = "run 1"`); any other value is taken as it is, so
  `command = "/opt/my code/sim" "case 1.inp"` keeps its quotes for the shell.
- `#` starts a comment, except inside quotes.
- Blocks: `parameters` … `end`, `data` … `end`, `template` … `end template`.
- A later setting overrides an earlier one, and the command line overrides
  the file.
- The settings of the methods are keys as well (section 4.7).

### 4.2 Program settings

| Key | Default | Meaning |
|----------------------|--------------------|----------------------------------------------------------|
| `command` | — | the shell command that evaluates one point |
| `function` | — | a built-in test function instead of a command: `sphere`, `rosenbrock`, `rastrigin`, `ackley`, `styblinski`, `griewank` |
| `mode` | `objective` | `objective`, `residuals` or `model` (section 5) |
| `params_file` | `params.txt` | the file the parameters are written to |
| `params_format` | `names` | `names`: `name value` lines; `values`: one value per line, in the order of the parameters block |
| `number_format` | `(es24.16e3)` | Fortran format of the numbers written (the default keeps every digit) |
| `template_file` | — | a template for `params_file` (section 4.5) |
| `result_file` | `result.txt` | the file the command writes its result to |
| `data_file` | — | the data for `mode = model` (section 4.4) |
| `y_column`, `sigma_column` | — | which columns of the data are y and σ |
| `residuals` | — | with `mode = residuals`: the number of residuals, checked if given |
| `uncertainties` | `scaled` | `scaled` by χ²/dof, or `absolute` from the given σ alone |
| `workdir` | `fitpar_work` | the folder that holds the parallel work folders |
| `copy_files` | — | files copied into every work folder (parallel runs) |
| `output_file` | `fitpar_result.txt` | the result report |
| `best_file` | `fitpar_best.txt` | the best parameters, `name value` lines |
| `history_file` | `fitpar_history.csv` | one line per evaluation |
| `command_output` | `show` | the command's own output: `show`, `hide`, or `log` (appended to `command_output.txt` in the evaluation folder) |
| `progress` | `true` | progress lines while fitting |
| `final_run` | `true` | run the command once more at the best point |
| `ignore_exit_status` | `false` | do not treat a non-zero exit status as a failure |
| `name` | — | a name for the run, shown in the detailed report of `verbose = 1` |

### 4.3 The parameters block

```text
parameters
#  name     start    lower    upper    flags
   A        1e12     1e6      1e16     log       # optimised as log10(A)
   n        0        -3       3
   c        0.5      fixed                       # not fitted
   x        0                                    # no bounds
   y        1        0        inf                # lower bound only
end
```

- The name starts with a letter and contains letters, digits, `_`, `.` or `-`,
  at most 32 characters; the keywords `end`, `data`, `template`,
  `parameters`, `parameter` and `params` cannot be names. Names are not
  case-sensitive.
- Then the start value, and either both bounds or none. `-inf` and `inf`
  (also `-infinity`, `infinity`, or `none` on either side) leave a side open.
- `log` (or `log10`): optimise log10 of the parameter; start and lower bound
  must be positive. `fixed` (or `fix`): keep the start value.
- The order of the parameters is the order of `params_format = values` and of
  the columns of the history file.

### 4.4 Data (mode = model)

Either in a file, `data_file = name`, or inline:

```text
data
# y      sigma
 3.50    0.05
 2.51    0.05
 1.85    0.05
end
```

Lines starting with `#` and empty lines are skipped; columns are separated by
spaces, tabs, commas or semicolons. With one column it is y and σ = 1; with
two, y and σ; with more, set `y_column` and, if there is one, `sigma_column`
(without it σ = 1). Every σ must be positive. Other columns (for instance the
x values) are there for your model script; `fitpar` ignores them.

### 4.5 Templates

A template is the input file of your program with the numbers to fit replaced
by `{name}`. Before every run `fitpar` writes it to `params_file`, with every
`{name}` replaced by the parameter's current value (in `number_format`) and
`{id}` by the evaluation number; the names are matched without regard to
case. Everything else is copied unchanged, including lines that start with
`#`. A `{word}` that is not a parameter name gets a note at the start, since
it is most likely a misspelt name. Give it as a file,

```text
params_file   = case.inp
template_file = case.tpl
```

or inline, between `template` and `end template` (a plain `end` belongs to the
template, since input formats often contain one):

```text
params_file = case.inp
template
TEMPERATURE  {T0}
RATE         {k1}
END
end template
```

### 4.6 Placeholders in the command

| Placeholder | Replaced by |
|------------------|----------------------------------------------------------------------------------|
| `{params}` | the name of `params_file` |
| `{result}` | the name of `result_file` |
| `{dir}` | the evaluation folder (`.`, or `fitpar_work/slot03` in parallel runs) |
| `{home}` | the path from the evaluation folder back to the main folder (`.` or `../..`) |
| `{id}` | the evaluation number, 1, 2, 3, … |
| `{slot}` | the parallel slot, 0, 1, 2, … |

The command runs in the evaluation folder, so `{params}` and `{result}` are
plain file names there. For example:

```text
command = ./mymodel {params} {result}
command = python3 {home}/model.py          # a script that stays in the main folder
command = mysim -i {params} -o run{id}.out && python3 {home}/extract.py run{id}.out
```

### 4.7 Settings of the methods

Besides the program settings above, the methods have 108 settings of their
own, set in the same way (`key = value`). `fitpar --options` lists them with
their defaults, and section 10.2 has the same list. The ones that matter most:

| Key | Default | Meaning |
|--------------------------|--------------------------|------------------------------------------------|
| `method` | chosen by `fitpar` | the optimisation method (section 6) |
| `max_feval` | 200 000; global methods 1000 per free parameter | most runs of the command in the fit, the test at the start included |
| `max_time` | 0 (none) | stop after this many seconds |
| `seed` | 20240101 | random seed of the global methods: the same seed, the same run |
| `parallel`, `max_concurrent` | `false`, 0 | parallel evaluations (section 7) |
| `polish`, `local_method`, `polish_feval` | `true`, `dfogn` in fits | the local refinement after a global search |
| `dfogn_starts` | 1 | `dfogn` restarts from random points; −1: until the budget is spent |
| `tol_x`, `tol_f` | 1e-10, 1e-12 | convergence tolerances of the local methods |
| `verbose` | 0 | 1 or 2: also the method's own report and iteration log |

---

## 5. Objective, residuals or model: the three modes

| `mode` | The command writes to `result_file` | `fitpar` minimises | Uncertainties |
|------------|------------------------------|----------------------------------|----------------|
| `objective` | one number f | f | no |
| `residuals` | m numbers r₁ … r_m | χ² = Σ rᵢ² | yes |
| `model` | one model value per data point | χ² = Σ ((modelᵢ − yᵢ)/σᵢ)² | yes |

The result file may hold the numbers in any layout — one per line, several
per line, separated by spaces, tabs or commas; lines starting with `#` are
skipped, and other words are ignored, except `nan` and `inf`, which make the
evaluation fail. In the `residuals` and `model` modes the count must be the
same at every evaluation.

**Which to use.** `model` when you have data and your program computes the
corresponding model values: `fitpar` reads the data, applies the σ values and
reports χ². `residuals` when the comparison is easier in the script — on a
log scale, several data sets with different weights, a penalty term. Use
`objective` only when the quantity is not a sum of squares: least-squares
methods use the individual residuals, which is far more information than
their sum, and they give uncertainties.

**Uncertainties.** In the `residuals` and `model` modes `fitpar` reports the
standard uncertainty of every free parameter, from the Jacobian at the
optimum, J, as the square roots of the diagonal of
C = (JᵀJ)⁻¹ · χ²/dof, with dof = m − (number of free parameters), and the
correlation matrix Cᵢⱼ/√(CᵢᵢCⱼⱼ). The factor χ²/dof makes the result
independent of the scale of the σ values. With `uncertainties = absolute`
the factor is left out, which is right when the σ values are true standard
deviations and the model is known to be adequate. With residuals of your own,
divide them by their standard deviations if you want χ² to mean anything.

Two cases make the uncertainties absolute by themselves, with a note: when
there are no more data values than free parameters (dof ≤ 0, so χ²/dof is
undefined), and in `mode = model` with σ values given, when the model meets
the data exactly (χ²/dof ≈ 0, which would make every scaled uncertainty 0).
With fewer data values than free parameters, the data cannot determine all
parameters: `fitpar` marks them `undetermined` and says so.

**Fractions that add up to 1** — the fractions of cells in each fate, say —
are not independent: n of them carry n − 1 values of information. `fitpar`
notes it when both the data and the model values add up to 1. Leave one of
them out (example 7), or the uncertainties come out too small.

These are linearised uncertainties. They are reliable when the model is
close to linear within about one standard uncertainty of the optimum; for
strongly correlated or poorly determined parameters (correlations near ±1,
"undetermined", values at a bound) treat them as a warning rather than as
error bars.

---

## 6. Choosing a method

When `method` is not set, `fitpar` chooses:

| Mode | Bounds | Method |
|------------------------------|----------------------------------------|------------------------------|
| `residuals`, `model` | any | `dfogn` |
| `objective` | finite for every free parameter | `foctopus` (global) |
| `objective` | some infinite | `nelder-mead` |

**Fits to data (`dfogn`).** A derivative-free Gauss–Newton method: it keeps a
linear model of every residual and needs no derivatives, so each iteration
costs one evaluation after the first n + 1. It is the right default for
fits, and it tolerates programs that print only a few digits. It is a local
method: from a bad start it can end in a local minimum (example 6).
Remedies: a global method with a polish, or `dfogn_starts = -1` with a
`max_feval`, which restarts it from random points in the box until the
budget is spent and keeps the best.

**Global methods** search the whole box and spend their whole budget; they
need finite bounds on every free parameter. `foctopus` (FOCTOPUS-2, a
covariance-adaptive focusing search) is the default here, because it is
robust on multimodal and noisy objectives — the usual case with a
simulation; `de` and `cmaes` are good alternatives, and the others are
`pso`, `sa`, `direct`, `mlsl`, `multistart`, `basinhop`, `ga` and `mac`. In the `residuals` and
`model` modes a local polish with `dfogn` follows, which also provides the
uncertainties. The budget is 1000 evaluations per free parameter unless
`max_feval` is set; set it from the time one evaluation takes.

**Local methods for a scalar objective.** `nelder-mead` is the robust
choice for up to about ten parameters. The methods that differentiate the
objective numerically (`lbfgsb`, `bfgs`, `cg`, `sqp`, `trust-ncg`) cost n
evaluations per gradient and fail when the program rounds its output; they
are rarely right for an external program.

**How many evaluations?** `fitpar` prints the time of one evaluation at the
start. A fit to data with `dfogn` usually needs 10 to 50 evaluations per
parameter; a global search 500 to 2000 per parameter for a few parameters,
more on hard problems. `max_time` (seconds) is a second limit.

**Reproducibility.** Global methods are random, but with the same `seed` a
run is repeated exactly — also in parallel.

### The methods

| Method | Kind | Use it for |
|------------------------|----------------------|----------------------------------------------------------|
| `dfogn` | local, fits only | fits to data (`residuals`, `model`): the default there; no derivatives, tolerates rounded output |
| `lm` | local, fits only | fits of smooth models that print every digit; numerical derivatives, n evaluations per iteration |
| `nelder-mead` | local | up to about ten parameters, rough or kinked objectives |
| `powell` | local | objectives with mild noise |
| `pattern`, `mads` | local | non-smooth objectives; robust but slow in curved valleys |
| `bobyqa`, `newuoa` | local | smooth objectives whose parameters act independently; they fail when the parameters are strongly correlated |
| `lbfgsb`, `bfgs`, `cg`, `sqp`, `trust-ncg` | local, gradient | smooth objectives printed with every digit, and cheap ones |
| `foctopus` | global | multimodal or noisy objectives; the default with finite bounds |
| `de` | global | multimodal objectives (differential evolution) |
| `cmaes` | global | ill-conditioned objectives, up to about 40 parameters |
| `direct` | global, no randomness | a reproducible search in few dimensions |
| `mlsl`, `multistart`, `basinhop` | global, by local runs | several distinct local minima |
| `pso`, `sa`, `ga`, `mac` | global | alternatives to the above |

Every global method needs finite bounds on every free parameter, and in the
`residuals` and `model` modes it is followed by a polish with `dfogn` that
provides the uncertainties. Section 10.2 lists the settings of each method.

---

## 7. Running in parallel

```text
parallel       = true
max_concurrent = 8        # at most 8 runs at once; 0: as many as OMP_NUM_THREADS
copy_files     = model.py data.dat
```

- **What runs in parallel.** The methods that evaluate a whole population at
  a time: the global methods (`foctopus`, `de`, `cmaes`, `pso`, …). `dfogn`
  and the other local methods evaluate one point at a time, and so does the
  polish after a global search; with `parallel = true` they run in `slot00`,
  one evaluation after the other, and gain nothing.
- **Work folders.** Every slot has its own folder, `workdir/slot00`,
  `slot01`, …, created at the start; the command runs inside it, and
  `params_file` and `result_file` live there. The final run at the best point
  is done in the main folder.
- **Files the command needs.** List them in `copy_files` (file names separated
  by spaces; each is copied into every work folder at the start), or refer to
  them from the main folder with `{home}`:
  `command = python3 {home}/model.py`. A program that reads a large or
  fixed file is better pointed at it with `{home}` than copied.
- **How many.** Not more than the cores you can use — and not more than your
  program's licence or memory allows. If your program itself runs on several
  cores, divide.
- **Same results.** The trial points do not depend on the order in which
  evaluations finish, so a parallel run gives the same result as a serial one
  with the same seed.
- The work folders are left in place after the run; they hold the last
  evaluation of every slot, which helps when something went wrong.

---

## 8. Output files

| File | Contents |
|----------------------------|------------------------------------------------------------------------|
| `fitpar_result.txt` | the report printed at the end. With more than 12 free parameters, it also has the full correlation matrix |
| `fitpar_best.txt` | the best parameters, `name value` per line, all of them including fixed ones. Kept current during the run, so an interrupted run leaves its best point |
| `fitpar_history.csv` | one line per evaluation, the final run at the best point included: `eval, slot, status, objective` (or `chi2`), then the parameters. Failed evaluations are marked `failed` |
| `params_file`, `result_file` | of the last evaluation — normally the final run at the best point |
| `fitpar_work/slotNN/` | parallel runs: the work folders |
| `command_output.txt` | with `command_output = log`: the command's output, in each evaluation folder |

`fitpar_history.csv` of example 3:

```text
eval,slot,status,chi2,A,k,c
1,0,ok,2.110772954145552E+003,1.000000000000000E+000,1.000000000000000E-001,0.0000...
2,0,ok,4.064739063708053E+003,2.000000000000000E+000,1.000000000000000E-001,0.0000...
3,0,ok,4.261158191484095E+003,1.000000000000000E+000,1.099900000000000E+000,0.0000...
```

(the lines are cut here; every number has 16 digits).

It loads directly into a spreadsheet, Python (`pandas.read_csv`) or any
plotting program — for instance to plot χ² against one parameter, which shows
at a glance how well that parameter is determined.

---

## 9. When something goes wrong

**`build.sh` finds no compiler, or linking fails on macOS.** Install
gfortran (section 1) or name it: `FC=/usr/local/bin/gfortran ./build.sh`.
A linker message such as `library 'System' not found` after a macOS update
means the Command Line Tools need updating: `xcode-select --install`, or
reinstall them from Apple's developer downloads; then `brew upgrade gcc`.

**The test evaluation at the start point fails.** `fitpar` prints the command
and the reason. `params_file` is still there, so run the command by hand in
the same folder and look at what it does. Typical causes: a typo in the
command, `python3` instead of `python` on Windows, the script reading
`params.txt` in another format than `fitpar` writes (see `params_format`), or
the result written to another file name than `result_file`.

**"the model wrote N values but there are M data points".** In `mode = model`
the command must write exactly one value per data row, in the same order.

**Many failed evaluations.** The program fails in parts of the parameter
space. That is allowed, but narrow the bounds if you can: every failure is a
wasted evaluation. The history file shows where the failures are.

**A parameter is AT LOWER BOUND or AT UPPER BOUND.** The best fit wants to
go further. Either the bound is physical (then the result is the constrained
optimum, and its uncertainty means little) or it is too tight.

**"undetermined" and the rank warning.** The data do not change when some
parameter (or combination) changes — as for the peak position of a peak that
was flattened to zero height in example 6. Either the fit is stuck (use a
global method or better start values) or the model has more parameters than
the data can determine (fix one).

**Correlations close to ±1.** The parameters are not determined separately
(example 4). Fix one, measure over a wider range, or reparametrise.

**chi2/dof far from 1.** Much larger: the model does not describe the data,
or the σ values are too small. Much smaller: the σ values are too large.

**dof 0 or negative.** There are no more data values than free parameters.
At dof = 0 the model can usually meet the data exactly and the uncertainties
come from the σ values alone; below 0 the data cannot determine all
parameters (example 7). Fix parameters or add data.

**It takes too long.** The time per evaluation times `max_feval` is the
upper limit. Set `max_feval` or `max_time`; fix the parameters you are sure
of; for global methods use `parallel`.

**Stopping a run.** Ctrl-C stops `fitpar` (exit status 130): it reaches the
running command, the shell reports it, and `fitpar` stops at once — also in
a parallel run. `fitpar_best.txt` and `fitpar_history.csv` are written as the
run goes, so the best point so far is not lost. (A command that itself
returns exit status 130 is taken as Ctrl-C too.)

**Windows.** Commands run through `cmd.exe` there, and the paths of the work
folders are written with backslashes. Use `python` (or `py`) instead of
`python3`. Ctrl-C handling as described above is for Linux and macOS. WSL
(section 1) avoids all of this.

---

## 10. Reference

### 10.1 Command line and exit status

```text
fitpar input.inp [key=value ...]   run the fit described in input.inp
fitpar --example                   print a commented starter input file
fitpar --options                   list the settings of the methods, with defaults
fitpar --version
fitpar --help
```

The exit status is 0 when the fit ran, whatever its outcome (read the status
line), 1 when it could not start (an error in the input, or a failing test
evaluation), and 130 when it was interrupted. A script can therefore check
`$?` and then read `fitpar_best.txt`.

### 10.2 All settings of the methods

`fitpar --options` prints this list. Logical values may be written as
`true`/`false`, `yes`/`no`, `on`/`off`, `1`/`0` or `.true.`/`.false.`.
Unless you set them, `fitpar` chooses four of these itself: `method`
(section 6), `max_feval` for global methods (1000 per free parameter),
`local_method` (`dfogn` in the `residuals` and `model` modes) and `verbose`
(0, since `fitpar` prints its own report). Most of the settings below are
for fine-tuning a method and rarely needed.

<!-- OPTIONS-TABLE -->

#### Method

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `method` | `auto` | optimisation method (fitpar manual, "Choosing a method") |
| `local_method` | `lbfgsb` | method of the polish after a global search, and of the local runs of mlsl, multistart, basinhop |

#### Stopping

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `tol_f` | `1.0000E-012` | local methods: stop when f changes by less than this (relative) |
| `tol_x` | `1.0000E-010` | local methods: stop when the step is shorter than this (relative) |
| `tol_g` | `1.0000E-008` | gradient-based methods: stop when the largest gradient component is below this |
| `max_feval` | `200000` | maximum number of objective evaluations |
| `max_iter` | `20000` | maximum number of iterations (local methods) |
| `max_time` | `-1.000` | stop after this many seconds (negative: no limit) |
| `target_f` | `-1.7977E+308` | stop as soon as f <= target_f (in fits f = chi2/2) |
| `stall_iter` | `0` | stop after this many iterations without improvement (0 = off) |

#### Numerical derivatives (used only by the gradient-based methods)

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `fd_order` | `2` | 1 forward, 2 central, 4 Richardson |
| `fd_step` | `0.000` | 0 = automatic per-variable step |

#### Output and parallel runs

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `max_concurrent` | `0` | evaluations in flight at once when parallel = true (0 = OMP_NUM_THREADS) |
| `verbose` | `0` | 0 silent, 1 summary, 2 iterations, 3 debug |
| `print_every` | `1` | with verbose >= 2, print every this many iterations |
| `trace_file` | | write a CSV trace of the progress of the method to this file |

#### Random numbers, populations, restarts

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `seed` | `20240101` | random seed of the global methods: the same seed repeats a run (0 = from the clock) |
| `popsize` | `0` | population size of the global methods (0 = the method's default) |
| `parallel` | `false` | evaluate the points of a population at the same time (global methods) |
| `restarts` | `0` | extra restarts of a local method from its own result |

#### Polish after a global search

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `polish` | `true` | refine the result of a global search with local_method |
| `polish_feval` | `0` | most evaluations of the polish (0 = max(500, 20% of max_feval)) |

#### nelder-mead

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `nm_step` | `5.0000E-002` | initial simplex size (relative) |
| `nm_adaptive` | `true` | dimension-adapted coefficients |

#### lm, and the fit statistics

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `lm_lambda0` | `1.0000E-003` | initial Levenberg-Marquardt damping (dimensionless) |
| `lm_scaled` | `true` | Marquardt diagonal scaling |
| `lm_covar` | `true` | compute the uncertainties and correlations of a fit |

#### lbfgsb

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `lbfgs_memory` | `10` | correction pairs kept by L-BFGS-B |

#### de (differential evolution)

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `de_f` | `0.5000` | differential evolution: scale factor F (start value if de_adaptive) |
| `de_cr` | `0.9000` | differential evolution: crossover rate CR (start value if de_adaptive) |
| `de_adaptive` | `true` | JADE self-adaptation of F and CR |
| `de_pbest` | `0.1100` | differential evolution: fraction of the population used as p-best |
| `de_lpsr` | `true` | linear population size reduction |

#### pso (particle swarm)

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `pso_w` | `0.7298` | particle swarm: inertia weight |
| `pso_c1` | `1.496` | particle swarm: weight of the particle's own best |
| `pso_c2` | `1.496` | particle swarm: weight of the neighbourhood best |
| `pso_neighbours` | `3` | particle swarm: neighbourhood size on the ring topology |

#### cmaes

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `cma_sigma0` | `0.3000` | cmaes: initial step size, relative to the box width |
| `cma_ipop` | `true` | restart with doubled population |

#### sa (simulated annealing)

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `sa_t0` | `0.000` | simulated annealing: start temperature (0 = calibrated automatically) |
| `sa_rt` | `0.8500` | simulated annealing: temperature reduction factor |
| `sa_ns` | `20` | simulated annealing: cycles between step-length adjustments |
| `sa_nt` | `5` | simulated annealing: step adjustments between temperature reductions |

#### direct

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `direct_eps` | `1.0000E-004` | DIRECT: epsilon of the potential-optimality test |
| `direct_local` | `false` | locally biased variant (DIRECT-L) |

#### multistart, mlsl, basinhop

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `ms_points` | `0` | multistart, mlsl: number of sample points (0 = 10 n) |
| `bh_step` | `0.1000` | basin hopping: size of the random jumps, relative to the box |
| `bh_temp` | `1.000` | basin hopping: acceptance temperature |

#### bobyqa, newuoa, dfogn

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `dfo_rhobeg` | `0.000` | bobyqa, newuoa, dfogn: first trust radius in scaled units (0 = 0.1 of the box) |
| `dfogn_starts` | `1` | dfogn: number of starts (-1 = restart from random points until the budget is spent) |
| `dfogn_pred_tol` | `0.000` | dfogn: end a run when the model promises less gain than this (units of f) |
| `dfogn_stats_fd` | `true` | dfogn: error bars from differences with steps of about one standard error (2n to 8n extra evaluations; robust when the model output is noisy, e.g. printed with few digits); false: from the interpolation model, with no extra evaluation |
| `dfogn_stats_dr` | `0.000` | dfogn: the change of the residual vector those differences aim at (0 = sqrt(chi2/dof), or 1 for an exact fit; 1 suits residuals divided by true standard deviations, and fitpar sets it so for data with sigmas) |
| `dfo_rhoend` | `0.000` | bobyqa, newuoa, dfogn: last trust radius in scaled units (0 = 1e-10) |

#### pattern, mads

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `ps_mesh` | `0.1000` | initial mesh size, relative to the box |
| `ps_mads` | `false` | pattern search: randomly rotated poll directions (method = mads sets it) |

#### ga (genetic algorithm)

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `ga_pcross` | `0.8000` | crossover probability |
| `ga_pmut` | `0.000` | mutation probability (0 = 1/n) |
| `ga_elite` | `5.0000E-002` | fraction carried over unchanged |
| `ga_tournament` | `3` | tournament size for selection |

#### mac

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `mac_batch` | `0` | batch size (0 = 2 + 2 ln n, min 4) |
| `mac_window` | `0` | archive length in batches (0 = automatic) |
| `mac_ess` | `0.000` | target effective sample size (0 = a quarter of the archive) |
| `mac_gamma0` | `1.0000E-003` | initial inverse temperature |
| `mac_gamma_max` | `1.0000E+012` | MAC: upper limit of the inverse temperature |
| `mac_sigma0` | `0.2500` | initial spread, fraction of the box |
| `mac_blend` | `0.1500` | pull of the archive best on the mean |
| `mac_smooth` | `0.2000` | covariance smoothing towards the old |
| `mac_floor` | `1.0000E-009` | diagonal regularisation of the shape matrix (the shape has unit scale, so this is not a limit on accuracy) |
| `mac_tol_scale` | `1.0000E-012` | terminal scale as a fraction of the box; this is an accuracy limit, so it must sit below the accuracy wanted |

#### foctopus

| Key | Default | Meaning |
|----------------------|------------------|------------------------------------------------------------|
| `foc_classic` | `false` | the original FOCTOPUS algorithm instead of FOCTOPUS-2 (off by default) |
| `foc_nsamp` | `0` | batch size (0 = automatic) |
| `foc_zoom` | `0` | initial zoom exponent (classic) |
| `foc_zin` | `1.000` | focus step after a failed batch |
| `foc_zout` | `1.000` | focus step after a successful batch |
| `foc_zmin` | `0` | widest allowed zoom (classic) |
| `foc_zmax` | `200` | terminal resolution exponent (legacy floor only) |
| `foc_tol_scale` | `1.0000E-013` | terminal search scale as a fraction of the initial spread |
| `foc_legacy_floor` | `false` | classic foctopus: the old rule for the smallest search scale (off by default) |
| `foc_msigma` | `3.000` | box half-width in sigmas |
| `foc_noise_probe` | `true` | measure evaluation noise and shorten the restart patience under strong noise |
| `foc_noise_every` | `0` | noise probe: generations between two probes (0 = max(5, n/10)) |
| `foc_noise_ratio` | `0.5000` | noise probe: alarm when the probe pair differs by more than this times the batch spread |
| `foc_noise_patience` | `0.2500` | stall patience (fraction) used once noise has been detected |
| `foc_niche` | `false` | niching: also return the distinct basins found (off by default) |
| `foc_niche_phi` | `2.000` | niching: distance factor of nearest-better clustering |
| `foc_niche_depth` | `0.1000` | niching: basins searched must lie within this fraction of the depth range |
| `foc_niche_max` | `2` | niching: most basins searched after one run |
| `foc_niche_hv` | `3` | niching: interior points of the hill-valley test |
| `foc_niche_giveup` | `2` | niching: stop after this many niche runs end clearly worse than the best |
| `foc_niche_archive` | `3000` | niching: archive length (best sample of each generation) |
| `foc_nbipop` | `false` | NBIPOP restarts: helps on scattered minima without global structure (off by default) |
| `foc_surrogate` | `false` | surrogate pre-screening: about a third of the evaluations on smooth problems (off by default) |
| `foc_sur_tau` | `0.8500` | surrogate: Kendall tau needed to trust the model ranking |
| `foc_sur_kmin` | `2` | surrogate: least best-ranked points evaluated per generation |
| `foc_sur_round` | `1` | surrogate: least points per evaluation round (set to the number of parallel workers) |
| `foc_tol_fun` | `0.000` | stall rule: absolute improvement tolerance, units of f (0 = off) |
| `foc_adaptive` | `0` | experimental gap-adaptive focusing: 0 off, 1-5 variants (leave at 0) |
| `foc_fstar` | `0.000` | experimental gap-adaptive focusing: assumed optimum value (leave at default) |
| `foc_gap_power` | `2.000` | experimental gap-adaptive focusing (leave at default) |
| `foc_dz_max` | `4.000` | experimental gap-adaptive focusing: clamp on one adaptive step (leave at default) |
| `foc_damp` | `0.000` | experimental gap-adaptive focusing: damping of the widening with the budget spent (leave at 0) |
| `foc_scale_c` | `1.000` | experimental gap-adaptive focusing, mode 5: scale factor (leave at default) |
| `foc_scale_clamp` | `4.000` | experimental gap-adaptive focusing (leave at default) |
| `foc_gap_stop` | `false` | end a run that cannot reach target_f within the budget and restart (needs foc_fstar) |
| `foc_gap_window` | `12` | foc_gap_stop: generations of history used |
| `foc_gap_slack` | `1.000` | foc_gap_stop: decades of projected shortfall tolerated |
| `foc_rank_one` | `true` | cumulative rank-one covariance term |
| `foc_mirrored_select` | `false` | keep at most one member of each mirrored pair in the recombination (off by default) |

<!-- /OPTIONS-TABLE -->

---

*fitpar 2.8.1. The sources are in `src` and `app`, the tests in `test`.*
