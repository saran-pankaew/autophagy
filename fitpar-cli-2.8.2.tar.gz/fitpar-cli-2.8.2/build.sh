#!/bin/sh
# ============================================================================
#  Build the fitpar program.
#
#      ./build.sh            build bin/fitpar
#      ./build.sh test       build it and run its tests
#      ./build.sh debug      build it with run-time checks, and run the tests
#      ./build.sh clean      remove what the build made
#
#  The compiler is gfortran, or the first of gfortran-16 ... gfortran-12,
#  gfortran-mp-16 ... (MacPorts), /usr/local/gfortran/bin/gfortran or ifx that
#  is found; choose one with   FC=gfortran-15 ./build.sh
#  Linux and macOS (Apple Silicon and Intel).  The manual: doc/fitpar-manual.pdf
# ============================================================================
set -e
cd "$(dirname "$0")"
MODE=${1:-release}
case "$MODE" in
    clean)  rm -rf build bin; echo "cleaned"; exit 0 ;;
    release|test|debug) ;;
    *)      echo "usage: ./build.sh [test | debug | clean]"; exit 1 ;;
esac

# ---- the compiler -------------------------------------------------------------
if [ -z "$FC" ]; then
    for c in gfortran gfortran-16 gfortran-15 gfortran-14 gfortran-13 gfortran-12 \
             gfortran-mp-16 gfortran-mp-15 gfortran-mp-14 gfortran-mp-13 gfortran-mp-12 \
             /usr/local/gfortran/bin/gfortran ifx; do
        if command -v "$c" > /dev/null 2>&1; then FC=$c; break; fi
    done
fi
if [ -z "$FC" ] || ! command -v "$FC" > /dev/null 2>&1; then
    echo "build.sh: no Fortran compiler found."
    echo "  Install gfortran (manual, section 1: Linux: the gfortran package;"
    echo "  macOS: brew install gcc), or name one:  FC=/path/to/gfortran ./build.sh"
    exit 1
fi
FCVER=$("$FC" --version 2>/dev/null | head -n 1)

mkdir -p build bin
# probe FLAGS...: can the compiler build and link a small program with them?
probe() {
    printf 'program probe\n   print *, 1\nend program probe\n' > build/probe.f90
    ( cd build && "$FC" "$@" probe.f90 -o probe.x ) > /dev/null 2>&1
}
# probe_tuning FLAG: is the processor-tuning FLAG accepted without complaint?
probe_tuning() {
    printf 'program probe\n   print *, 1\nend program probe\n' > build/probe.f90
    ( cd build && "$FC" $FLAGS "$1" -c probe.f90 -o probe.o ) > build/probe.err 2>&1 || return 1
    ! grep -qi -e "${1%%=*}" -e 'unknown' -e 'deprecated' build/probe.err
}

# ---- flags --------------------------------------------------------------------
case "$FCVER" in
    *"GNU Fortran"*)
        if [ "$MODE" = debug ]; then
            FLAGS="-O0 -g -fcheck=all -fbacktrace -ffpe-trap=invalid,zero,overflow -fwrapv"
        else
            FLAGS="-O3 -funroll-loops -fwrapv"
            # tuned for this processor where the compiler can do it (Apple
            # Silicon compilers may not accept -march=native)
            if probe_tuning -march=native; then FLAGS="$FLAGS -march=native"
            elif probe_tuning -mcpu=native; then FLAGS="$FLAGS -mcpu=native"
            fi
        fi
        OMP=-fopenmp ;;
    *ifx*|*ifort*|*Intel*)
        if [ "$MODE" = debug ]; then
            FLAGS="-O0 -g -check all -traceback -fpe0"
        else
            FLAGS="-O2 -fp-model precise"
            if probe_tuning -xHost; then FLAGS="$FLAGS -xHost"; fi
        fi
        OMP=-qopenmp ;;
    *)
        FLAGS="-O2"; OMP=-fopenmp ;;
esac
if probe $FLAGS $OMP; then
    FLAGS="$FLAGS $OMP"; PAR=yes
else
    PAR=no
fi
rm -f build/probe.f90 build/probe.x build/probe.o build/probe.err

# ---- compile: the optimisation modules in dependency order, then the program ---
MODS="fitpar_kinds fitpar_linalg fitpar_rng fitpar_types fitpar_eval fitpar_linesearch
      fitpar_globutil fitpar_local_quasi fitpar_local_dfo fitpar_local_newton fitpar_lsq
      fitpar_lsq_dfogn fitpar_localdisp fitpar_global_de fitpar_global_cmaes
      fitpar_global_swarm fitpar_global_direct fitpar_global_multi fitpar_global_foctopus
      fitpar_global_ga fitpar_global_mac fitpar_local_dfotr fitpar_local_direct_search fitpar"
echo "building fitpar $(cat VERSION 2>/dev/null)"
echo "  compiler: $FC ($FCVER)"
echo "  flags   : $FLAGS"
OBJS=""
cd build                        # module files land here with every compiler
for m in $MODS; do
    "$FC" $FLAGS -I. -c "../src/$m.f90" -o "$m.o" || { echo "build.sh: src/$m.f90 did not compile"; exit 1; }
    OBJS="$OBJS $m.o"
done
for m in fitpar_option_keys fitpar_app; do
    "$FC" $FLAGS -I. -c "../app/$m.f90" -o "$m.o" || { echo "build.sh: app/$m.f90 did not compile"; exit 1; }
    OBJS="$OBJS $m.o"
done
"$FC" $FLAGS -I. ../app/main.f90 $OBJS -o ../bin/fitpar || { echo "build.sh: linking failed"; exit 1; }
cd ..
echo "  built   : bin/fitpar"
if [ "$PAR" = no ]; then
    echo "  note    : no OpenMP with this compiler; parallel = true runs one evaluation at a time"
fi

# ---- tests --------------------------------------------------------------------
if [ "$MODE" = test ] || [ "$MODE" = debug ]; then
    echo
    sh test/test_standalone.sh bin/fitpar
fi
echo
echo "Run it as  bin/fitpar input.inp,  or put it on your PATH:"
echo "  export PATH=\"$(pwd)/bin:\$PATH\""
