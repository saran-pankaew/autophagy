# Examples of the standalone program `fitpar`

Build first (`./build.sh` in the fitpar folder gives `bin/fitpar`), then run an
example in its folder:

    cd 3-curve-fit
    ../../bin/fitpar fit.inp

| Folder | What it shows |
|---|---|
| `1-builtin` | the input file, a built-in test function |
| `2-own-objective` | your own objective in a Python script |
| `3-curve-fit` | a curve fitted to data, with uncertainties and correlations |
| `4-arrhenius` | residuals from the script, a log-scaled and a fixed parameter |
| `5-existing-program` | a program with its own input/output format: template + extractor |
| `6-parallel-global` | a trap for local methods, a global search, parallel evaluations |
| `7-boolean-network` | rates of a stochastic Boolean network (MaBoSS) fitted to cell fractions |

Examples 2-7 need Python 3 (`python3`; on Windows change it to `python` in
`fit.inp`), and example 7 also MaBoSS (`pip install cmaboss`). Every example
is explained, with its output, in `doc/fitpar-manual.pdf`, section 2.
