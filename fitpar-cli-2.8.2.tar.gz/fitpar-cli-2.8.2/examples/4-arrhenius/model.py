# Residuals (ln k_model - ln k_measured) / 0.10 for every row of rates.dat.
import math
R = 8.314462618e-3                                   # kJ mol-1 K-1
p = {name: float(value) for name, value in (line.split() for line in open('params.txt'))}
with open('result.txt', 'w') as out:
    for line in open('rates.dat'):
        if line.startswith('#'):
            continue
        T, k = map(float, line.split()[:2])
        lnk_model = math.log(p['A']) + p['n'] * math.log(T) - p['Ea'] / (R * T)
        out.write(f'{(lnk_model - math.log(k)) / 0.10!r}\n')
