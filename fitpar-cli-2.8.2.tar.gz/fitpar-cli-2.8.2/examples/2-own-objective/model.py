# Himmelblau's function: four minima, all with f = 0.
# Read the parameters fitpar wrote, write the objective where fitpar reads it.
p = {name: float(value) for name, value in (line.split() for line in open('params.txt'))}
x, y = p['x'], p['y']
f = (x**2 + y - 11)**2 + (x + y**2 - 7)**2
open('result.txt', 'w').write(f'{f!r}\n')
