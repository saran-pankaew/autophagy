# Simulate the cell-fate network with MaBoSS (pip install cmaboss) and write
# the fractions of cells in the fates listed in FATES, one per line, in the
# order of the data in fit.inp.
#     python3 simulate.py       reads cellfate.bnd and cellfate.cfg
import cmaboss

FATES = ['apoptosis', 'autophagy']        # add 'survival' if it was measured on its own

sim = cmaboss.MaBoSSSim(network='cellfate.bnd', config='cellfate.cfg')
probs, times, states = sim.run(only_last_state=True).get_last_probtraj()
fraction = {'apoptosis': 0.0, 'autophagy': 0.0, 'survival': 0.0}
for state, p in zip(states, probs[0]):
    on = state.split(' -- ')                  # the reported nodes that are on
    if 'Caspase' in on:
        fraction['apoptosis'] += p            # caspase active: apoptotic
    elif 'Autophagy' in on:
        fraction['autophagy'] += p
    else:
        fraction['survival'] += p             # '<nil>': neither
with open('result.txt', 'w') as out:
    for fate in FATES:
        out.write(f'{float(fraction[fate])!r}\n')
