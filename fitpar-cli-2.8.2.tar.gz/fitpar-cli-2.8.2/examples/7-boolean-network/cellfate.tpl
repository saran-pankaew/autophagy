// MaBoSS configuration of cellfate.bnd.  This is a template: fitpar writes it
// to cellfate.cfg with the current values in place of {k_casp}, {k_auto}, {k_jnk}.
$k_casp = {k_casp};
$k_auto = {k_auto};
$k_jnk  = {k_jnk};

// the cells start unstressed and are stressed (treated) at time 0
Stress.istate = 1;
mTOR.istate = 1;
JNK.istate = 0;
BCL2.istate = 1;
ULK1.istate = 0;
Beclin1.istate = 0;
Autophagy.istate = 0;
BAX.istate = 0;
Caspase.istate = 0;

// only Caspase (apoptosis) and Autophagy are reported
Stress.is_internal = 1;
mTOR.is_internal = 1;
JNK.is_internal = 1;
BCL2.is_internal = 1;
ULK1.is_internal = 1;
Beclin1.is_internal = 1;
BAX.is_internal = 1;

max_time = 6;              // the time of the measurement, in the model's time unit
time_tick = 0.5;
sample_count = 10000;      // simulated cells: Monte Carlo error sqrt(p(1-p)/10000) < 0.005
seed_pseudorandom = 1;     // the same random numbers at every evaluation
discrete_time = 0;
use_physrandgen = 0;
thread_count = 1;
statdist_traj_count = 0;
display_traj = 0;
