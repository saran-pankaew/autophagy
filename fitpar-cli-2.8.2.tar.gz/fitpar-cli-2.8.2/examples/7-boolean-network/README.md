# Example 7: rates of a stochastic Boolean network, fitted to cell fractions

A Boolean network decides the fate of a cell — here apoptosis, autophagy or
survival after a stress. Simulated stochastically for many cells, it gives the
fraction of cells in each fate, and those fractions can be fitted to the
fractions measured (for example by flow cytometry). `fitpar` varies the rates
of the network until the simulated fractions match the measured ones, and
reports the rates with their uncertainties.

## Run it

    pip install cmaboss        # MaBoSS, the simulator, as a Python package
    fitpar fit.inp             # or ../../bin/fitpar fit.inp

| File | What it is |
|---|---|
| `cellfate.bnd` | the network in MaBoSS format: logical rules and the rate of each switch |
| `cellfate.tpl` | the MaBoSS configuration, with `{k_casp}`, `{k_auto}`, `{k_jnk}` where the rates go |
| `simulate.py` | runs MaBoSS for 10 000 cells and writes the fractions of apoptotic and autophagic cells |
| `fit.inp` | the fit: the command, the data, the rates to fit |

The network is a toy, made up for this example: stress switches mTOR off and
JNK on; ULK1 and Beclin-1 start autophagy unless BCL2 holds Beclin-1 back;
BAX and caspases start apoptosis; caspases cleave Beclin-1, and autophagy
holds caspase activation back, so a cell ends in one fate or the other.

## What comes out

    chi2        : 0.000000000000E+00
    dof         : 0      (as many data values as free parameters)

    parameter         value                +/- 1 sigma             note
    k_casp            4.969806607430E-01   x/ 1.3  (log10 0.114)
    k_auto            5.087799542361E-01   x/ 1.385  (log10 0.141)
    k_jnk             1.000000000000E+00                           fixed

    correlation matrix of the free parameters
    k_casp             1.000
    k_auto             0.914  1.000

Two rates, two data values: the model can match the data exactly, so chi2 is
0 and the uncertainties come from the measured SD alone. They are factors:
`k_casp` = 0.50 times or divided by 1.3. The correlation of 0.91 says the data
fix the two rates together much better than each alone (a faster caspase
activation can be partly made up by a faster autophagy). A finite-difference
check with a million simulated cells gave factors of 1.25 and 1.35 and a
correlation of 0.89.

## How many parameters can three values determine?

**Three fractions of one population add up to 1.** If the 3 values are the
fractions of apoptotic, autophagic and surviving cells of the same sample,
the third follows from the other two: there are **2 independent values**, and
they can determine **at most 2 parameters**. That is why `fit.inp` fits
`apoptosis` and `autophagy` only, and keeps `k_jnk` fixed.

- Put all three in the `data` block (and `'survival'` in `FATES` in
  `simulate.py`), and `fitpar` notes that they add up to 1. The fit is the
  same, but the uncertainties come out too small — ×/1.17 and ×/1.22 instead
  of ×/1.30 and ×/1.39 — because the third value is counted as new
  information.
- Free `k_jnk` as well, and every rate is marked `undetermined`, with a
  warning that the data cannot determine them all: the rates `fitpar` returns
  are then one of many equally good fits.

**Three independent values** — measured with different assays, in different
samples, or under different conditions — can determine up to 3 parameters.
Then list all of them in `data`, and let `simulate.py` write the same values
in the same order.

**To determine more parameters, add conditions.** The proportions under a
second dose, at a second time point, or in a knock-down give new data for
the same rates. Simulate each condition in `simulate.py` (a different
`max_time`, an input node switched on or off, a node fixed by
`mutate` in MaBoSS) and append its values to `result.txt`; the `data` block
takes any number of rows.

Fit the rates that matter most for the measured fates and fix the others at
values from the literature, or at 1 (MaBoSS's default rate).

## Randomness

A stochastic simulation gives slightly different fractions every time. Two
settings in `cellfate.tpl` keep that from disturbing the fit:

- `seed_pseudorandom = 1`: every evaluation uses the same random numbers, so
  the same rates give the same fractions, and a small change of a rate gives
  a small change of the fractions.
- `sample_count = 10000`: the Monte Carlo error of a fraction p is
  sqrt(p(1-p)/10000), at most 0.005 — small against the measured SD (0.03).
  With fewer cells, add it to the SD: sigma = sqrt(SD² + p(1-p)/N).

## Your own model

**A MaBoSS model** (`.bnd` and `.cfg`; GINsim and the CoLoMoTo tools export
this format):

1. Copy your `.cfg` to a template, `model.tpl`, and replace each value to fit
   by its name in braces: `$k_casp = 1;` becomes `$k_casp = {k_casp};`. The
   rate parameters (`$name`) of the `.cfg` are the usual ones to fit.
2. In `simulate.py`, set the file names and the node names that define each
   fate (here: `Caspase` on is apoptotic, `Autophagy` on and `Caspase` off is
   autophagic), and set `max_time` in the template to the time of the
   measurement.
3. In `fit.inp`, set `params_file` and `template_file`, the data (fraction
   and SD of each fate) and the parameters: rates are positive and span
   orders of magnitude, so give them bounds and the flag `log`.

**Another simulator** works the same way: the command only has to write the
fractions to `result.txt`, one per line, in the order of the data. For
BoolNet in R: `command = Rscript simulate.R`; for your own Python code,
`command = python3 mymodel.py`.

**Which method.** The default for `mode = model` is `dfogn`, a local method;
for two or three rates and a sensible start it is usually enough (25
evaluations here). If the result depends on the start values, or a rate ends
at a bound, use a global search over the bounds:

    method    = foctopus
    max_feval = 1000
    parallel  = true          # several MaBoSS runs at once
    copy_files = cellfate.bnd simulate.py

The global search is followed by a polish with `dfogn`, which gives the
uncertainties.
