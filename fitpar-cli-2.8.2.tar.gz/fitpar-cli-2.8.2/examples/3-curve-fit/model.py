# Model y(t) = A exp(-k t) + c, evaluated at the t values of decay.dat.
import math
p = {name: float(value) for name, value in (line.split() for line in open('params.txt'))}
t = [float(line.split()[0]) for line in open('decay.dat') if not line.startswith('#')]
with open('result.txt', 'w') as out:
    for ti in t:
        out.write(f"{p['A'] * math.exp(-p['k'] * ti) + p['c']!r}\n")
