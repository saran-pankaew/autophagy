# A Gaussian peak on a flat background, at the x values of spectrum.dat:
#     y = height exp(-((x - center) / width)**2 / 2) + background
# fitpar writes params.txt and reads result.txt.
import math

p = {name: float(value) for name, value in (line.split() for line in open('params.txt'))}
xs = [float(line.split()[0]) for line in open('spectrum.dat') if not line.startswith('#')]
with open('result.txt', 'w') as f:
    for x in xs:
        y = p['height'] * math.exp(-0.5 * ((x - p['center']) / p['width'])**2) + p['background']
        f.write(f'{y!r}\n')
