! reactor simulation input (template: fitpar puts the numbers in place of the names in braces)
PRE-EXPONENTIAL      {A}        ! 1/s
ACTIVATION-ENERGY    {Ea}       ! kJ/mol
RESIDENCE-TIME       1.0        ! s
TEMPERATURES         850 875 900 925 950 975 1000 1025 1050
END
