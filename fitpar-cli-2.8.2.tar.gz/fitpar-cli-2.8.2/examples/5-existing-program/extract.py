# Take the "remaining" column out of the simulator's output and write it,
# one number per line, to result.txt, where fitpar reads the model values.
rows = []
in_table = False
for line in open('reactor.out'):
    words = line.split()
    if words[:3] == ['T/K', 'k/(1/s)', 'remaining']:
        in_table = True
    elif in_table and len(words) == 3:
        rows.append(words[2])
    elif in_table and not words:
        break
open('result.txt', 'w').write('\n'.join(rows) + '\n')
