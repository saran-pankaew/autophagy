# A stand-in for an existing simulation program that you cannot (or do not
# want to) change.  It has its own input format and its own output format:
#
#     python3 simulate.py reactor.inp reactor.out
#
# It models a plug-flow reactor in which a species decomposes with a
# first-order rate constant k = A exp(-Ea / (R T)), and prints the fraction
# that is left after the residence time at each temperature.
import math
import sys

inp, out = sys.argv[1], sys.argv[2]
setting = {}
temperatures = []
for line in open(inp):
    line = line.split('!')[0].strip()          # "!" starts a comment
    if not line or line.upper() == 'END':
        continue
    key, *values = line.split()
    if key.upper() == 'TEMPERATURES':
        temperatures += [float(v) for v in values]
    else:
        setting[key.upper()] = float(values[0])

A = setting['PRE-EXPONENTIAL']        # 1/s
Ea = setting['ACTIVATION-ENERGY']     # kJ/mol
tau = setting['RESIDENCE-TIME']       # s
R = 8.314462618e-3                    # kJ/(mol K)

with open(out, 'w') as f:
    f.write(' PLUG-FLOW REACTOR, FIRST-ORDER DECOMPOSITION\n')
    f.write(f' A = {A:.6e} 1/s   Ea = {Ea:.4f} kJ/mol   tau = {tau} s\n\n')
    f.write('     T/K        k/(1/s)      remaining\n')
    for T in temperatures:
        k = A * math.exp(-Ea / (R * T))
        f.write(f' {T:9.2f}  {k:13.6e}  {math.exp(-k * tau):13.6e}\n')
    f.write('\n NORMAL TERMINATION\n')
