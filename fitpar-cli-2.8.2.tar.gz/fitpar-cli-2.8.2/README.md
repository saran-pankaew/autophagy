# fitpar 2.8.2

Fit the parameters of any program from the command line.

You describe the fit in a short input file: the command that computes the
model (a Python script, a simulation code, anything that runs in a terminal),
the parameters with their limits, and the data to compare with. `fitpar`
runs the command for every trial point and reports the best parameters with
their uncertainties and correlations.

## Build

    ./build.sh          # Linux and macOS; needs gfortran (manual, section 1)
    ./build.sh test     # ... and run the tests

The program is `bin/fitpar`.

## Try it

    cd examples/3-curve-fit
    ../../bin/fitpar fit.inp

## Manual

`doc/fitpar-manual.pdf`: seven worked examples first, then the reference.
The same text is in `doc/fitpar-manual.md`; `doc/fitpar-manual.tex` is its
LaTeX source (`xelatex fitpar-manual`, twice).

## What is where

| | |
|---|---|
| `build.sh` | the build |
| `bin/` | the program, after the build |
| `doc/` | the manual |
| `examples/` | the seven examples of the manual |
| `src/`, `app/` | the Fortran sources |
| `test/` | the tests (`./build.sh test`) |
