!> FitPar -- real-coded genetic algorithm.
!>
!> Tournament selection, simulated binary crossover (SBX) and polynomial
!> mutation, with elitism.  This is the continuous-variable GA of Deb and
!> Agrawal, not a binary-string GA: encoding real parameters as bit strings
!> imposes an arbitrary resolution and destroys locality, and on the kind of
!> parameter-fitting problem this library targets that costs more than the
!> operators gain.
!>
!> SBX produces two children distributed around the parents with a spread
!> controlled by ga_eta_c: large values concentrate the children near the
!> parents, small values spread them out.  Polynomial mutation does the same
!> around a single point.  Both respect the box exactly, so no repair or
!> penalty is needed.
!>
!> A GA is included here for comparison rather than recommendation: on smooth
!> or ill-conditioned problems the differential-evolution and CMA-ES methods
!> in this library dominate it, and the benchmark tables in the manual say so.
!> It earns its place because the published mechanism-optimisation literature
!> uses one, and a comparison needs the method it actually used.
module fitpar_global_ga
   use fitpar_kinds
   use fitpar_types
   use fitpar_eval
   use fitpar_rng
   use fitpar_globutil
   implicit none
   private
   public :: solve_ga

   real(wp), parameter :: eta_c = 15.0_wp     !< SBX distribution index
   real(wp), parameter :: eta_m = 20.0_wp     !< mutation distribution index

contains

   subroutine solve_ga(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      type(rng_t) :: rng
      real(wp), allocatable :: lb(:), ub(:), pop(:, :), fit(:), kid(:, :), fkid(:)
      integer, allocatable  :: ord(:)
      real(wp) :: pcross, pmut, spread
      integer  :: n, np, nelite, gen, i, j, k, a, b, i1, i2

      n = p%n
      call get_box(p, x, lb, ub)
      call rng%seed(o%seed)
      np = o%popsize
      if (np <= 0) np = max(20, min(200, 10 * n))
      if (mod(np, 2) /= 0) np = np + 1
      nelite = max(1, nint(o%ga_elite * real(np, wp)))
      pcross = o%ga_pcross
      pmut = o%ga_pmut
      if (pmut <= zero) pmut = one / real(n, wp)

      allocate (pop(n, np), fit(np), kid(n, np), fkid(np), ord(np))
      call sample_lhs(rng, lb, ub, pop)
      pop(:, 1) = x
      call p%clip(pop(:, 1))
      call ev%fbatch(pop, fit)
      res%status = OPT_MAX_FEVAL

      do gen = 1, o%max_iter
         if (ev%stop_flag) then
            res%status = ev%stop_code; exit
         end if
         call rank_index(fit, ord)

         ! --- elitism: the best few survive untouched ------------------------
         do k = 1, nelite
            kid(:, k) = pop(:, ord(k))
         end do

         ! --- selection, crossover, mutation ---------------------------------
         k = nelite
         do while (k < np)
            a = tournament(rng, fit, o%ga_tournament)
            b = tournament(rng, fit, o%ga_tournament)
            i1 = k + 1; i2 = min(k + 2, np)
            kid(:, i1) = pop(:, a)
            kid(:, i2) = pop(:, b)
            if (rng%uniform() < pcross) &
               call sbx(rng, pop(:, a), pop(:, b), lb, ub, kid(:, i1), kid(:, i2))
            call mutate(rng, kid(:, i1), lb, ub, pmut)
            if (i2 > i1) call mutate(rng, kid(:, i2), lb, ub, pmut)
            k = k + 2
         end do

         call ev%fbatch(kid, fkid)
         pop = kid; fit = fkid

         spread = maxval(fit) - minval(fit)
         if (o%verbose >= 2 .and. mod(gen - 1, max(1, o%print_every)) == 0) &
            write (o%unit, '(a,i6,a,i8,a,es20.12,a,es11.3)') '  gen ', gen, &
            '  nf ', ev%nfev, '  f ', minval(fit), '  spread ', spread
         if (spread <= o%tol_f * (abs(minval(fit)) + o%tol_f)) then
            res%status = OPT_CONV_F; exit
         end if
      end do

      res%x = ev%xbest; res%f = ev%fbest; res%niter = gen
      if (allocated(res%g)) deallocate (res%g)
      allocate (res%g(n)); res%g = zero
   end subroutine solve_ga

   !> Tournament selection: the best of ntour uniformly drawn candidates.
   integer function tournament(rng, fit, ntour)
      type(rng_t), intent(inout) :: rng
      real(wp), intent(in) :: fit(:)
      integer, intent(in)  :: ntour
      integer :: i, c, nt
      nt = max(2, ntour)
      tournament = rng%randint(1, size(fit))
      do i = 2, nt
         c = rng%randint(1, size(fit))
         if (fit(c) < fit(tournament)) tournament = c
      end do
   end function tournament

   !> Simulated binary crossover, bounded variant (Deb & Agrawal 1995).
   subroutine sbx(rng, pa, pb, lb, ub, ca, cb)
      type(rng_t), intent(inout) :: rng
      real(wp), intent(in)  :: pa(:), pb(:), lb(:), ub(:)
      real(wp), intent(out) :: ca(:), cb(:)
      integer  :: j
      real(wp) :: u, beta, alpha, betaq, y1, y2, lo, hi
      do j = 1, size(pa)
         ca(j) = pa(j); cb(j) = pb(j)
         if (rng%uniform() > half) cycle
         if (abs(pa(j) - pb(j)) <= 1.0e-14_wp) cycle
         y1 = min(pa(j), pb(j)); y2 = max(pa(j), pb(j))
         lo = lb(j); hi = ub(j)
         u = rng%uniform()
         ! child 1
         beta = one + two * (y1 - lo) / max(y2 - y1, opt_tiny)
         alpha = two - beta**(-(eta_c + one))
         if (u <= one / alpha) then
            betaq = (u * alpha)**(one / (eta_c + one))
         else
            betaq = (one / max(two - u * alpha, opt_tiny))**(one / (eta_c + one))
         end if
         ca(j) = half * ((y1 + y2) - betaq * (y2 - y1))
         ! child 2
         beta = one + two * (hi - y2) / max(y2 - y1, opt_tiny)
         alpha = two - beta**(-(eta_c + one))
         if (u <= one / alpha) then
            betaq = (u * alpha)**(one / (eta_c + one))
         else
            betaq = (one / max(two - u * alpha, opt_tiny))**(one / (eta_c + one))
         end if
         cb(j) = half * ((y1 + y2) + betaq * (y2 - y1))
         ca(j) = min(max(ca(j), lo), hi)
         cb(j) = min(max(cb(j), lo), hi)
         if (rng%uniform() < half) then
            u = ca(j); ca(j) = cb(j); cb(j) = u
         end if
      end do
   end subroutine sbx

   !> Polynomial mutation, bounded (Deb & Goyal 1996).
   subroutine mutate(rng, c, lb, ub, pmut)
      type(rng_t), intent(inout) :: rng
      real(wp), intent(inout) :: c(:)
      real(wp), intent(in)    :: lb(:), ub(:), pmut
      integer  :: j
      real(wp) :: u, dx, d1, d2, dq, span
      do j = 1, size(c)
         if (rng%uniform() >= pmut) cycle
         span = ub(j) - lb(j)
         if (span <= zero) cycle
         d1 = (c(j) - lb(j)) / span
         d2 = (ub(j) - c(j)) / span
         u = rng%uniform()
         if (u <= half) then
            dq = (two * u + (one - two * u) * (one - d1)**(eta_m + one))**(one / (eta_m + one)) - one
         else
            dq = one - (two * (one - u) + two * (u - half) * (one - d2)**(eta_m + one))**(one / (eta_m + one))
         end if
         c(j) = min(max(c(j) + dq * span, lb(j)), ub(j))
      end do
   end subroutine mutate

end module fitpar_global_ga
