!> FitPar -- MAC: moment-adaptive covariance search.
!>
!> Tibor Nagy's successor to FOCTOPUS.  Where FOCTOPUS keeps one incumbent and
!> a zoom counter, MAC keeps a weighted *archive*: every point ever evaluated
!> carries a Boltzmann weight
!>
!>       w_i  proportional to  exp(-gamma (f_i - f_min)),
!>
!> and the sampling distribution for the next batch is the weighted mean and
!> weighted covariance of the whole archive.  The inverse temperature gamma is
!> not a schedule: it is solved for at each iteration so that the effective
!> sample size, ESS = 1/sum(w^2), hits a target.  That is the adaptive
!> tempering of sequential Monte Carlo, and it is what makes the method
!> invariant to the scale of the objective -- gamma simply moves to whatever
!> value the current spread of f requires.
!>
!> Three differences from the original standalone implementation, each one
!> measured rather than assumed (see the manual, section 5.5):
!>
!>   1. The ESS target is an absolute count, not a fraction of the archive.
!>      With a fraction, the target grows as the archive grows, so the
!>      distribution is forced to average over an ever larger part of its own
!>      history and can never focus; the uploaded version reaches 3e-10 on
!>      sphere-10 and does not converge on anything harder.
!>   2. The archive is windowed.  Points older than mac_window batches are
!>      dropped, which bounds the per-iteration cost at O(window * n^2) instead
!>      of letting it grow without limit, and stops ancient points from
!>      dragging the mean.
!>   3. The batch size is constant, not growing linearly with the iteration
!>      count.  Linear growth spends the last iterations on batches of a
!>      thousand points, which is where most of the budget went.
!>
!> The Boltzmann weighting itself is kept: it is the feature that separates
!> MAC from the rank-weighted evolution strategies, and it is what lets the
!> method exploit *how much* better a point is, not merely that it is better.
module fitpar_global_mac
   use fitpar_kinds
   use fitpar_types
   use fitpar_eval
   use fitpar_linalg
   use fitpar_rng
   use fitpar_globutil
   implicit none
   private
   public :: solve_mac

contains

   subroutine solve_mac(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      type(rng_t) :: rng
      real(wp), allocatable :: lb(:), ub(:), arc(:, :), arcy(:, :), fa(:), w(:)
      real(wp), allocatable :: u(:), unew(:), uold(:), s(:, :), cov(:, :), covold(:, :)
      real(wp), allocatable :: xi(:), pt(:), batch(:, :), fb(:), bury(:, :)
      integer  :: n, lam, cap, na, iter, i, j, k, info, window, kb
      real(wp) :: gamma, ess, target_ess, floor_s, step, span, blend, smooth
      real(wp) :: sig, cs, ds, chin
      real(wp), allocatable :: s0(:, :), ps(:), dm(:), wv(:)

      n = p%n
      call get_box(p, x, lb, ub)
      call rng%seed(o%seed)

      lam = o%mac_batch
      if (lam <= 0) lam = max(4, 2 + int(two * log(real(max(n, 2), wp))))
      window = o%mac_window
      if (window <= 0) window = max(8, 4 + int(three * log(real(max(n, 2), wp))))
      cap = lam * window
      target_ess = o%mac_ess
      ! An absolute elite count, not a fraction of the archive: with a
      ! fraction the elite set grows with the window, and the mean becomes an
      ! average over an ever wider part of the search's own past.
      if (target_ess <= zero) target_ess = max(3.0_wp, half * real(lam, wp))
      target_ess = min(target_ess, real(cap, wp))
      blend = o%mac_blend
      smooth = o%mac_smooth
      span = maxval(ub - lb)
      if (span <= zero .or. span >= opt_huge) span = max(one, maxval(abs(x)))

      allocate (arc(n, cap), arcy(n, cap), fa(cap), w(cap), u(n), unew(n), uold(n), xi(n), pt(n))
      allocate (s(n, n), cov(n, n), covold(n, n), batch(n, lam), fb(lam), bury(n, lam))
      allocate (s0(n, n), ps(n), dm(n), wv(n))

      u = min(max(x, lb), ub)
      ! shape (s0, unit scale) and scale (sig) are carried separately
      s0 = zero
      sig = o%mac_sigma0 * span
      do j = 1, n
         s0(j, j) = (ub(j) - lb(j)) / span
         if (s0(j, j) <= zero) s0(j, j) = one
      end do
      s = sig * s0
      ps = zero
      chin = sqrt(real(n, wp)) * (one - one / (4.0_wp * n) + one / (21.0_wp * n * n))
      cs = 4.0_wp / real(n + 4, wp)
      ds = one + cs
      na = 0
      gamma = o%mac_gamma0
      res%status = OPT_MAX_FEVAL

      do iter = 1, o%max_iter
         if (ev%stop_flag) then
            res%status = ev%stop_code; exit
         end if

         ! --- draw and evaluate one batch ------------------------------------
         do k = 1, lam
            do j = 1, n
               xi(j) = rng%normal()
            end do
            pt = u + matmul(s, xi)
            call reflect(pt, lb, ub)
            batch(:, k) = pt
            ! record the step normalised by the scale that generated it; the
            ! archive spans several generations, and a step drawn at an older,
            ! larger sigma is not comparable to one drawn now
            bury(:, k) = (pt - u) / sig
         end do
         call ev%fbatch(batch, fb)

         ! --- append to the archive, dropping the oldest batch when full -----
         do k = 1, lam
            if (na < cap) then
               na = na + 1
               arc(:, na) = batch(:, k); arcy(:, na) = bury(:, k); fa(na) = fb(k)
            else
               arc(:, 1:cap - 1) = arc(:, 2:cap)
               arcy(:, 1:cap - 1) = arcy(:, 2:cap)
               fa(1:cap - 1) = fa(2:cap)
               arc(:, cap) = batch(:, k); arcy(:, cap) = bury(:, k); fa(cap) = fb(k)
            end if
         end do

         ! --- temperature: solve ESS(gamma) = target -------------------------
         call solve_gamma(fa, na, target_ess, o%mac_gamma_max, gamma)
         call boltzmann(fa, na, gamma, w, ess)

         ! --- weighted mean, blended towards the archive best ----------------
         uold = u
         unew = zero
         do i = 1, na
            unew = unew + w(i) * arc(:, i)
         end do
         kb = minloc(fa(1:na), dim=1)
         unew = (one - blend) * unew + blend * arc(:, kb)
         call clip_box(unew, lb, ub)

         ! --- covariance from *steps*, with the scale carried separately -----
         !
         ! The original updates the covariance to the weighted covariance of
         ! the archive positions.  That is the cross-entropy update, and it
         ! carries the shape and the scale in one object: the elite spread
         ! shrinks every iteration whether or not the search is making
         ! progress, so the distribution collapses on a schedule rather than
         ! on evidence.  Measured, that is what stops the method on the
         ! ellipsoid -- it collapses before it has learned the anisotropy.
         !
         ! Here the covariance is built from normalised steps y = (x - m)/sig,
         ! so it learns shape only, and the scale sig is adapted separately
         ! from the length of the accumulated mean displacement.  The
         ! Boltzmann weights and the ESS tempering -- what makes this MAC and
         ! not an evolution strategy -- are untouched.
         cov = (one - smooth) * matmul(s0, transpose(s0))
         do i = 1, na
            call outer_update(cov, arcy(:, i), smooth * w(i))
         end do
         floor_s = o%mac_floor
         do j = 1, n
            cov(j, j) = cov(j, j) + floor_s * floor_s
         end do
         call sym_sqrt(cov, s0, info)
         if (info /= 0) then
            s0 = zero
            do j = 1, n
               s0(j, j) = one
            end do
         end if

         ! cumulative step-size adaptation on the whitened mean displacement
         dm = (unew - uold) / sig
         call whiten(s0, dm, wv, info)
         if (info == 0) then
            ps = (one - cs) * ps + sqrt(cs * (two - cs) * max(ess, one)) * wv
            sig = sig * exp(max(-one, min(one, (cs / ds) * (norm2v(ps) / chin - one))))
         end if
         s = sig * s0

         step = norm2v(unew - uold)
         u = unew
         res%niter = iter

         if (o%verbose >= 2 .and. mod(iter - 1, max(1, o%print_every)) == 0) &
            write (o%unit, '(a,i6,a,i8,a,es20.12,a,es10.2,a,f8.1,a,es10.2)') &
            '  it ', iter, '  nf ', ev%nfev, '  f ', ev%fbest, '  gamma ', gamma, &
            '  ess ', ess, '  scale ', sig

         if (step < o%tol_x .and. sig < o%mac_tol_scale * span) then
            res%status = OPT_CONV_X; exit
         end if
      end do

      ! The distribution centre is the method's own answer; it is usually
      ! better than any sampled point, so it is worth the one evaluation.
      if (.not. ev%stop_flag) then
         call clip_box(u, lb, ub)
         step = ev%f(u)
      end if
      res%x = ev%xbest; res%f = ev%fbest
      if (allocated(res%g)) deallocate (res%g)
      allocate (res%g(n)); res%g = zero
   end subroutine solve_mac

   pure subroutine clip_box(v, lb, ub)
      real(wp), intent(inout) :: v(:)
      real(wp), intent(in)    :: lb(:), ub(:)
      v = min(max(v, lb), ub)
   end subroutine clip_box

   !> Reflect into the box.  Reflection avoids the pile-up on the boundary
   !> that clipping produces, which would bias the covariance towards zero
   !> in any direction pressed against a bound.  The loop is bounded: a
   !> degenerate or tiny interval is handled by clipping instead, because
   !> repeated reflection in an interval of zero width does not terminate.
   pure subroutine reflect(v, lb, ub)
      real(wp), intent(inout) :: v(:)
      real(wp), intent(in)    :: lb(:), ub(:)
      integer :: i, it
      real(wp) :: wdt
      do i = 1, size(v)
         wdt = ub(i) - lb(i)
         if (wdt <= zero) then
            v(i) = lb(i); cycle
         end if
         it = 0
         do while (v(i) < lb(i) .or. v(i) > ub(i))
            if (v(i) < lb(i)) v(i) = two * lb(i) - v(i)
            if (v(i) > ub(i)) v(i) = two * ub(i) - v(i)
            it = it + 1
            if (it > 50) then
               v(i) = min(max(v(i), lb(i)), ub(i)); exit
            end if
         end do
      end do
   end subroutine reflect

   !> Boltzmann weights, shifted by the minimum so the exponent cannot overflow.
   pure subroutine boltzmann(f, na, gamma, w, ess)
      real(wp), intent(in)  :: f(:), gamma
      integer, intent(in)   :: na
      real(wp), intent(out) :: w(:), ess
      real(wp) :: fmin, z, ws
      integer  :: i
      fmin = minval(f(1:na))
      w(1:na) = zero
      do i = 1, na
         z = -gamma * (f(i) - fmin)
         if (z > -700.0_wp) w(i) = exp(z)
      end do
      ws = sum(w(1:na))
      if (ws <= zero .or. ws /= ws) then
         i = minloc(f(1:na), dim=1)
         w(1:na) = zero; w(i) = one; ess = one
      else
         w(1:na) = w(1:na) / ws
         ess = one / sum(w(1:na)**2)
      end if
   end subroutine boltzmann

   !> Bisection for the gamma that gives the target ESS.  ESS decreases
   !> monotonically in gamma, from na at gamma = 0 to 1 as gamma grows, so the
   !> bracket is unconditional and thirty bisections are ample.
   pure subroutine solve_gamma(f, na, target, gmax, gamma)
      real(wp), intent(in)    :: f(:), target, gmax
      integer, intent(in)     :: na
      real(wp), intent(inout) :: gamma
      real(wp), allocatable   :: w(:)
      real(wp) :: lo, hi, mid, ess, spread
      integer  :: it
      allocate (w(na))
      spread = maxval(f(1:na)) - minval(f(1:na))
      if (spread <= zero) then
         deallocate (w); return                      ! all equal: gamma is moot
      end if
      lo = zero
      hi = min(gmax, 50.0_wp / spread)               ! ESS(hi) is essentially 1
      call boltzmann(f, na, hi, w, ess)
      if (ess >= target) then
         gamma = hi; deallocate (w); return
      end if
      do it = 1, 40
         mid = half * (lo + hi)
         call boltzmann(f, na, mid, w, ess)
         if (ess < target) then
            hi = mid
         else
            lo = mid
         end if
      end do
      gamma = lo
      deallocate (w)
   end subroutine solve_gamma

   !> Solve s0 * w = d for the whitened displacement (s0 is symmetric PSD).
   subroutine whiten(s0, d, w, info)
      real(wp), intent(in)  :: s0(:, :), d(:)
      real(wp), intent(out) :: w(:)
      integer, intent(out)  :: info
      real(wp), allocatable :: l(:, :)
      integer :: n, j
      n = size(d)
      allocate (l(n, n))
      l = s0
      do j = 1, n
         l(j, j) = l(j, j) + 1.0e-12_wp
      end do
      call cholesky_factor(l, info)
      if (info /= 0) return
      call cholesky_solve(l, d, w)
   end subroutine whiten

   !> Principal square root of a symmetric positive semi-definite matrix.
   subroutine sym_sqrt(a, s, info)
      real(wp), intent(in)  :: a(:, :)
      real(wp), intent(out) :: s(:, :)
      integer, intent(out)  :: info
      real(wp), allocatable :: d(:), v(:, :)
      integer :: n, i
      n = size(a, 1)
      allocate (d(n), v(n, n))
      call jacobi_eigen(a, d, v, info)
      if (info /= 0) return
      s = zero
      do i = 1, n
         call outer_update(s, v(:, i), sqrt(max(d(i), zero)))
      end do
   end subroutine sym_sqrt

end module fitpar_global_mac
