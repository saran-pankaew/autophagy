!> FitPar -- particle swarm optimisation and adaptive simulated annealing.
!>
!> solve_pso : constriction-factor PSO on a ring topology.  The ring (local
!>   best) rather than a global best is deliberate: global-best PSO collapses
!>   onto the first decent basin it finds, which looks like fast convergence
!>   and is in fact premature convergence.  Velocities are clamped and the
!>   walls are absorbing.
!>
!> solve_sa : Corana's adaptive simulated annealing.  The step vector is tuned
!>   per coordinate to hold the acceptance ratio near 0.5, so the method works
!>   without the user guessing a step size, and the temperature schedule is
!>   geometric with a stagnation-based stopping test.  Slow, but it will cross
!>   barriers that gradient and simplex methods cannot, and it tolerates noisy
!>   objectives well.
module fitpar_global_swarm
   use fitpar_kinds
   use fitpar_types
   use fitpar_eval
   use fitpar_rng
   use fitpar_globutil
   implicit none
   private
   public :: solve_pso, solve_sa

contains

   subroutine solve_pso(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      real(wp), allocatable :: pos(:, :), vel(:, :), pbest(:, :), fpbest(:)
      real(wp), allocatable :: fcur(:), lb(:), ub(:), vmax(:)
      integer, allocatable  :: nbest(:)
      real(wp) :: r1, r2, spread
      integer  :: n, np, i, j, k, gen, ibest, nb, idx
      type(rng_t) :: rng

      n = p%n
      call get_box(p, x, lb, ub)
      call rng%seed(o%seed)
      np = o%popsize
      if (np <= 0) np = min(max(4 * n, 25), 100)
      nb = max(1, min(o%pso_neighbours, np / 2))

      allocate (pos(n, np), vel(n, np), pbest(n, np), fpbest(np), fcur(np))
      allocate (vmax(n), nbest(np))
      vmax = half * (ub - lb)

      call sample_lhs(rng, lb, ub, pos)
      pos(:, 1) = x
      call p%clip(pos(:, 1))
      do i = 1, np
         do j = 1, n
            vel(j, i) = (two * rng%uniform() - one) * vmax(j) * 0.1_wp
         end do
      end do
      call ev%fbatch(pos, fcur)
      pbest = pos; fpbest = fcur
      res%status = OPT_MAX_FEVAL

      do gen = 1, o%max_iter
         if (ev%stop_flag) then
            res%status = ev%stop_code; exit
         end if

         ! ring-topology neighbourhood best
         do i = 1, np
            nbest(i) = i
            do k = -nb, nb
               idx = modulo(i - 1 + k, np) + 1
               if (fpbest(idx) < fpbest(nbest(i))) nbest(i) = idx
            end do
         end do

         do i = 1, np
            do j = 1, n
               r1 = rng%uniform(); r2 = rng%uniform()
               vel(j, i) = o%pso_w * vel(j, i) &
                           + o%pso_c1 * r1 * (pbest(j, i) - pos(j, i)) &
                           + o%pso_c2 * r2 * (pbest(j, nbest(i)) - pos(j, i))
               vel(j, i) = max(-vmax(j), min(vmax(j), vel(j, i)))
               pos(j, i) = pos(j, i) + vel(j, i)
               if (pos(j, i) < lb(j)) then          ! absorbing wall
                  pos(j, i) = lb(j); vel(j, i) = zero
               else if (pos(j, i) > ub(j)) then
                  pos(j, i) = ub(j); vel(j, i) = zero
               end if
            end do
         end do

         call ev%fbatch(pos, fcur)
         do i = 1, np
            if (fcur(i) < fpbest(i)) then
               fpbest(i) = fcur(i)
               pbest(:, i) = pos(:, i)
            end if
         end do

         ibest = minloc(fpbest, dim=1)
         spread = maxval(fpbest) - fpbest(ibest)
         if (o%verbose >= 2 .and. mod(gen - 1, max(1, o%print_every)) == 0) &
            write (o%unit, '(a,i6,a,i8,a,es20.12,a,es11.3)') '  gen ', gen, &
            '  nf ', ev%nfev, '  f ', fpbest(ibest), '  spread ', spread
         if (spread <= o%tol_f * (abs(fpbest(ibest)) + o%tol_f)) then
            res%status = OPT_CONV_F; exit
         end if
         if (gen == o%max_iter) res%status = OPT_MAX_ITER
      end do

      res%x = ev%xbest
      res%f = ev%fbest
      res%niter = gen
   end subroutine solve_pso

   !--------------------------------------------------------------------------

   subroutine solve_sa(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      real(wp), allocatable :: lb(:), ub(:), vstep(:), xcur(:), xtry(:), xopt(:)
      real(wp), allocatable :: fstar(:)
      integer, allocatable  :: nacp(:)
      real(wp) :: t, fcur, ftry, fopt, ratio, du, probability
      integer  :: n, i, h, j, k, m, nacc, ntot, ncycle
      integer, parameter :: neps = 4
      real(wp), parameter :: eps_conv = 1.0e-10_wp
      type(rng_t) :: rng

      n = p%n
      call get_box(p, x, lb, ub)
      call rng%seed(o%seed)
      allocate (vstep(n), xcur(n), xtry(n), xopt(n), nacp(n), fstar(neps))
      vstep = half * (ub - lb)
      xcur = x
      call p%clip(xcur)
      fcur = ev%f(xcur)
      xopt = xcur; fopt = fcur
      fstar = opt_huge
      res%status = OPT_MAX_FEVAL

      ! --- temperature calibration: accept ~80% of uphill moves initially ----
      t = o%sa_t0
      if (t <= zero) then
         du = zero
         do k = 1, min(20, max(5, n))
            do i = 1, n
               xtry(i) = lb(i) + rng%uniform() * (ub(i) - lb(i))
            end do
            ftry = ev%f(xtry)
            du = du + abs(ftry - fcur)
         end do
         du = du / real(min(20, max(5, n)), wp)
         t = max(du / log(1.25_wp), 1.0e-8_wp)
      end if

      ncycle = 0
      nacc = 0; ntot = 0
      do m = 1, o%max_iter
         nacp = 0
         do j = 1, o%sa_nt
            do k = 1, o%sa_ns
               do h = 1, n
                  xtry = xcur
                  xtry(h) = xcur(h) + (two * rng%uniform() - one) * vstep(h)
                  if (xtry(h) < lb(h) .or. xtry(h) > ub(h)) &
                     xtry(h) = lb(h) + rng%uniform() * (ub(h) - lb(h))
                  ftry = ev%f(xtry)
                  ntot = ntot + 1
                  if (ftry <= fcur) then
                     xcur = xtry; fcur = ftry
                     nacp(h) = nacp(h) + 1; nacc = nacc + 1
                     if (fcur < fopt) then
                        xopt = xcur; fopt = fcur
                     end if
                  else
                     probability = exp(-(ftry - fcur) / max(t, opt_tiny))
                     if (rng%uniform() < probability) then
                        xcur = xtry; fcur = ftry
                        nacp(h) = nacp(h) + 1; nacc = nacc + 1
                     end if
                  end if
                  if (ev%stop_flag) exit
               end do
               if (ev%stop_flag) exit
            end do
            if (ev%stop_flag) exit

            ! --- Corana step adjustment ------------------------------------
            do i = 1, n
               ratio = real(nacp(i), wp) / real(o%sa_ns, wp)
               if (ratio > 0.6_wp) then
                  vstep(i) = vstep(i) * (one + two * (ratio - 0.6_wp) / 0.4_wp)
               else if (ratio < 0.4_wp) then
                  vstep(i) = vstep(i) / (one + two * (0.4_wp - ratio) / 0.4_wp)
               end if
               vstep(i) = min(vstep(i), ub(i) - lb(i))
               vstep(i) = max(vstep(i), 1.0e-12_wp * max(one, abs(xcur(i))))
            end do
            nacp = 0
         end do

         if (ev%stop_flag) then
            res%status = ev%stop_code; exit
         end if

         ! --- cool -------------------------------------------------------------
         ncycle = ncycle + 1
         fstar(2:neps) = fstar(1:neps - 1)
         fstar(1) = fcur
         if (o%verbose >= 2 .and. mod(m - 1, max(1, o%print_every)) == 0) &
            write (o%unit, '(a,i6,a,i8,a,es20.12,a,es11.3,a,f6.3)') '  cyc ', m, &
            '  nf ', ev%nfev, '  fopt ', fopt, '  T ', t, '  acc ', &
            real(nacc, wp) / real(max(1, ntot), wp)

         if (ncycle >= neps) then
            if (all(abs(fstar - fcur) <= eps_conv * (abs(fcur) + eps_conv)) .and. &
                abs(fcur - fopt) <= eps_conv * (abs(fopt) + eps_conv)) then
               res%status = OPT_CONV_F; exit
            end if
         end if
         t = o%sa_rt * t
         xcur = xopt; fcur = fopt          ! restart the walk from the best point
         nacc = 0; ntot = 0
         if (m == o%max_iter) res%status = OPT_MAX_ITER
      end do

      res%x = ev%xbest
      res%f = ev%fbest
      res%niter = m
   end subroutine solve_sa

end module fitpar_global_swarm
