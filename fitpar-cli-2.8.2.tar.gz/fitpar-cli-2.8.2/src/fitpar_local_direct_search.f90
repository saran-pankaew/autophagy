!> FitPar -- the three remaining MATLAB-Toolbox methods of the comparison
!> study: generalised pattern search (patternsearch), dense BFGS
!> quasi-Newton (fminunc), and active-set SQP (fmincon).
module fitpar_local_direct_search
   use fitpar_kinds
   use fitpar_types
   use fitpar_eval
   use fitpar_linalg
   use fitpar_linesearch
   use fitpar_globutil
   use fitpar_rng
   implicit none
   private
   public :: solve_pattern, solve_bfgs, solve_sqp

contains

   ! =======================================================================
   !> Generalised pattern search.  Poll the 2n coordinate directions at the
   !> current mesh size; on success expand the mesh, on failure contract it.
   !> Convergence follows from the mesh: every poll set positively spans R^n,
   !> so a mesh-local optimum with a vanishing mesh is a Clarke stationary
   !> point -- the guarantee a simplex method does not have.
   !>
   !> With ps_mads = .true. the poll directions are randomly rotated at each
   !> size (mesh-adaptive direct search): the poll set is then asymptotically
   !> dense in the sphere, which lifts the guarantee to non-smooth objectives
   !> and removes the axis bias that hurts GPS on rotated problems.
   !>
   !> A successful direction is tried again immediately (the Hooke-Jeeves
   !> pattern move) before the next poll, which is what makes the method
   !> competitive on the smooth stretches between kinks.
   ! =======================================================================
   subroutine solve_pattern(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      real(wp), allocatable :: lb(:), ub(:), xc(:), xt(:), dirs(:, :), scal(:)
      real(wp), allocatable :: q(:, :), v(:)
      real(wp) :: fc, ft, mesh, mesh0, fbase
      integer  :: n, i, k, iter, nd, isucc
      logical  :: success
      type(rng_t) :: rng

      n = p%n
      call get_box(p, x, lb, ub)
      call rng%seed(o%seed)
      nd = 2 * n
      allocate (xc(n), xt(n), dirs(n, nd), scal(n), q(n, n), v(n))
      xc = min(max(x, lb), ub)
      fc = ev%f(xc)
      scal = ub - lb
      where (scal <= zero .or. scal >= opt_huge) scal = max(one, abs(xc))
      mesh0 = o%ps_mesh
      if (mesh0 <= zero) mesh0 = 0.1_wp
      mesh = mesh0
      res%status = OPT_MAX_FEVAL
      isucc = 0

      do iter = 1, o%max_iter
         if (ev%stop_flag) then
            res%status = ev%stop_code; exit
         end if
         ! --- poll directions ------------------------------------------------
         call poll_set(rng, n, o%ps_mads, q, dirs)
         success = .false.
         fbase = fc
         ! try the previously successful direction first: it is the cheapest
         ! guess available and it is what turns a poll into a pattern move
         if (isucc > 0) then
            xt = min(max(xc + mesh * scal * dirs(:, isucc), lb), ub)
            ft = ev%f(xt)
            if (ft < fc) then
               fc = ft; xc = xt; success = .true.
            end if
         end if
         if (.not. success) then
            do k = 1, nd
               if (ev%stop_flag) exit
               xt = min(max(xc + mesh * scal * dirs(:, k), lb), ub)
               ft = ev%f(xt)
               if (ft < fc) then
                  fc = ft; xc = xt; success = .true.; isucc = k
                  exit                                    ! opportunistic poll
               end if
            end do
         end if

         if (success) then
            mesh = min(two * mesh, one)                   ! expand
         else
            mesh = half * mesh                            ! contract
            isucc = 0
            if (mesh < o%tol_x) then
               res%status = OPT_CONV_X; exit
            end if
         end if
         if (o%verbose >= 2 .and. mod(iter - 1, max(1, o%print_every)) == 0) &
            write (o%unit, '(a,i6,a,i8,a,es20.12,a,es11.3)') '  it ', iter, &
            '  nf ', ev%nfev, '  f ', fc, '  mesh ', mesh
      end do

      res%x = ev%xbest; res%f = ev%fbest; res%niter = iter
      if (allocated(res%g)) deallocate (res%g)
      allocate (res%g(n)); res%g = zero
   end subroutine solve_pattern

   !> 2n poll directions: +/- the columns of an orthogonal matrix, which is
   !> the identity for GPS and a random rotation for MADS.
   subroutine poll_set(rng, n, mads, q, dirs)
      type(rng_t), intent(inout) :: rng
      integer, intent(in)  :: n
      logical, intent(in)  :: mads
      real(wp), intent(out) :: q(:, :), dirs(:, :)
      integer :: i, j, k
      real(wp) :: r
      if (mads) then
         do j = 1, n                                   ! Gram-Schmidt on Gaussians
            do i = 1, n
               q(i, j) = rng%normal()
            end do
            do k = 1, j - 1
               r = dot_product(q(:, k), q(:, j))
               q(:, j) = q(:, j) - r * q(:, k)
            end do
            r = norm2v(q(:, j))
            if (r <= 1.0e-12_wp) then
               q(:, j) = zero; q(j, j) = one
            else
               q(:, j) = q(:, j) / r
            end if
         end do
      else
         q = zero
         do i = 1, n
            q(i, i) = one
         end do
      end if
      do i = 1, n
         dirs(:, 2 * i - 1) = q(:, i)
         dirs(:, 2 * i)     = -q(:, i)
      end do
   end subroutine poll_set

   ! =======================================================================
   !> Dense BFGS quasi-Newton with a strong-Wolfe line search -- the method
   !> behind MATLAB's fminunc('quasi-newton').  The inverse Hessian is carried
   !> explicitly (O(n^2) memory), which is why this is a different method from
   !> the library's L-BFGS-B: it is exact rather than limited-memory, and it
   !> handles bounds only by projection, not by an active-set treatment.
   ! =======================================================================
   subroutine solve_bfgs(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      real(wp), allocatable :: h(:, :), g(:), gn(:), d(:), s(:), yv(:), xn(:), hy(:)
      real(wp), allocatable :: lbx(:), ubx(:)
      real(wp) :: f, fn, alpha, sy, yhy, gnorm
      integer  :: n, i, j, iter, info

      n = p%n
      allocate (h(n, n), g(n), gn(n), d(n), s(n), yv(n), xn(n), hy(n))
      call get_box(p, x, lbx, ubx)
      call p%clip(x)
      call ev%fg(x, f, g)
      h = zero
      do i = 1, n
         h(i, i) = one
      end do
      res%status = OPT_MAX_FEVAL

      do iter = 1, o%max_iter
         ! The convergence test must use the PROJECTED gradient.  The
         ! evaluator clips every point into the box, so once an iterate leaves
         ! it the objective is constant along the offending coordinate and its
         ! finite-difference derivative is exactly zero.  Testing the plain
         ! gradient then reports stationarity at a bound where the true
         ! gradient is large -- measured on a shifted sphere, this stopped the
         ! method after 84 evaluations with f - f* = 15.4 and a success
         ! message.  A component pressed outward against an active bound is
         ! not evidence of a minimum; it is evidence the step left the domain.
         gnorm = zero
         do i = 1, n
            if ((x(i) <= lbx(i) + opt_eps .and. g(i) > zero) .or. &
                (x(i) >= ubx(i) - opt_eps .and. g(i) < zero)) cycle
            gnorm = max(gnorm, abs(g(i)))
         end do
         if (gnorm <= o%tol_g) then
            if (any(x <= lbx + opt_eps) .or. any(x >= ubx - opt_eps)) then
               res%status = OPT_CONV_X      ! stationary only within the box
            else
               res%status = OPT_CONV_G
            end if
            exit
         end if
         if (ev%stop_flag) then
            res%status = ev%stop_code; exit
         end if
         d = -matmul(h, g)
         if (dot_product(d, g) >= zero) then            ! not a descent direction
            h = zero
            do i = 1, n
               h(i, i) = one
            end do
            d = -g
         end if
         alpha = one
         call wolfe_search(ev, x, f, g, d, alpha, xn, fn, gn, info)
         if (info /= 0) then
            res%status = OPT_NUMERICAL; exit
         end if
         xn = min(max(xn, lbx), ubx)        ! stay in the domain the caller gave
         s = xn - x; yv = gn - g
         sy = dot_product(s, yv)
         if (sy > 1.0e-12_wp * max(norm2v(s) * norm2v(yv), opt_tiny)) then
            hy = matmul(h, yv)
            yhy = dot_product(yv, hy)
            ! BFGS update of the inverse Hessian (Sherman-Morrison form)
            do j = 1, n
               do i = 1, n
                  h(i, j) = h(i, j) + ((sy + yhy) * s(i) * s(j)) / sy**2 &
                            - (hy(i) * s(j) + s(i) * hy(j)) / sy
               end do
            end do
         end if
         if (abs(f - fn) <= o%tol_f * (abs(f) + one)) then
            x = xn; f = fn; g = gn
            res%status = OPT_CONV_F; exit
         end if
         x = xn; f = fn; g = gn
      end do

      res%x = ev%xbest; res%f = ev%fbest; res%niter = iter
      res%gnorm = maxval(abs(g))
      if (allocated(res%g)) deallocate (res%g)
      allocate (res%g(n)); res%g = g
   end subroutine solve_bfgs

   ! =======================================================================
   !> Active-set sequential quadratic programming for bound constraints --
   !> the method behind fmincon('active-set') when the only constraints are
   !> the box.  At each iterate the bounds that are active and pushing
   !> outward are fixed, and a BFGS quasi-Newton step is taken in the free
   !> subspace; the active set is re-estimated every iteration.
   !>
   !> With only bounds present the QP subproblem has a closed-form solution
   !> on the free variables, so no inner QP solver is needed.  This is the
   !> honest scope of this routine: it is SQP specialised to a box, not a
   !> general nonlinear-constraint solver.
   ! =======================================================================
   subroutine solve_sqp(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      real(wp), allocatable :: b(:, :), g(:), gn(:), d(:), s(:), yv(:), xn(:)
      real(wp), allocatable :: lb(:), ub(:), bs(:), gf(:), df(:)
      logical, allocatable  :: free(:)
      real(wp) :: f, fn, alpha, sy, sbs, pg, t
      integer  :: n, nf, i, j, k, iter, info

      n = p%n
      call get_box(p, x, lb, ub)
      allocate (b(n, n), g(n), gn(n), d(n), s(n), yv(n), xn(n), free(n))
      x = min(max(x, lb), ub)
      call ev%fg(x, f, g)
      b = zero
      do i = 1, n
         b(i, i) = one                                   ! B approximates the Hessian
      end do
      res%status = OPT_MAX_FEVAL

      do iter = 1, o%max_iter
         if (ev%stop_flag) then
            res%status = ev%stop_code; exit
         end if
         ! --- active set: a bound is active when the gradient pushes outward --
         do i = 1, n
            free(i) = .not. ((x(i) <= lb(i) + opt_eps .and. g(i) > zero) .or. &
                             (x(i) >= ub(i) - opt_eps .and. g(i) < zero))
         end do
         nf = count(free)
         ! projected-gradient convergence test on the free variables
         pg = zero
         do i = 1, n
            if (free(i)) pg = max(pg, abs(g(i)))
         end do
         if (pg <= o%tol_g) then
            res%status = OPT_CONV_G; exit
         end if
         if (nf == 0) then
            res%status = OPT_CONV_X; exit
         end if

         ! --- QP step on the free subspace: B_ff d_f = -g_f --------------------
         allocate (bs(nf * nf), gf(nf), df(nf))
         k = 0
         do j = 1, n
            if (.not. free(j)) cycle
            do i = 1, n
               if (.not. free(i)) cycle
               k = k + 1
               bs(k) = b(i, j)
            end do
         end do
         k = 0
         do i = 1, n
            if (free(i)) then
               k = k + 1; gf(k) = -g(i)
            end if
         end do
         call solve_spd(reshape(bs, [nf, nf]), gf, df, info)
         d = zero
         if (info == 0) then
            k = 0
            do i = 1, n
               if (free(i)) then
                  k = k + 1; d(i) = df(k)
               end if
            end do
         else
            where (free) d = -g                          ! fall back on steepest descent
         end if
         deallocate (bs, gf, df)
         if (dot_product(d, g) >= zero) then
            d = zero
            where (free) d = -g
         end if

         alpha = one
         call wolfe_search(ev, x, f, g, d, alpha, xn, fn, gn, info)
         if (info /= 0) then
            ! A Wolfe search can fail legitimately here: the step runs into a
            ! bound, so the curvature condition is unreachable along d.  That
            ! is a constraint being active, not a numerical breakdown -- fall
            ! back on a projected Armijo step, which the box cannot defeat.
            alpha = one
            call projected_search(ev, p, x, f, g, d, alpha, xn, fn, info)
            if (info /= 0) then
               res%status = OPT_CONV_X; exit
            end if
            call ev%grad(xn, gn)
         end if
         xn = min(max(xn, lb), ub)
         s = xn - x; yv = gn - g
         sy = dot_product(s, yv)
         sbs = dot_product(s, matmul(b, s))
         if (sy > 0.2_wp * sbs .and. sbs > zero) then    ! damped BFGS (Powell)
            do j = 1, n
               do i = 1, n
                  b(i, j) = b(i, j) + yv(i) * yv(j) / sy &
                            - dot_product(b(i, :), s) * dot_product(s, b(:, j)) / sbs
               end do
            end do
         end if
         if (abs(f - fn) <= o%tol_f * (abs(f) + one)) then
            x = xn; f = fn; g = gn
            res%status = OPT_CONV_F; exit
         end if
         x = xn; f = fn; g = gn
      end do

      res%x = ev%xbest; res%f = ev%fbest; res%niter = iter
      res%gnorm = maxval(abs(g))
      if (allocated(res%g)) deallocate (res%g)
      allocate (res%g(n)); res%g = g
   end subroutine solve_sqp

   !> Cholesky solve with a diagonal shift when the matrix is not definite.
   subroutine solve_spd(a, b, x, info)
      real(wp), intent(in)  :: a(:, :), b(:)
      real(wp), intent(out) :: x(:)
      integer, intent(out)  :: info
      real(wp), allocatable :: l(:, :)
      real(wp) :: shift
      integer  :: n, i, k
      n = size(b)
      allocate (l(n, n))
      shift = zero
      do k = 0, 5
         l = a
         do i = 1, n
            l(i, i) = l(i, i) + shift
         end do
         call cholesky_factor(l, info)
         if (info == 0) exit
         shift = max(two * shift, 1.0e-8_wp * max(one, maxval(abs(a))))
      end do
      if (info /= 0) return
      call cholesky_solve(l, b, x)
   end subroutine solve_spd

end module fitpar_local_direct_search
