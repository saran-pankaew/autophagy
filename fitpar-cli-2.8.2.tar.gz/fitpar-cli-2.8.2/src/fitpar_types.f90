!> FitPar -- public data types: problem definition, solver options, results.
module fitpar_types
   use fitpar_kinds
   implicit none
   private

   public :: opt_problem, opt_options, opt_result, opt_context
   public :: opt_fun_i, opt_grad_i, opt_fungrad_i, opt_res_i, opt_jac_i
   public :: status_message, method_id, method_name, is_global_method, mark_undetermined
   public :: OPT_SUCCESS, OPT_CONV_F, OPT_CONV_X, OPT_CONV_G, OPT_CONV_TARGET, &
             OPT_MAX_FEVAL, OPT_MAX_ITER, OPT_MAX_TIME, OPT_STAGNATED, &
             OPT_USER_STOP, OPT_BAD_INPUT, OPT_NUMERICAL
   public :: M_AUTO, M_NELDER_MEAD, M_POWELL, M_LBFGSB, M_TRUST_NCG, M_CG, &
             M_LEVMAR, M_DE, M_PSO, M_CMAES, M_SA, M_DIRECT, M_MLSL, &
             M_MULTISTART, M_BASINHOP, M_FOCTOPUS, M_GA, M_NEWUOA, M_BOBYQA, M_DFOGN, &
             M_PATTERN, M_BFGS, M_SQP, M_MAC

   !--------------------------------------------------------------------------
   ! Exit status codes
   !--------------------------------------------------------------------------
   integer, parameter :: OPT_SUCCESS     = 0   !< generic success
   integer, parameter :: OPT_CONV_F      = 1   !< objective converged
   integer, parameter :: OPT_CONV_X      = 2   !< step length converged
   integer, parameter :: OPT_CONV_G      = 3   !< projected gradient converged
   integer, parameter :: OPT_CONV_TARGET = 4   !< user target value reached
   integer, parameter :: OPT_MAX_FEVAL   = 5   !< evaluation budget exhausted
   integer, parameter :: OPT_MAX_ITER    = 6   !< iteration budget exhausted
   integer, parameter :: OPT_MAX_TIME    = 7   !< wall-clock budget exhausted
   integer, parameter :: OPT_STAGNATED   = 8   !< no progress; give up
   integer, parameter :: OPT_USER_STOP   = -1  !< objective returned ierr /= 0
   integer, parameter :: OPT_BAD_INPUT   = -2  !< malformed problem/options
   integer, parameter :: OPT_NUMERICAL   = -3  !< unrecoverable numerical failure

   !--------------------------------------------------------------------------
   ! Method identifiers
   !--------------------------------------------------------------------------
   integer, parameter :: M_AUTO        = 0
   ! local
   integer, parameter :: M_NELDER_MEAD = 1
   integer, parameter :: M_POWELL      = 2
   integer, parameter :: M_LBFGSB      = 3
   integer, parameter :: M_TRUST_NCG   = 4
   integer, parameter :: M_CG          = 5
   integer, parameter :: M_LEVMAR      = 6
   ! global
   integer, parameter :: M_DE          = 11
   integer, parameter :: M_PSO         = 12
   integer, parameter :: M_CMAES       = 13
   integer, parameter :: M_SA          = 14
   integer, parameter :: M_DIRECT      = 15
   integer, parameter :: M_MLSL        = 16
   integer, parameter :: M_MULTISTART  = 17
   integer, parameter :: M_BASINHOP    = 18
   integer, parameter :: M_FOCTOPUS    = 19
   integer, parameter :: M_GA          = 20
   integer, parameter :: M_MAC         = 26
   ! local methods added after the global block keep their ids above it; the
   ! is_global_method test below is explicit rather than an id comparison.
   integer, parameter :: M_NEWUOA      = 21
   integer, parameter :: M_BOBYQA      = 22
   integer, parameter :: M_PATTERN     = 23
   integer, parameter :: M_BFGS        = 24
   integer, parameter :: M_SQP         = 25
   integer, parameter :: M_DFOGN       = 27

   !> Base type for user data.  Extend it to carry your experimental data,
   !> grids, lookup tables, MPI communicators, ... into the objective without
   !> a single COMMON block or global variable.
   type :: opt_context
      integer :: dummy = 0
   end type opt_context

   type(opt_context), target, save :: default_ctx

   !--------------------------------------------------------------------------
   ! Objective function interfaces
   !--------------------------------------------------------------------------
   abstract interface
      !> Scalar objective:  f = F(x)
      subroutine opt_fun_i(x, f, ctx, ierr)
         import :: wp
         real(wp), intent(in)    :: x(:)
         real(wp), intent(out)   :: f
         class(*), intent(inout) :: ctx
         integer, intent(out)    :: ierr
      end subroutine opt_fun_i

      !> Analytic gradient:  g = dF/dx
      subroutine opt_grad_i(x, g, ctx, ierr)
         import :: wp
         real(wp), intent(in)    :: x(:)
         real(wp), intent(out)   :: g(:)
         class(*), intent(inout) :: ctx
         integer, intent(out)    :: ierr
      end subroutine opt_grad_i

      !> Combined value+gradient (preferred when they share work).
      subroutine opt_fungrad_i(x, f, g, ctx, ierr)
         import :: wp
         real(wp), intent(in)    :: x(:)
         real(wp), intent(out)   :: f, g(:)
         class(*), intent(inout) :: ctx
         integer, intent(out)    :: ierr
      end subroutine opt_fungrad_i

      !> Residual vector for least squares:  r_i = (y_i - model_i)/sigma_i
      subroutine opt_res_i(x, r, ctx, ierr)
         import :: wp
         real(wp), intent(in)    :: x(:)
         real(wp), intent(out)   :: r(:)
         class(*), intent(inout) :: ctx
         integer, intent(out)    :: ierr
      end subroutine opt_res_i

      !> Analytic Jacobian J(i,j) = dr_i/dx_j
      subroutine opt_jac_i(x, jm, ctx, ierr)
         import :: wp
         real(wp), intent(in)    :: x(:)
         real(wp), intent(out)   :: jm(:, :)
         class(*), intent(inout) :: ctx
         integer, intent(out)    :: ierr
      end subroutine opt_jac_i
   end interface

   !--------------------------------------------------------------------------
   ! Problem definition
   !--------------------------------------------------------------------------
   type :: opt_problem
      integer :: n = 0                     !< number of parameters
      integer :: m = 0                     !< number of residuals (0 = not least squares)
      procedure(opt_fun_i), pointer, nopass     :: fun     => null()
      procedure(opt_grad_i), pointer, nopass    :: grad    => null()
      procedure(opt_fungrad_i), pointer, nopass :: fungrad => null()
      procedure(opt_res_i), pointer, nopass     :: res     => null()
      procedure(opt_jac_i), pointer, nopass     :: jac     => null()
      real(wp), allocatable :: lb(:), ub(:) !< box bounds (optional)
      real(wp), allocatable :: xscale(:)    !< typical magnitude of each parameter
      logical, allocatable  :: fixed(:)     !< freeze individual parameters
      class(*), pointer     :: ctx => null()
      character(len=64)     :: name = 'unnamed problem'
   contains
      procedure :: init      => problem_init
      procedure :: bounded   => problem_bounded
      procedure :: is_lsq    => problem_is_lsq
      procedure :: clip      => problem_clip
      procedure :: check     => problem_check
   end type opt_problem

   !--------------------------------------------------------------------------
   ! Solver options.  Every field has a sane default; you normally set three.
   !--------------------------------------------------------------------------
   type :: opt_options
      character(len=24) :: method = 'auto'
      character(len=24) :: local_method = 'lbfgsb'  !< polish / inner solver

      ! --- termination -----------------------------------------------------
      real(wp) :: tol_f     = 1.0e-12_wp   !< relative change in f
      real(wp) :: tol_x     = 1.0e-10_wp   !< relative change in x
      real(wp) :: tol_g     = 1.0e-8_wp    !< inf-norm of (projected) gradient
      integer  :: max_feval = 200000
      integer  :: max_iter  = 20000
      real(wp) :: max_time  = -one         !< seconds; <0 = unlimited
      real(wp) :: target_f  = -opt_huge    !< stop as soon as f <= target_f
      integer  :: stall_iter = 0           !< stop after this many barren iters (0=off)

      ! --- derivatives ------------------------------------------------------
      integer  :: fd_order = 2             !< 1 forward, 2 central, 4 Richardson
      real(wp) :: fd_step  = zero          !< 0 = automatic per-variable step

      ! --- output -----------------------------------------------------------
      !> How many objective evaluations may be in flight at once.  Batch
      !> methods evaluate a generation together, and for a simulation-based
      !> objective that is where the wall-clock time goes.  0 leaves it to the
      !> runtime (OMP_NUM_THREADS); a positive value caps it, which matters
      !> when each evaluation needs memory, a licence or a scratch directory of
      !> its own, or when the machine is shared.  1 forces serial evaluation,
      !> which is also how to get bit-identical runs from an objective that is
      !> not reentrant.
      integer  :: max_concurrent = 0
      integer  :: verbose     = 1          !< 0 silent, 1 summary, 2 iterations, 3 debug
      integer  :: print_every = 1
      integer  :: unit        = output_unit
      character(len=256) :: trace_file = '' !< CSV trace of every iteration

      ! --- stochastic -------------------------------------------------------
      integer(int64) :: seed = 20240101_int64  !< 0 = seed from clock
      integer  :: popsize  = 0             !< 0 = method-specific default
      logical  :: parallel = .false.       !< OpenMP over population members
      integer  :: restarts = 0             !< extra restarts for local methods

      ! --- hybrid -----------------------------------------------------------
      logical  :: polish   = .true.        !< local refinement after a global run
      integer  :: polish_feval = 0         !< 0 = max(500, 20% of max_feval)

      ! --- Nelder-Mead ------------------------------------------------------
      real(wp) :: nm_step = 0.05_wp        !< initial simplex size (relative)
      logical  :: nm_adaptive = .true.     !< dimension-adapted coefficients

      ! --- Levenberg-Marquardt ---------------------------------------------
      real(wp) :: lm_lambda0 = 1.0e-3_wp
      logical  :: lm_scaled  = .true.      !< Marquardt diagonal scaling
      logical  :: lm_covar   = .true.      !< compute covariance / error bars

      ! --- L-BFGS -----------------------------------------------------------
      integer  :: lbfgs_memory = 10

      ! --- Differential Evolution ------------------------------------------
      real(wp) :: de_f  = 0.5_wp
      real(wp) :: de_cr = 0.9_wp
      logical  :: de_adaptive = .true.     !< JADE self-adaptation of F and CR
      real(wp) :: de_pbest = 0.11_wp
      logical  :: de_lpsr = .true.         !< linear population size reduction

      ! --- PSO ---------------------------------------------------------------
      real(wp) :: pso_w = 0.7298_wp, pso_c1 = 1.49618_wp, pso_c2 = 1.49618_wp
      integer  :: pso_neighbours = 3

      ! --- CMA-ES -------------------------------------------------------------
      real(wp) :: cma_sigma0 = 0.3_wp      !< relative to the box width
      logical  :: cma_ipop = .true.        !< restart with doubled population

      ! --- Simulated annealing (Corana) ---------------------------------------
      real(wp) :: sa_t0 = zero             !< 0 = calibrate automatically
      real(wp) :: sa_rt = 0.85_wp
      integer  :: sa_ns = 20, sa_nt = 5

      ! --- DIRECT --------------------------------------------------------------
      real(wp) :: direct_eps = 1.0e-4_wp
      logical  :: direct_local = .false.   !< locally biased variant (DIRECT-L)

      ! --- multistart / MLSL / basin hopping ------------------------------------
      integer  :: ms_points = 0            !< 0 = 10*n
      real(wp) :: bh_step = 0.1_wp         !< basin-hopping perturbation
      real(wp) :: bh_temp = one

      ! --- model-based DFO trust region (NEWUOA / BOBYQA) -----------------------
      real(wp) :: dfo_rhobeg = zero        !< initial trust radius (0 = automatic)
      !> dfogn: number of starts (1; -1 = restart from uniform points in the box
      !> until the budget is spent) and the predicted-gain tolerance, in units of
      !> f = sum(r**2)/2, below which a run ends (0 = off)
      integer  :: dfogn_starts = 1
      real(wp) :: dfogn_pred_tol = zero
      !> dfogn: error bars from differences with steps of about one standard
      !> error (2n to 8n extra evaluations; robust when the model output is
      !> noisy, e.g. printed with few digits); false: from the interpolation
      !> model, with no extra evaluation
      logical  :: dfogn_stats_fd = .true.
      !> dfogn: the change of the residual vector those differences aim at
      !> (0 = sqrt(chi2/dof), or 1 for an exact fit; 1 suits residuals divided
      !> by true standard deviations, and fitpar sets it so for data with sigmas)
      real(wp) :: dfogn_stats_dr = zero
      real(wp) :: dfo_rhoend = zero        !< terminal trust radius (0 = tol_x)

      ! --- pattern search -------------------------------------------------------
      real(wp) :: ps_mesh = 0.1_wp         !< initial mesh size, relative to the box
      logical  :: ps_mads = .false.        !< .true. = randomly rotated poll (MADS)

      ! --- genetic algorithm ----------------------------------------------------
      real(wp) :: ga_pcross = 0.8_wp       !< crossover probability
      real(wp) :: ga_pmut = zero           !< mutation probability (0 = 1/n)
      real(wp) :: ga_elite = 0.05_wp       !< fraction carried over unchanged
      integer  :: ga_tournament = 3        !< tournament size for selection

      ! --- MAC moment-adaptive covariance search --------------------------------
      integer  :: mac_batch = 0            !< batch size (0 = 2 + 2 ln n, min 4)
      integer  :: mac_window = 0           !< archive length in batches (0 = automatic)
      real(wp) :: mac_ess = zero           !< target effective sample size
                                           !< (0 = a quarter of the archive)
      real(wp) :: mac_gamma0 = 1.0e-3_wp   !< initial inverse temperature
      real(wp) :: mac_gamma_max = 1.0e12_wp
      real(wp) :: mac_sigma0 = 0.25_wp     !< initial spread, fraction of the box
      real(wp) :: mac_blend = 0.15_wp      !< pull of the archive best on the mean
      real(wp) :: mac_smooth = 0.20_wp     !< covariance smoothing towards the old
      real(wp) :: mac_floor = 1.0e-9_wp    !< diagonal regularisation of the shape
                                           !< matrix (the shape has unit scale,
                                           !< so this is not a limit on accuracy)
      real(wp) :: mac_tol_scale = 1.0e-12_wp!< terminal scale as a fraction of the
                                           !< box; this is an accuracy limit, so
                                           !< it must sit below the accuracy wanted

      ! --- FOCTOPUS adaptive zoom random search ---------------------------------
      logical  :: foc_classic = .false.    !< .true. = original algorithm (fixed)
      integer  :: foc_nsamp = 0            !< batch size (0 = automatic)
      integer  :: foc_zoom  = 0            !< initial zoom exponent (classic)
      !> Focus steps.  Real, not integer: a half step is a meaningful setting
      !> because the scale moves by lambda**(-z/n) and z need not be whole.
      !> Zoom steps, classic variant only.  With foc_classic = .false. (the
      !> default) cumulative step-size adaptation replaces the counter these
      !> drive and they are never read; setting them changes nothing.
      real(wp) :: foc_zin   = 1.0_wp       !< focus step after a failed batch
      real(wp) :: foc_zout  = 1.0_wp       !< focus step after a successful batch
      integer  :: foc_zmin  = 0            !< widest allowed zoom (classic)
      integer  :: foc_zmax  = 200          !< terminal resolution exponent
                                           !< (legacy floor only)
      !> Terminal search scale as a fraction of the initial spread.  Replaces
      !> the inherited floor sigma0*lambda**(-zmax/n), whose exponent carries a
      !> 1/n: at fixed zmax that floor rises from 5e-7 of the box at n=30 to
      !> 4e-3 at n=65, so the attainable accuracy silently depended on the
      !> number of parameters.  A fixed relative resolution does not.
      real(wp) :: foc_tol_scale = 1.0e-13_wp
      logical  :: foc_legacy_floor = .false. !< restore sigma0*lambda**(-zmax/n)
      real(wp) :: foc_msigma = 3.0_wp      !< box half-width in sigmas
      !> Adaptive restart patience (enhanced path; default on from 2.4.0).
      !> Every foc_noise_every generations a pair at 1/100 of the sampling step
      !> is compared with the batch's own mirrored-pair differences; two alarms
      !> in a row shorten the stall patience to foc_noise_patience.
      logical  :: foc_noise_probe = .true.
      integer  :: foc_noise_every = 0   !< 0: max(5, nint(n/10)) (2.4.1)
      real(wp) :: foc_noise_ratio = 0.5_wp
      real(wp) :: foc_noise_patience = 0.25_wp
      !> Niching (2.5.0; off by default).  An archive keeps each generation's
      !> best sample; when a regular run ends, nearest-better clustering proposes
      !> basins the run passed through, a hill-valley test confirms they are
      !> separate valleys, and the similarly deep ones are searched by local runs
      !> before the usual IPOP restart.  After foc_niche_giveup niche runs that end
      !> clearly worse than the best so far, niching stops.  Distinct run optima
      !> are returned in res%xopt / res%fopt.  Off, none of it runs.
      logical  :: foc_niche = .false.
      real(wp) :: foc_niche_phi = 2.0_wp, foc_niche_depth = 0.1_wp
      integer  :: foc_niche_max = 2, foc_niche_hv = 3, foc_niche_giveup = 2, foc_niche_archive = 3000
      !> NBIPOP restarts (2.6.0; off by default): two interleaved restart regimes,
      !> the one that has used less of its share goes next, and the regime that
      !> found the best point gets twice the other's share.  Small runs: a batch
      !> between lambda0 and half the large one, with a spread 10^(-2u) times the
      !> box-wide one, from a random point.  Helps on landscapes of scattered
      !> minima without global structure; neutral on the main benchmark.
      logical  :: foc_nbipop = .false.
      !> Surrogate pre-screening (2.6.0; off by default), after lq-CMA-ES: a
      !> linear, diagonal-quadratic or full-quadratic model (full up to 1000
      !> coefficients) of the run's evaluated points, whitened by the current
      !> distribution, ranks each batch; the foc_sur_kmin best-ranked (at least a
      !> tenth) are evaluated, more while the model's ranking of recent points
      !> agrees with the true one below Kendall tau foc_sur_tau.  About a third of
      !> the evaluations on the benchmark, a fifth on smooth ill-conditioned
      !> problems.  The noise probe is off under it.
      logical  :: foc_surrogate = .false.
      real(wp) :: foc_sur_tau = 0.85_wp
      integer  :: foc_sur_kmin = 2
      !> least points per surrogate round (set to the number of parallel workers)
      !> and the absolute improvement tolerance of the stall rule (0 = off)
      integer  :: foc_sur_round = 1
      real(wp) :: foc_tol_fun = zero

      !> Gap-adaptive focusing.  When a lower bound f* on the objective is
      !> known -- exactly 0 for a least-squares residual sum, and often known
      !> from physics otherwise -- the objective value is a distance sensor:
      !> near a minimum of order p, f - f* ~ d^p, so the ratio of successive
      !> gaps measures how far the incumbent moved relative to the optimum.
      !> The focus step can then be computed rather than tuned:
      !>
      !>    dz = -(n / (p ln N)) ln( (f_new - f*) / (f_old - f*) )
      !>
      !> foc_adaptive switches this on; foc_fstar is the bound; foc_gap_power
      !> is p (2 for a smooth quadratic minimum, 1 where the minimum is a kink,
      !> as in Ackley or Alpine).  A failed batch carries no distance
      !> information and still uses foc_zin.
      !> 0 off; 3 widen in proportion to the gain (the intended rule: a large
      !> improvement earns a large step back); 1 distance-matched contraction (contracts
      !> monotonically, so it can converge prematurely); 2 the same
      !> contraction on improvement but a widening step on failure, so the
      !> search can still escape.
      integer  :: foc_adaptive = 0
      real(wp) :: foc_fstar = zero
      real(wp) :: foc_gap_power = 2.0_wp
      real(wp) :: foc_dz_max = 4.0_wp      !< clamp on one adaptive step
      !> Damping of the adaptive widening with the budget already spent.
      !> The measured weakness of every gain-proportional rule is that it never
      !> stops widening, so the distribution is still broad when the budget
      !> runs out and the run stops shallow.  Scaling the widening by
      !> (1 - used)**foc_damp turns the rule into the fixed one as the budget
      !> is consumed: exploratory early, unconditional contraction late.
      !> 0 disables the damping.
      real(wp) :: foc_damp = zero
      !> Mode 5 sets the scale absolutely instead of stepping it.  From the
      !> batch we measure D, the typical change in f produced by a step of the
      !> current size, and we know the gap g = f - f*.  For a locally
      !> quadratic objective f - f* ~ kappa d^2 and D ~ kappa sigma^2, so
      !> d/sigma ~ sqrt(g/D) with kappa cancelling: the distance to the optimum
      !> is measurable in units of the current scale without knowing the
      !> curvature.  The scale is then set to foc_scale_c times that distance,
      !> with the per-iteration change clamped by foc_scale_clamp.  This is
      !> absolute rather than cumulative, so it cannot build the feedback loop
      !> that defeats modes 1 to 4.
      real(wp) :: foc_scale_c = 1.0_wp
      real(wp) :: foc_scale_clamp = 4.0_wp
      !> Give up on a run that cannot reach the target.  With f* known the gap
      !> g = f - f* is known too, so the log-linear rate of its decay over
      !> recent generations extrapolates to the end of the budget.  If the
      !> projected gap is still above the target, the remaining evaluations are
      !> better spent on a fresh restart than on finishing this run.  Unlike
      !> the adaptive focus rules this does not steer the search at all, only
      !> the allocation of budget between runs, so it cannot interfere with
      !> convergence.
      logical  :: foc_gap_stop = .false.
      integer  :: foc_gap_window = 12      !< generations of history used
      real(wp) :: foc_gap_slack = 1.0_wp   !< decades of projected shortfall tolerated
      logical  :: foc_rank_one = .true.    !< cumulative rank-one covariance term
      !> Keep at most one member of each mirrored pair in the recombination.
      !> Correct in principle -- both members of a pair cancel to first order
      !> in the weighted mean -- but measured on the library's own suite it
      !> costs Rastrigin-10 (19/20 -> 4/20) while changing nothing else, so it
      !> is OFF by default and offered for smooth correlated problems.
      logical  :: foc_mirrored_select = .false.
      real(wp), allocatable :: foc_sigma0(:) !< explicit per-parameter sigma0
                                           !< (overrides the box-derived default;
                                           !<  used by the legacy shim)
      real(wp), allocatable :: nm_step_vec(:) !< absolute per-coordinate simplex
                                           !< edges; overrides nm_step
   end type opt_options

   !--------------------------------------------------------------------------
   ! Result record
   !--------------------------------------------------------------------------
   type :: opt_result
      real(wp), allocatable :: x(:), g(:)
      real(wp) :: f = opt_huge
      real(wp) :: gnorm = opt_huge
      integer  :: nfev = 0, ngev = 0, niter = 0
      integer  :: status = OPT_BAD_INPUT
      character(len=96) :: message = 'not run'
      character(len=48) :: method = ''
      real(wp) :: time = zero
      ! least-squares statistics (filled by the LM solver when lm_covar=.true.)
      logical  :: has_stats = .false.
      real(wp) :: chi2 = zero, rms = zero, redchi2 = zero
      integer  :: dof = 0, rank = 0
      real(wp), allocatable :: sigma(:)    !< 1-sigma parameter uncertainties
      !> the same from the residuals' own scale, not scaled by chi2/dof: the
      !> uncertainties when the residuals are divided by true standard
      !> deviations, and the only ones when there are no more residuals than
      !> parameters (2.8.2)
      real(wp), allocatable :: sigma_abs(:)
      !> parameters the data do not determine (2.8.2): with a rank-deficient
      !> Jacobian, those with a component along an undetermined direction.
      !> Their sigma is that of the pseudo-inverse and is meaningless.
      logical, allocatable :: undetermined(:)
      real(wp), allocatable :: cov(:, :)   !< covariance matrix
      real(wp), allocatable :: corr(:, :)  !< correlation matrix
      ! niching (foctopus with foc_niche = .true.)
      integer  :: niche_runs = 0, nopt = 0
      real(wp), allocatable :: xopt(:, :)  !< distinct run optima, best first
      real(wp), allocatable :: fopt(:)
   contains
      procedure :: summary => result_summary
   end type opt_result

contains

   !> Attach objective(s) and bounds.  Only n and one of fun/fungrad/res is
   !> mandatory; everything else refines the problem.
   subroutine problem_init(this, n, fun, grad, fungrad, res, jac, m, lb, ub, &
                           ctx, xscale, name)
      class(opt_problem), intent(inout) :: this
      integer, intent(in) :: n
      procedure(opt_fun_i), optional     :: fun
      procedure(opt_grad_i), optional    :: grad
      procedure(opt_fungrad_i), optional :: fungrad
      procedure(opt_res_i), optional     :: res
      procedure(opt_jac_i), optional     :: jac
      integer, intent(in), optional      :: m
      real(wp), intent(in), optional     :: lb(:), ub(:), xscale(:)
      class(*), target, intent(in), optional :: ctx
      character(len=*), intent(in), optional :: name

      ! make init idempotent: a problem object may legitimately be reused
      if (allocated(this%lb))     deallocate (this%lb)
      if (allocated(this%ub))     deallocate (this%ub)
      if (allocated(this%xscale)) deallocate (this%xscale)
      if (allocated(this%fixed))  deallocate (this%fixed)
      this%fun => null(); this%grad => null(); this%fungrad => null()
      this%res => null(); this%jac => null()
      this%m = 0

      this%n = n
      if (present(m))       this%m = m
      if (present(fun))     this%fun => fun
      if (present(grad))    this%grad => grad
      if (present(fungrad)) this%fungrad => fungrad
      if (present(res))     this%res => res
      if (present(jac))     this%jac => jac
      if (present(name))    this%name = name

      if (present(lb) .and. present(ub)) then
         this%lb = lb
         this%ub = ub
      else if (present(lb) .or. present(ub)) then
         allocate (this%lb(n), this%ub(n))
         this%lb = -opt_huge; this%ub = opt_huge
         if (present(lb)) this%lb = lb
         if (present(ub)) this%ub = ub
      end if

      if (present(xscale)) then
         this%xscale = xscale
      else
         allocate (this%xscale(n)); this%xscale = one
      end if

      if (present(ctx)) then
         this%ctx => ctx
      else
         this%ctx => default_ctx
      end if
   end subroutine problem_init

   pure logical function problem_bounded(this)
      class(opt_problem), intent(in) :: this
      problem_bounded = allocated(this%lb) .and. allocated(this%ub)
   end function problem_bounded

   pure logical function problem_is_lsq(this)
      class(opt_problem), intent(in) :: this
      problem_is_lsq = (this%m > 0) .and. associated(this%res)
   end function problem_is_lsq

   !> Project x into the feasible box (no-op for unbounded problems).
   pure subroutine problem_clip(this, x)
      class(opt_problem), intent(in) :: this
      real(wp), intent(inout)        :: x(:)
      if (allocated(this%lb)) x = max(x, this%lb)
      if (allocated(this%ub)) x = min(x, this%ub)
   end subroutine problem_clip

   !> Validate the problem before any solver touches it.
   subroutine problem_check(this, ok, msg)
      class(opt_problem), intent(inout) :: this
      logical, intent(out)          :: ok
      character(len=*), intent(out) :: msg
      ok = .false.
      msg = ''
      if (this%n <= 0) then
         msg = 'problem%n must be positive'; return
      end if
      if (.not. (associated(this%fun) .or. associated(this%fungrad) .or. &
                 associated(this%res))) then
         msg = 'no objective supplied (need fun, fungrad or res)'; return
      end if
      if (associated(this%res) .and. this%m <= 0) then
         msg = 'residual objective requires m > 0'; return
      end if
      if (allocated(this%lb)) then
         if (size(this%lb) /= this%n .or. size(this%ub) /= this%n) then
            msg = 'bounds have the wrong length'; return
         end if
         if (any(this%lb > this%ub)) then
            msg = 'lower bound exceeds upper bound'; return
         end if
      end if
      if (.not. associated(this%ctx)) this%ctx => default_ctx
      if (.not. allocated(this%xscale)) then
         allocate (this%xscale(this%n)); this%xscale = one
      end if
      ok = .true.
   end subroutine problem_check

   !--------------------------------------------------------------------------

   pure function status_message(code) result(s)
      integer, intent(in) :: code
      character(len=64)   :: s
      select case (code)
      case (OPT_SUCCESS);     s = 'success'
      case (OPT_CONV_F);      s = 'converged: relative change in f below tol_f'
      case (OPT_CONV_X);      s = 'converged: step length below tol_x'
      case (OPT_CONV_G);      s = 'converged: projected gradient below tol_g'
      case (OPT_CONV_TARGET); s = 'target objective value reached'
      case (OPT_MAX_FEVAL);   s = 'stopped: function evaluation budget exhausted'
      case (OPT_MAX_ITER);    s = 'stopped: iteration limit reached'
      case (OPT_MAX_TIME);    s = 'stopped: wall-clock limit reached'
      case (OPT_STAGNATED);   s = 'stopped: no further progress possible'
      case (OPT_USER_STOP);   s = 'stopped: objective reported an error'
      case (OPT_BAD_INPUT);   s = 'error: invalid problem or options'
      case (OPT_NUMERICAL);   s = 'error: numerical breakdown'
      case default;           s = 'unknown status'
      end select
   end function status_message

   pure integer function method_id(name)
      character(len=*), intent(in) :: name
      character(len=len(name))     :: s
      integer :: i, ic
      s = name
      do i = 1, len_trim(s)                       ! lowercase
         ic = iachar(s(i:i))
         if (ic >= 65 .and. ic <= 90) s(i:i) = achar(ic + 32)
      end do
      select case (trim(adjustl(s)))
      case ('auto');                       method_id = M_AUTO
      case ('nelder-mead', 'neldermead', 'nm', 'simplex', 'amoeba')
         method_id = M_NELDER_MEAD
      case ('powell');                     method_id = M_POWELL
      case ('lbfgsb', 'l-bfgs-b', 'lbfgs', 'l-bfgs')
         method_id = M_LBFGSB
      case ('trust-ncg', 'newton', 'trust_ncg', 'tncg')
         method_id = M_TRUST_NCG
      case ('cg', 'conjugate-gradient');   method_id = M_CG
      case ('lm', 'levmar', 'levenberg-marquardt', 'lsq')
         method_id = M_LEVMAR
      case ('de', 'differential-evolution', 'shade')
         method_id = M_DE
      case ('pso', 'swarm');               method_id = M_PSO
      case ('cmaes', 'cma-es', 'cma');     method_id = M_CMAES
      case ('sa', 'annealing', 'simulated-annealing')
         method_id = M_SA
      case ('direct');                     method_id = M_DIRECT
      case ('mlsl');                       method_id = M_MLSL
      case ('multistart', 'ms');           method_id = M_MULTISTART
      case ('basinhopping', 'basinhop', 'bh')
         method_id = M_BASINHOP
      case ('foctopus', 'foc');            method_id = M_FOCTOPUS
      case ('ga', 'genetic');              method_id = M_GA
      case ('mac');                        method_id = M_MAC
      case ('newuoa');                     method_id = M_NEWUOA
      case ('bobyqa');                     method_id = M_BOBYQA
      case ('dfogn', 'dfo-gn');            method_id = M_DFOGN
      case ('pattern', 'patternsearch', 'gps')
         method_id = M_PATTERN
      case ('mads', 'nomad');              method_id = M_PATTERN
      case ('bfgs', 'quasi-newton', 'fminunc')
         method_id = M_BFGS
      case ('sqp', 'active-set', 'fmincon')
         method_id = M_SQP
      case default;                        method_id = -1
      end select
   end function method_id

   pure function method_name(id) result(s)
      integer, intent(in) :: id
      character(len=32)   :: s
      select case (id)
      case (M_NELDER_MEAD); s = 'Nelder-Mead'
      case (M_POWELL);      s = 'Powell'
      case (M_LBFGSB);      s = 'L-BFGS-B'
      case (M_TRUST_NCG);   s = 'trust-region Newton-CG'
      case (M_CG);          s = 'conjugate gradient'
      case (M_LEVMAR);      s = 'Levenberg-Marquardt'
      case (M_DE);          s = 'differential evolution'
      case (M_PSO);         s = 'particle swarm'
      case (M_CMAES);       s = 'CMA-ES'
      case (M_SA);          s = 'simulated annealing'
      case (M_DIRECT);      s = 'DIRECT'
      case (M_MLSL);        s = 'MLSL'
      case (M_MULTISTART);  s = 'multistart'
      case (M_BASINHOP);    s = 'basin hopping'
      case (M_FOCTOPUS);    s = 'foctopus'
      case (M_GA);          s = 'genetic algorithm'
      case (M_MAC);         s = 'MAC'
      case (M_NEWUOA);      s = 'NEWUOA'
      case (M_BOBYQA);      s = 'BOBYQA'
      case (M_DFOGN);       s = 'derivative-free Gauss-Newton'
      case (M_PATTERN);     s = 'pattern search'
      case (M_BFGS);        s = 'BFGS quasi-Newton'
      case (M_SQP);         s = 'active-set SQP'
      case default;         s = 'auto'
      end select
   end function method_name

   !> After cov = pinv(G), G = J^T J: mark the parameters with a component in
   !> the null space of G.  diag(I - cov G) is that component (in the scaled
   !> coordinates sym_pinv works in); it is 0 for a determined parameter and
   !> up to 1 for one the data do not see at all.
   subroutine mark_undetermined(g, cov, res)
      real(wp), intent(in) :: g(:, :), cov(:, :)
      type(opt_result), intent(inout) :: res
      real(wp) :: pdiag
      integer :: i, n
      n = size(g, 1)
      if (allocated(res%undetermined)) deallocate (res%undetermined)
      allocate (res%undetermined(n))
      res%undetermined = .false.
      if (res%rank >= n) return
      do i = 1, n
         pdiag = one - dot_product(cov(i, :), g(:, i))
         res%undetermined(i) = pdiag > 1.0e-6_wp
      end do
   end subroutine mark_undetermined

   pure logical function is_global_method(id)
      integer, intent(in) :: id
      ! Explicit: the local methods added after the global block (NEWUOA and
      ! below) have larger ids, so an id comparison alone would misclassify them.
      is_global_method = (id >= M_DE .and. id <= M_GA) .or. id == M_MAC
   end function is_global_method

   subroutine result_summary(this, unit)
      class(opt_result), intent(in) :: this
      integer, intent(in), optional :: unit
      integer :: u, i
      u = output_unit
      if (present(unit)) u = unit
      write (u, '(a)') repeat('-', 68)
      write (u, '(a,a)')        ' method      : ', trim(this%method)
      write (u, '(a,es24.16)')  ' f(x*)       : ', this%f
      write (u, '(a,es12.4)')   ' |grad|_inf  : ', this%gnorm
      write (u, '(a,i0,a,i0,a,i0)') ' evaluations : ', this%nfev, &
         '   gradients: ', this%ngev, '   iterations: ', this%niter
      write (u, '(a,f10.3,a)')  ' wall time   : ', this%time, ' s'
      write (u, '(a,i0,a,a)')   ' status      : ', this%status, '  ', trim(this%message)
      if (allocated(this%x)) then
         write (u, '(a)') ' x*          :'
         if (this%has_stats .and. allocated(this%sigma)) then
            do i = 1, size(this%x)
               write (u, '(4x,i4,2x,es22.14,a,es12.4)') i, this%x(i), '  +/- ', this%sigma(i)
            end do
            write (u, '(a,es12.4,a,i0,a,es12.4)') ' chi2 = ', this%chi2, &
               '   dof = ', this%dof, '   reduced chi2 = ', this%redchi2
         else
            do i = 1, size(this%x)
               write (u, '(4x,i4,2x,es22.14)') i, this%x(i)
            end do
         end if
      end if
      write (u, '(a)') repeat('-', 68)
   end subroutine result_summary

end module fitpar_types
