!> FitPar -- helpers shared by the global search methods.
module fitpar_globutil
   use fitpar_kinds
   use fitpar_types
   implicit none
   private
   public :: get_box, rank_index, box_penalty

contains

   !> Global methods need a search box.  If the user supplied none, build one
   !> around the start point from the parameter scales.  This is a fallback,
   !> not a substitute for real bounds: a global search is only as good as the
   !> region it is told to search.
   subroutine get_box(p, x, lb, ub)
      type(opt_problem), intent(in) :: p
      real(wp), intent(in) :: x(:)
      real(wp), allocatable, intent(out) :: lb(:), ub(:)
      integer :: i
      allocate (lb(p%n), ub(p%n))
      if (p%bounded()) then
         lb = p%lb; ub = p%ub
      else
         lb = -opt_huge; ub = opt_huge
      end if
      do i = 1, p%n
         if (lb(i) <= -1.0e30_wp) lb(i) = x(i) - 10.0_wp * max(abs(x(i)), p%xscale(i))
         if (ub(i) >= 1.0e30_wp)  ub(i) = x(i) + 10.0_wp * max(abs(x(i)), p%xscale(i))
         if (ub(i) <= lb(i)) then
            lb(i) = x(i) - one; ub(i) = x(i) + one
         end if
      end do
   end subroutine get_box

   !> Indices that sort v ascending (insertion sort; populations are small).
   pure subroutine rank_index(v, idx)
      real(wp), intent(in) :: v(:)
      integer, intent(out) :: idx(:)
      integer :: i, j, t
      do i = 1, size(v)
         idx(i) = i
      end do
      do i = 2, size(v)
         t = idx(i)
         j = i - 1
         do while (j >= 1)
            if (v(idx(j)) <= v(t)) exit
            idx(j + 1) = idx(j)
            j = j - 1
         end do
         idx(j + 1) = t
      end do
   end subroutine rank_index

   !> Quadratic penalty for a point outside the box, scaled by the current
   !> objective range.  Used by CMA-ES, whose Gaussian samples must be allowed
   !> to leave the box without destroying the covariance update.
   pure real(wp) function box_penalty(x, lb, ub, fscale)
      real(wp), intent(in) :: x(:), lb(:), ub(:), fscale
      real(wp) :: d
      integer :: i
      box_penalty = zero
      do i = 1, size(x)
         d = zero
         if (x(i) < lb(i)) d = lb(i) - x(i)
         if (x(i) > ub(i)) d = x(i) - ub(i)
         if (d > zero) box_penalty = box_penalty + (d / max(ub(i) - lb(i), opt_tiny))**2
      end do
      box_penalty = fscale * box_penalty
   end function box_penalty

end module fitpar_globutil
