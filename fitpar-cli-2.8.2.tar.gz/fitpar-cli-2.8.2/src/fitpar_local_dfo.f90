!> FitPar -- derivative-free local methods.
!>
!> solve_nelder_mead : adaptive simplex.  The classical coefficients
!>   (1, 2, 1/2, 1/2) degrade badly beyond n ~ 10; the dimension-dependent
!>   coefficients of Gao & Han (2012) keep the simplex from collapsing, and are
!>   the default here.  Optional restarts re-inflate a collapsed simplex, which
!>   is the standard cure for the premature-convergence failure that gives
!>   simplex methods their poor reputation.
!>
!> solve_powell : direction-set method with Brent line minimisation.  Achieves
!>   quadratic termination on quadratic forms without any derivatives, and is
!>   usually far more accurate than a simplex when the objective is smooth but
!>   the gradient is unavailable or too noisy to difference.
module fitpar_local_dfo
   use fitpar_kinds
   use fitpar_types
   use fitpar_eval
   implicit none
   private
   public :: solve_nelder_mead, solve_powell

contains

   subroutine solve_nelder_mead(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      real(wp), allocatable :: sx(:, :), sf(:), xc(:), xr(:), xe(:), xt(:), x0(:)
      integer, allocatable  :: ord(:)
      real(wp) :: alpha, beta, gamma, delta, fr, fe, ft, fspread, xspread, step
      integer  :: n, i, j, iter, nv, itotal, irestart
      logical  :: shrink

      n = p%n; nv = n + 1
      allocate (sx(n, nv), sf(nv), xc(n), xr(n), xe(n), xt(n), x0(n), ord(nv))

      if (o%nm_adaptive .and. n > 1) then
         alpha = one
         beta = one + two / real(n, wp)
         gamma = 0.75_wp - one / (two * real(n, wp))
         delta = one - one / real(n, wp)
      else
         alpha = one; beta = two; gamma = half; delta = half
      end if

      call p%clip(x)
      x0 = x
      itotal = 0
      res%status = OPT_MAX_ITER

      restart_loop: do irestart = 0, o%restarts

         ! --- build the initial simplex ---------------------------------------
         do j = 1, nv
            sx(:, j) = x0
         end do
         do i = 1, n
            step = o%nm_step * max(abs(x0(i)), p%xscale(i))
            if (step <= zero) step = o%nm_step
            if (allocated(o%nm_step_vec)) then
               if (size(o%nm_step_vec) >= n) then
                  if (abs(o%nm_step_vec(i)) > zero) step = abs(o%nm_step_vec(i))
               end if
            end if
            if (p%bounded()) then
               if (x0(i) + step > p%ub(i)) step = -abs(step)
               if (x0(i) + step < p%lb(i)) step = half * (p%ub(i) - p%lb(i))
            end if
            sx(i, i + 1) = x0(i) + step
         end do
         do j = 1, nv
            call p%clip(sx(:, j))
            sf(j) = ev%f(sx(:, j))
         end do
         call sort_simplex(sx, sf)

         ! --- main loop ---------------------------------------------------------
         do iter = 1, o%max_iter
            itotal = itotal + 1
            if (ev%stop_flag) then
               res%status = ev%stop_code; exit restart_loop
            end if

            fspread = abs(sf(nv) - sf(1))
            xspread = zero
            do j = 2, nv
               xspread = max(xspread, maxval(abs(sx(:, j) - sx(:, 1))))
            end do
            if (o%verbose >= 2 .and. mod(iter - 1, max(1, o%print_every)) == 0) &
               write (o%unit, '(a,i6,a,i8,a,es20.12,a,es11.3)') '  it ', itotal, &
               '  nf ', ev%nfev, '  f ', sf(1), '  spread ', fspread

            ! The spread test needs an absolute component: near a zero-residual
            ! optimum |f| itself vanishes, and a purely relative criterion can
            ! never fire -- the simplex then grinds until the budget runs out
            ! while already sitting on the answer.
            if (fspread <= o%tol_f * (abs(sf(1)) + one) .and. &
                xspread <= o%tol_x * max(one, maxval(abs(sx(:, 1))))) then
               res%status = OPT_CONV_F
               exit
            end if

            ! centroid of the n best vertices
            xc = zero
            do j = 1, n
               xc = xc + sx(:, j)
            end do
            xc = xc / real(n, wp)

            shrink = .false.
            xr = xc + alpha * (xc - sx(:, nv))
            call p%clip(xr)
            fr = ev%f(xr)

            if (fr < sf(1)) then                       ! expand
               xe = xc + beta * (xr - xc)
               call p%clip(xe)
               fe = ev%f(xe)
               if (fe < fr) then
                  sx(:, nv) = xe; sf(nv) = fe
               else
                  sx(:, nv) = xr; sf(nv) = fr
               end if
            else if (fr < sf(n)) then                  ! accept reflection
               sx(:, nv) = xr; sf(nv) = fr
            else
               if (fr < sf(nv)) then                   ! outside contraction
                  xt = xc + gamma * (xr - xc)
                  call p%clip(xt)
                  ft = ev%f(xt)
                  if (ft <= fr) then
                     sx(:, nv) = xt; sf(nv) = ft
                  else
                     shrink = .true.
                  end if
               else                                     ! inside contraction
                  xt = xc - gamma * (xc - sx(:, nv))
                  call p%clip(xt)
                  ft = ev%f(xt)
                  if (ft < sf(nv)) then
                     sx(:, nv) = xt; sf(nv) = ft
                  else
                     shrink = .true.
                  end if
               end if
            end if

            if (shrink) then
               do j = 2, nv
                  sx(:, j) = sx(:, 1) + delta * (sx(:, j) - sx(:, 1))
                  call p%clip(sx(:, j))
                  sf(j) = ev%f(sx(:, j))
               end do
            end if

            call sort_simplex(sx, sf)
            if (itotal >= o%max_iter) then
               res%status = OPT_MAX_ITER; exit restart_loop
            end if
         end do

         x0 = sx(:, 1)
         if (irestart == o%restarts) exit restart_loop
      end do restart_loop

      res%x = sx(:, 1)
      res%f = sf(1)
      res%niter = itotal
      res%gnorm = abs(sf(nv) - sf(1))
      if (allocated(res%g)) deallocate (res%g)
      allocate (res%g(n)); res%g = zero
   end subroutine solve_nelder_mead

   !> Insertion sort of the simplex by function value (nv is small).
   pure subroutine sort_simplex(sx, sf)
      real(wp), intent(inout) :: sx(:, :), sf(:)
      real(wp) :: ftmp
      real(wp), allocatable :: xtmp(:)
      integer :: i, j, nv
      nv = size(sf)
      allocate (xtmp(size(sx, 1)))
      do i = 2, nv
         ftmp = sf(i); xtmp = sx(:, i)
         j = i - 1
         do while (j >= 1)
            if (sf(j) <= ftmp) exit
            sf(j + 1) = sf(j); sx(:, j + 1) = sx(:, j)
            j = j - 1
         end do
         sf(j + 1) = ftmp; sx(:, j + 1) = xtmp
      end do
   end subroutine sort_simplex

   !--------------------------------------------------------------------------
   ! Powell's direction set method
   !--------------------------------------------------------------------------
   subroutine solve_powell(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      real(wp), allocatable :: u(:, :), xi(:), x_old(:), x_ext(:), dir(:)
      real(wp) :: f, fp, fptt, del, t, fx_ext
      integer  :: n, i, iter, ibig

      n = p%n
      allocate (u(n, n), xi(n), x_old(n), x_ext(n), dir(n))
      u = zero
      do i = 1, n
         u(i, i) = max(p%xscale(i), opt_tiny)
      end do

      call p%clip(x)
      f = ev%f(x)
      x_old = x
      res%status = OPT_MAX_ITER

      do iter = 1, o%max_iter
         fp = f
         ibig = 0
         del = zero
         do i = 1, n
            dir = u(:, i)
            fptt = f
            call line_min(ev, p, x, dir, f)
            if (fptt - f > del) then
               del = fptt - f
               ibig = i
            end if
            if (ev%stop_flag) exit
         end do

         if (o%verbose >= 2 .and. mod(iter - 1, max(1, o%print_every)) == 0) &
            write (o%unit, '(a,i6,a,i8,a,es20.12,a,es11.3)') '  it ', iter, &
            '  nf ', ev%nfev, '  f ', f, '  decr  ', fp - f

         if (two * abs(fp - f) <= o%tol_f * (abs(fp) + abs(f)) + opt_tiny) then
            res%status = OPT_CONV_F; exit
         end if
         if (ev%stop_flag) then
            res%status = ev%stop_code; exit
         end if

         ! extrapolated point and Powell's replacement test
         x_ext = two * x - x_old
         dir = x - x_old
         x_old = x
         fx_ext = ev%f(x_ext)
         if (fx_ext < fp) then
            t = two * (fp - two * f + fx_ext) * (fp - f - del)**2 - del * (fp - fx_ext)**2
            if (t < zero) then
               call line_min(ev, p, x, dir, f)
               if (ibig > 0) then
                  u(:, ibig) = u(:, n)
                  u(:, n) = dir
               end if
            end if
         end if
         if (iter == o%max_iter) res%status = OPT_MAX_ITER
      end do

      res%x = x; res%f = f; res%niter = iter
      if (allocated(res%g)) deallocate (res%g)
      allocate (res%g(n)); res%g = zero
      res%gnorm = zero
   end subroutine solve_powell

   !> Minimise f along x + t*dir.  Bracket first (mnbrak-style), then Brent.
   !> Bounds truncate the admissible t interval.
   subroutine line_min(ev, p, x, dir, f)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      real(wp), intent(inout) :: x(:), dir(:), f
      real(wp) :: tlo, thi, ta, tb, tc, fa, fb, fc, tmin, fmin
      real(wp), allocatable :: xt(:)
      integer :: i

      allocate (xt(size(x)))
      if (maxval(abs(dir)) <= opt_tiny) return

      tlo = -opt_big; thi = opt_big
      if (p%bounded()) then
         do i = 1, size(x)
            if (abs(dir(i)) > opt_tiny) then
               tlo = max(tlo, min((p%lb(i) - x(i)) / dir(i), (p%ub(i) - x(i)) / dir(i)))
               thi = min(thi, max((p%lb(i) - x(i)) / dir(i), (p%ub(i) - x(i)) / dir(i)))
            end if
         end do
         if (thi <= tlo) return
      else
         tlo = -1.0e8_wp; thi = 1.0e8_wp
      end if

      ! --- bracket the minimum (Numerical Recipes mnbrak, corrected) --------
      ! The essential detail: if the first probe goes uphill we SWAP the two
      ! points rather than abandoning that side, so the returned triple always
      ! brackets a minimum even when it lies between 0 and the first probe.
      ta = zero; fa = f
      tb = min(thi, max(tlo, 0.1_wp))
      if (abs(tb) <= opt_tiny) tb = max(tlo, min(thi, -0.1_wp))
      xt = x + tb * dir; call p%clip(xt); fb = ev%f(xt)
      if (fb > fa) then
         call swap_r(ta, tb); call swap_r(fa, fb)
      end if
      tc = min(thi, max(tlo, tb + 1.618034_wp * (tb - ta)))
      xt = x + tc * dir; call p%clip(xt); fc = ev%f(xt)
      do while (fb > fc .and. .not. ev%stop_flag)
         ta = tb; fa = fb
         tb = tc; fb = fc
         tc = min(thi, max(tlo, tb + 1.618034_wp * (tb - ta)))
         if (abs(tc - tb) <= 1.0e-14_wp * max(one, abs(tb))) exit
         xt = x + tc * dir; call p%clip(xt); fc = ev%f(xt)
      end do

      call brent_min(ev, p, x, dir, ta, tb, tc, tmin, fmin)
      if (fmin < f) then
         f = fmin
         dir = tmin * dir
         x = x + dir
         call p%clip(x)
      else
         dir = zero
      end if
   end subroutine line_min

   pure subroutine swap_r(a, b)
      real(wp), intent(inout) :: a, b
      real(wp) :: t
      t = a; a = b; b = t
   end subroutine swap_r

   !> Brent's parabolic-interpolation/golden-section 1-D minimiser.
   subroutine brent_min(ev, p, x, dir, ax, bx, cx, xmin, fmin)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      real(wp), intent(in)  :: x(:), dir(:), ax, bx, cx
      real(wp), intent(out) :: xmin, fmin
      real(wp), parameter :: cgold = 0.3819660_wp, zeps = 1.0e-12_wp
      integer, parameter  :: itmax = 100
      real(wp) :: a, b, d, e, etemp, fu, fv, fw, fxv, pq, q, r, tol1, tol2, u, v, w, xx, xm
      real(wp), allocatable :: xt(:)
      integer :: iter

      allocate (xt(size(x)))
      a = min(ax, cx); b = max(ax, cx)
      xx = bx; w = bx; v = bx
      xt = x + xx * dir; call p%clip(xt)
      fxv = ev%f(xt); fw = fxv; fv = fxv
      d = zero; e = zero

      do iter = 1, itmax
         xm = half * (a + b)
         tol1 = sqrt(opt_eps) * abs(xx) + zeps
         tol2 = two * tol1
         if (abs(xx - xm) <= (tol2 - half * (b - a)) .or. ev%stop_flag) exit
         if (abs(e) > tol1) then
            r = (xx - w) * (fxv - fv)
            q = (xx - v) * (fxv - fw)
            pq = (xx - v) * q - (xx - w) * r
            q = two * (q - r)
            if (q > zero) pq = -pq
            q = abs(q)
            etemp = e
            e = d
            if (abs(pq) >= abs(half * q * etemp) .or. pq <= q * (a - xx) .or. &
                pq >= q * (b - xx)) then
               if (xx >= xm) then
                  e = a - xx
               else
                  e = b - xx
               end if
               d = cgold * e
            else
               d = pq / q
               u = xx + d
               if (u - a < tol2 .or. b - u < tol2) d = sign(tol1, xm - xx)
            end if
         else
            if (xx >= xm) then
               e = a - xx
            else
               e = b - xx
            end if
            d = cgold * e
         end if
         if (abs(d) >= tol1) then
            u = xx + d
         else
            u = xx + sign(tol1, d)
         end if
         xt = x + u * dir; call p%clip(xt)
         fu = ev%f(xt)
         if (fu <= fxv) then
            if (u >= xx) then
               a = xx
            else
               b = xx
            end if
            v = w; fv = fw
            w = xx; fw = fxv
            xx = u; fxv = fu
         else
            if (u < xx) then
               a = u
            else
               b = u
            end if
            if (fu <= fw .or. w == xx) then
               v = w; fv = fw
               w = u; fw = fu
            else if (fu <= fv .or. v == xx .or. v == w) then
               v = u; fv = fu
            end if
         end if
      end do
      xmin = xx; fmin = fxv
   end subroutine brent_min

end module fitpar_local_dfo
