!> FitPar -- Covariance Matrix Adaptation Evolution Strategy.
!>
!> CMA-ES is the state of the art for non-separable, ill-conditioned,
!> derivative-free problems.  It samples from a multivariate normal and adapts
!> the full covariance, so it learns the shape of a curved narrow valley --
!> exactly the geometry that defeats coordinate-wise methods -- and becomes
!> invariant to rotations of the parameter space.  Step size is controlled
!> separately by cumulative step-length adaptation, which is what keeps it from
!> converging prematurely.
!>
!> Implemented here with:
!>   * rank-one plus rank-mu covariance update with the evolution path,
!>   * cumulative step-size adaptation (CSA),
!>   * IPOP restarts: on convergence the population is doubled and the search
!>     restarted, which turns a local strategy into a global one,
!>   * boundary handling by clipped evaluation plus a quadratic penalty.
!>
!> Reference: Hansen & Ostermeier (2001); Auger & Hansen (2005) for IPOP.
module fitpar_global_cmaes
   use fitpar_kinds
   use fitpar_types
   use fitpar_eval
   use fitpar_rng
   use fitpar_linalg
   use fitpar_globutil
   implicit none
   private
   public :: solve_cmaes

contains

   subroutine solve_cmaes(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      real(wp), allocatable :: lb(:), ub(:), xmean(:), xold(:), width(:)
      real(wp), allocatable :: arz(:, :), arx(:, :), ary(:, :), arf(:), w(:)
      real(wp), allocatable :: bmat(:, :), dvec(:), cmat(:, :), invsqrtc(:, :)
      real(wp), allocatable :: ps(:), pc(:), ytmp(:), xeval(:, :)
      integer, allocatable  :: ord(:)
      real(wp) :: sigma, mueff, cc, cs, c1, cmu, damps, chin, hsig, psnorm
      real(wp) :: sumw, sumw2, fbest_run, fscale, tmp
      integer  :: n, lambda, mu, gen, i, j, k, info, eigen_gen, restart
      integer  :: lambda0, gen_total
      type(rng_t) :: rng
      logical  :: restart_needed

      n = p%n
      call get_box(p, x, lb, ub)
      allocate (width(n)); width = ub - lb
      call rng%seed(o%seed)

      lambda0 = o%popsize
      if (lambda0 <= 0) lambda0 = 4 + int(three * log(real(n, wp)))
      lambda0 = max(lambda0, 5)
      gen_total = 0
      allocate (xmean(n), xold(n), ps(n), pc(n), ytmp(n))
      allocate (bmat(n, n), dvec(n), cmat(n, n), invsqrtc(n, n))
      res%status = OPT_MAX_FEVAL
      res%f = opt_huge
      res%x = x

      restart_loop: do restart = 0, merge(9, 0, o%cma_ipop)
         lambda = lambda0 * 2**restart
         mu = lambda / 2

         if (allocated(arz)) deallocate (arz, arx, ary, arf, w, ord, xeval)
         allocate (arz(n, lambda), arx(n, lambda), ary(n, lambda), arf(lambda))
         allocate (w(mu), ord(lambda), xeval(n, lambda))

         ! --- recombination weights ------------------------------------------
         do i = 1, mu
            w(i) = log(real(mu, wp) + half) - log(real(i, wp))
         end do
         sumw = sum(w); w = w / sumw
         sumw2 = sum(w**2)
         mueff = one / sumw2

         ! --- strategy parameters (Hansen's standard settings) ----------------
         cc = (4.0_wp + mueff / real(n, wp)) / (real(n, wp) + 4.0_wp + two * mueff / real(n, wp))
         cs = (mueff + two) / (real(n, wp) + mueff + 5.0_wp)
         c1 = two / ((real(n, wp) + 1.3_wp)**2 + mueff)
         cmu = min(one - c1, two * (mueff - two + one / mueff) / &
                   ((real(n, wp) + two)**2 + mueff))
         damps = one + two * max(zero, sqrt((mueff - one) / (real(n, wp) + one)) - one) + cs
         chin = sqrt(real(n, wp)) * (one - one / (4.0_wp * real(n, wp)) &
                                     + one / (21.0_wp * real(n, wp)**2))

         ! --- initial state ----------------------------------------------------
         if (restart == 0) then
            xmean = x
         else
            do i = 1, n
               xmean(i) = lb(i) + rng%uniform() * width(i)
            end do
         end if
         sigma = o%cma_sigma0 * maxval(width)
         if (sigma <= zero) sigma = 0.3_wp
         cmat = zero; bmat = zero; invsqrtc = zero
         do i = 1, n
            cmat(i, i) = (width(i) / maxval(width))**2   ! anisotropic start
            bmat(i, i) = one
            invsqrtc(i, i) = one
            dvec(i) = sqrt(cmat(i, i))
         end do
         ps = zero; pc = zero
         eigen_gen = 0
         fbest_run = opt_huge
         restart_needed = .false.

         do gen = 1, o%max_iter
            gen_total = gen_total + 1

            ! --- sample -------------------------------------------------------
            do k = 1, lambda
               call rng%normal_v(arz(:, k))
               do i = 1, n
                  ary(i, k) = sum(bmat(i, :) * dvec(:) * arz(:, k))
               end do
               arx(:, k) = xmean + sigma * ary(:, k)
               xeval(:, k) = min(max(arx(:, k), lb), ub)
            end do

            call ev%fbatch(xeval(:, 1:lambda), arf(1:lambda))

            ! --- boundary penalty ---------------------------------------------
            fscale = max(abs(maxval(arf(1:lambda)) - minval(arf(1:lambda))), opt_tiny)
            do k = 1, lambda
               arf(k) = arf(k) + box_penalty(arx(:, k), lb, ub, fscale)
            end do
            if (ev%stop_flag) then
               res%status = ev%stop_code
               exit restart_loop
            end if

            call rank_index(arf(1:lambda), ord(1:lambda))
            if (arf(ord(1)) < fbest_run) fbest_run = arf(ord(1))

            ! --- recombination -------------------------------------------------
            xold = xmean
            xmean = zero
            ytmp = zero
            do i = 1, mu
               xmean = xmean + w(i) * arx(:, ord(i))
               ytmp = ytmp + w(i) * ary(:, ord(i))
            end do

            ! --- step-size control (CSA) ----------------------------------------
            do i = 1, n
               ps(i) = (one - cs) * ps(i) + sqrt(cs * (two - cs) * mueff) * &
                       sum(invsqrtc(i, :) * ytmp(:))
            end do
            psnorm = sqrt(sum(ps**2))
            hsig = zero
            if (psnorm / sqrt(one - (one - cs)**(two * real(gen, wp))) / chin < &
                1.4_wp + two / (real(n, wp) + one)) hsig = one

            pc = (one - cc) * pc + hsig * sqrt(cc * (two - cc) * mueff) * ytmp

            ! --- covariance update -----------------------------------------------
            cmat = (one - c1 - cmu) * cmat
            call outer_update(cmat, pc, c1)
            if (hsig < half) cmat = cmat + c1 * cc * (two - cc) * cmat   ! variance loss correction
            do i = 1, mu
               call outer_update(cmat, ary(:, ord(i)), cmu * w(i))
            end do

            sigma = sigma * exp((cs / damps) * (psnorm / chin - one))

            ! --- eigen decomposition, amortised ------------------------------------
            if (gen - eigen_gen > max(1, int(real(lambda, wp) / (10.0_wp * real(n, wp) * (c1 + cmu))))) then
               eigen_gen = gen
               cmat = half * (cmat + transpose(cmat))
               call jacobi_eigen(cmat, dvec, bmat, info)
               if (any(dvec <= zero)) then
                  where (dvec <= zero) dvec = opt_eps
               end if
               ! guard against runaway condition number
               if (maxval(dvec) > 1.0e14_wp * minval(dvec)) then
                  tmp = maxval(dvec) / 1.0e14_wp
                  dvec = dvec + tmp
                  cmat = zero
                  do i = 1, n
                     call outer_update(cmat, bmat(:, i), dvec(i))
                  end do
               end if
               dvec = sqrt(dvec)
               do i = 1, n
                  do j = 1, n
                     invsqrtc(i, j) = sum(bmat(i, :) * bmat(j, :) / dvec(:))
                  end do
               end do
            end if

            if (o%verbose >= 2 .and. mod(gen - 1, max(1, o%print_every)) == 0) &
               write (o%unit, '(a,i6,a,i8,a,es20.12,a,es11.3,a,i4)') '  gen ', gen_total, &
               '  nf ', ev%nfev, '  f ', arf(ord(1)), '  sigma ', sigma, '  lam ', lambda

            ! --- restart / stop criteria -------------------------------------------
            if (sigma * maxval(dvec) < o%tol_x * maxval(width)) restart_needed = .true.
            if (abs(arf(ord(lambda)) - arf(ord(1))) <= &
                o%tol_f * (abs(arf(ord(1))) + o%tol_f)) restart_needed = .true.
            if (.not. is_finite(sigma) .or. sigma <= opt_tiny) restart_needed = .true.
            if (restart_needed) exit
            if (gen == o%max_iter) then
               res%status = OPT_MAX_ITER
               exit restart_loop
            end if
         end do

         if (o%verbose >= 2 .and. o%cma_ipop) &
            write (o%unit, '(a,i0,a,es14.6)') '  [cma] restart ', restart + 1, &
            ' best so far ', ev%fbest
         if (ev%stop_flag) exit restart_loop
      end do restart_loop

      res%x = ev%xbest
      res%f = ev%fbest
      res%niter = gen_total
   end subroutine solve_cmaes

end module fitpar_global_cmaes
