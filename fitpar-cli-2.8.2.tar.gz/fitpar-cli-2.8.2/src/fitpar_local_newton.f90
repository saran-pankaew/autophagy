!> FitPar -- trust-region truncated Newton (Steihaug-Toint CG).
!>
!> The Hessian is never formed.  Curvature enters only through Hessian-vector
!> products, obtained by central differencing of the gradient, so the memory
!> cost is O(n) and the method scales to large parameter vectors.  Negative
!> curvature is not a failure here: the CG loop simply follows the direction of
!> negative curvature to the trust-region boundary, which is exactly what you
!> want when starting far from the solution.
!>
!> Use this when you can supply an analytic gradient.  With finite-difference
!> gradients each Hessian-vector product costs 4n function evaluations and
!> L-BFGS-B is usually the better bargain.
module fitpar_local_newton
   use fitpar_kinds
   use fitpar_types
   use fitpar_eval
   implicit none
   private
   public :: solve_trust_ncg

contains

   subroutine solve_trust_ncg(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(inout) :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      real(wp), allocatable :: g(:), step(:), xt(:), gt(:)
      real(wp) :: f, ft, delta, delta_max, rho, gnorm, pred, ared, mstep
      integer  :: n, iter
      real(wp), parameter :: eta = 0.15_wp

      n = p%n
      allocate (g(n), step(n), xt(n), gt(n))
      call p%clip(x)
      call ev%fg(x, f, g)
      delta = one
      delta_max = 1.0e4_wp
      res%status = OPT_MAX_ITER

      do iter = 1, o%max_iter
         gnorm = maxval(abs(g))
         if (o%verbose >= 2 .and. mod(iter - 1, max(1, o%print_every)) == 0) &
            write (o%unit, '(a,i6,a,i8,a,es20.12,a,es11.3,a,es10.2)') '  it ', iter, &
            '  nf ', ev%nfev, '  f ', f, '  |g| ', gnorm, '  delta ', delta
         if (gnorm <= o%tol_g) then
            res%status = OPT_CONV_G; exit
         end if
         if (ev%stop_flag) then
            res%status = ev%stop_code; exit
         end if

         call steihaug_cg(ev, x, g, delta, step, pred)
         mstep = sqrt(sum(step**2))
         if (mstep <= o%tol_x * max(one, sqrt(sum(x**2)))) then
            res%status = OPT_CONV_X; exit
         end if

         xt = x + step
         call p%clip(xt)
         ft = ev%f(xt)
         ared = f - ft
         if (pred <= zero) then
            rho = -one
         else
            rho = ared / pred
         end if

         if (rho < 0.25_wp) then
            delta = 0.25_wp * delta
         else if (rho > 0.75_wp .and. mstep >= 0.9_wp * delta) then
            delta = min(two * delta, delta_max)
         end if

         if (rho > eta) then
            if (reldiff(f, ft) <= o%tol_f .and. ared >= zero) then
               x = xt; f = ft
               call ev%grad(x, g)
               res%status = OPT_CONV_F; exit
            end if
            x = xt; f = ft
            call ev%grad(x, g)
         end if

         if (delta < 1.0e-14_wp) then
            res%status = OPT_STAGNATED; exit
         end if
         if (ev%stop_flag) then
            res%status = ev%stop_code; exit
         end if
      end do

      res%x = x; res%f = f; res%g = g
      res%gnorm = maxval(abs(g))
      res%niter = iter
   end subroutine solve_trust_ncg

   !> Approximately minimise the quadratic model inside the trust region.
   !> Returns the step and the predicted decrease.
   subroutine steihaug_cg(ev, x, g, delta, step, pred)
      type(evaluator_t), intent(inout) :: ev
      real(wp), intent(in)  :: x(:), g(:), delta
      real(wp), intent(out) :: step(:), pred
      real(wp), allocatable :: z(:), r(:), d(:), hd(:)
      real(wp) :: gnorm, eps_k, dhd, alpha, rr, rr_new, beta, tau, zz
      integer :: n, j, maxcg

      n = size(x)
      allocate (z(n), r(n), d(n), hd(n))
      z = zero; r = g; d = -g
      gnorm = sqrt(sum(g**2))
      eps_k = min(half, sqrt(gnorm)) * gnorm       ! superlinear forcing sequence
      maxcg = max(10, 2 * n)
      step = zero; pred = zero

      if (gnorm <= opt_tiny) return

      do j = 1, maxcg
         call ev%hessvec(x, d, hd)
         dhd = dot_product(d, hd)
         if (dhd <= zero) then                      ! negative curvature: go to the edge
            call boundary_tau(z, d, delta, tau)
            step = z + tau * d
            exit
         end if
         rr = dot_product(r, r)
         alpha = rr / dhd
         zz = sqrt(sum((z + alpha * d)**2))
         if (zz >= delta) then
            call boundary_tau(z, d, delta, tau)
            step = z + tau * d
            exit
         end if
         z = z + alpha * d
         r = r + alpha * hd
         rr_new = dot_product(r, r)
         if (sqrt(rr_new) < eps_k) then
            step = z
            exit
         end if
         beta = rr_new / rr
         d = -r + beta * d
         step = z
         if (ev%stop_flag) exit
      end do

      ! predicted decrease  -(g'p + 0.5 p'Hp)
      call ev%hessvec(x, step, hd)
      pred = -(dot_product(g, step) + half * dot_product(step, hd))
   end subroutine steihaug_cg

   !> Positive root of ||z + tau d|| = delta.
   pure subroutine boundary_tau(z, d, delta, tau)
      real(wp), intent(in)  :: z(:), d(:), delta
      real(wp), intent(out) :: tau
      real(wp) :: a, b, c, disc
      a = dot_product(d, d)
      b = two * dot_product(z, d)
      c = dot_product(z, z) - delta**2
      disc = b * b - 4.0_wp * a * c
      if (a <= opt_tiny .or. disc < zero) then
         tau = zero
      else
         tau = (-b + sqrt(disc)) / (two * a)
      end if
   end subroutine boundary_tau

end module fitpar_local_newton
