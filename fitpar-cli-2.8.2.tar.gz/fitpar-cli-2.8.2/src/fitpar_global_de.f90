!> FitPar -- differential evolution, self-adaptive variant.
!>
!> Plain DE has two hyper-parameters (F and CR) that decide between success and
!> stagnation and that nobody can guess in advance.  This implementation uses
!> the JADE scheme instead: F and CR are drawn per individual from
!> distributions whose location parameters are learned from the mutations that
!> actually succeeded, so the search adapts itself from exploration to
!> exploitation without user intervention.  Note that this is JADE, not SHADE:
!> the location parameters are single running values updated by exponential
!> smoothing (Lehmer mean for F, arithmetic mean for CR), not a bank of H
!> historical memory entries indexed cyclically.  The population reduction
!> below is, however, exactly the one L-SHADE adds to SHADE.
!>
!>   * current-to-pbest/1/bin mutation with an external archive of defeated
!>     parents, which preserves direction information that plain DE discards;
!>   * linear population size reduction (L-SHADE), which spends the early
!>     budget on exploration and the late budget on refinement;
!>   * midpoint bounce-back at the bounds, which keeps the population inside
!>     the box without the clustering that hard clipping produces.
module fitpar_global_de
   use fitpar_kinds
   use fitpar_types
   use fitpar_eval
   use fitpar_rng
   use fitpar_globutil
   implicit none
   private
   public :: solve_de

contains

   subroutine solve_de(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      real(wp), allocatable :: pop(:, :), fit(:), trial(:, :), ftrial(:)
      real(wp), allocatable :: arch(:, :), sf(:), scr(:), fvals(:)
      integer, allocatable  :: ord(:)
      real(wp) :: mu_f, mu_cr, fi, cri, sum1, sum2, spread, fmean
      integer  :: n, np, np0, np_min, i, j, k, gen, r1, r2, pb, narch, maxarch
      integer  :: jrand, nsucc, ibest
      real(wp), allocatable :: lb(:), ub(:)
      type(rng_t) :: rng
      real(wp), parameter :: c_adapt = 0.1_wp

      n = p%n
      call get_box(p, x, lb, ub)
      call rng%seed(o%seed)

      np0 = o%popsize
      if (np0 <= 0) np0 = min(max(5 * n, 30), 150)
      np_min = 4
      np = np0
      maxarch = np0
      allocate (pop(n, np0), fit(np0), trial(n, np0), ftrial(np0))
      allocate (arch(n, maxarch), sf(np0), scr(np0), ord(np0), fvals(np0))
      narch = 0
      mu_f = 0.5_wp; mu_cr = 0.5_wp

      ! --- initial population: LHS plus the user's start point ---------------
      call sample_lhs(rng, lb, ub, pop)
      pop(:, 1) = x
      call p%clip(pop(:, 1))
      call ev%fbatch(pop(:, 1:np), fit(1:np))
      ibest = minloc(fit(1:np), dim=1)
      res%status = OPT_MAX_FEVAL

      do gen = 1, o%max_iter
         if (ev%stop_flag) then
            res%status = ev%stop_code; exit
         end if

         call rank_index(fit(1:np), ord(1:np))
         nsucc = 0

         do i = 1, np
            ! --- adaptive control parameters --------------------------------
            cri = min(one, max(zero, mu_cr + 0.1_wp * rng%normal()))
            do
               fi = mu_f + 0.1_wp * rng%cauchy()
               if (fi > zero) exit
            end do
            fi = min(fi, one)

            ! --- current-to-pbest/1 with archive ------------------------------
            pb = ord(rng%randint(1, max(2, nint(o%de_pbest * real(np, wp)))))
            do
               r1 = rng%randint(1, np)
               if (r1 /= i) exit
            end do
            do
               r2 = rng%randint(1, np + narch)
               if (r2 /= i .and. r2 /= r1) exit
            end do

            jrand = rng%randint(1, n)
            do j = 1, n
               if (rng%uniform() <= cri .or. j == jrand) then
                  if (r2 <= np) then
                     trial(j, i) = pop(j, i) + fi * (pop(j, pb) - pop(j, i)) &
                                   + fi * (pop(j, r1) - pop(j, r2))
                  else
                     trial(j, i) = pop(j, i) + fi * (pop(j, pb) - pop(j, i)) &
                                   + fi * (pop(j, r1) - arch(j, r2 - np))
                  end if
                  ! midpoint bounce-back keeps diversity at the walls
                  if (trial(j, i) < lb(j)) trial(j, i) = half * (lb(j) + pop(j, i))
                  if (trial(j, i) > ub(j)) trial(j, i) = half * (ub(j) + pop(j, i))
               else
                  trial(j, i) = pop(j, i)
               end if
            end do
            sf(i) = fi; scr(i) = cri
         end do

         call ev%fbatch(trial(:, 1:np), ftrial(1:np))

         ! --- selection, archive and parameter adaptation --------------------
         sum1 = zero; sum2 = zero; fmean = zero
         do i = 1, np
            if (ftrial(i) <= fit(i)) then
               if (ftrial(i) < fit(i)) then
                  nsucc = nsucc + 1
                  sum1 = sum1 + sf(i)**2         ! Lehmer mean numerator
                  sum2 = sum2 + sf(i)
                  fmean = fmean + scr(i)
                  if (narch < maxarch) then
                     narch = narch + 1
                     arch(:, narch) = pop(:, i)
                  else
                     arch(:, rng%randint(1, maxarch)) = pop(:, i)
                  end if
               end if
               pop(:, i) = trial(:, i)
               fit(i) = ftrial(i)
            end if
         end do
         if (nsucc > 0 .and. o%de_adaptive) then
            mu_f = (one - c_adapt) * mu_f + c_adapt * sum1 / max(sum2, opt_tiny)
            mu_cr = (one - c_adapt) * mu_cr + c_adapt * fmean / real(nsucc, wp)
         end if

         ibest = minloc(fit(1:np), dim=1)
         spread = maxval(fit(1:np)) - fit(ibest)

         if (o%verbose >= 2 .and. mod(gen - 1, max(1, o%print_every)) == 0) &
            write (o%unit, '(a,i6,a,i8,a,es20.12,a,es11.3,a,i4)') '  gen ', gen, &
            '  nf ', ev%nfev, '  f ', fit(ibest), '  spread ', spread, '  np ', np

         if (spread <= o%tol_f * (abs(fit(ibest)) + o%tol_f)) then
            res%status = OPT_CONV_F; exit
         end if

         ! --- linear population size reduction --------------------------------
         if (o%de_lpsr .and. o%max_feval > 0) then
            k = nint(real(np0, wp) - real(np0 - np_min, wp) * &
                     real(ev%nfev, wp) / real(o%max_feval, wp))
            k = max(np_min, min(np, k))
            if (k < np) then
               call rank_index(fit(1:np), ord(1:np))
               do i = 1, k
                  trial(:, i) = pop(:, ord(i))
                  ftrial(i) = fit(ord(i))
               end do
               pop(:, 1:k) = trial(:, 1:k)
               fit(1:k) = ftrial(1:k)
               np = k
            end if
         end if
         if (gen == o%max_iter) res%status = OPT_MAX_ITER
      end do

      ibest = minloc(fit(1:np), dim=1)
      res%x = pop(:, ibest)
      res%f = fit(ibest)
      if (ev%fbest < res%f) then
         res%x = ev%xbest; res%f = ev%fbest
      end if
      res%niter = gen
   end subroutine solve_de

end module fitpar_global_de
