!> FitPar -- DIVIDing RECTangles (DIRECT).
!>
!> The one deterministic global method here: no random numbers, no population,
!> no seed.  It partitions the box into hyperrectangles and, at each pass,
!> subdivides exactly those rectangles that could contain the optimum for
!> *some* value of the unknown Lipschitz constant.  That is the whole idea:
!> rather than guessing how rugged the objective is, it hedges across all
!> possible ruggedness levels simultaneously, balancing global search (large
!> rectangles) against local refinement (rectangles with low centre values).
!>
!> Properties that matter in practice:
!>   * fully reproducible -- two runs give bit-identical answers,
!>   * requires only bounds, no start point, no tuning,
!>   * converges to the global optimum for any continuous function,
!>   * cost grows quickly with dimension: excellent to n ~ 10, usable to ~ 20,
!>     hopeless beyond that.  Use it to locate the basin, then polish.
!>
!> The DIRECT-L variant (direct_local = .true.) measures rectangles by their
!> longest side instead of their diagonal, which biases the search toward
!> local refinement and is usually faster when the objective has few minima.
!>
!> Reference: Jones, Perttunen & Stuckman (1993); Gablonsky & Kelley (2001).
module fitpar_global_direct
   use fitpar_kinds
   use fitpar_types
   use fitpar_eval
   use fitpar_globutil
   implicit none
   private
   public :: solve_direct

   integer, parameter :: init_cap = 4096

contains

   subroutine solve_direct(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      real(wp), allocatable :: cen(:, :), fv(:), dsz(:)
      integer, allocatable  :: lev(:, :)
      real(wp), allocatable :: lb(:), ub(:), xw(:), cnew(:), cb(:)
      integer, allocatable  :: lbv(:)
      real(wp), allocatable :: wmin(:), fplus(:), fminus(:)
      integer, allocatable  :: dims(:), dord(:), po(:), iz(:)
      real(wp), allocatable :: dz(:), fz(:)
      real(wp) :: fmin, delta, kleft, kright, slope, eps_abs
      integer  :: n, nr, cap, iter, i, j, k, id, npo, ibest, nd, nz, nz_max
      logical  :: pot

      n = p%n
      call get_box(p, x, lb, ub)
      cap = init_cap
      allocate (cen(n, cap), fv(cap), dsz(cap), lev(n, cap))
      allocate (xw(n), cnew(n), wmin(n), fplus(n), fminus(n), cb(n), lbv(n))
      allocate (dims(n), dord(n))
      nz_max = 8192
      allocate (dz(nz_max), fz(nz_max), iz(nz_max), po(nz_max))

      ! --- the whole box is rectangle 1, centre evaluated -------------------
      nr = 1
      cen(:, 1) = half
      lev(:, 1) = 0
      xw = lb + cen(:, 1) * (ub - lb)
      fv(1) = ev%f(xw)
      dsz(1) = rect_size(lev(:, 1), n, o%direct_local)
      fmin = fv(1); ibest = 1
      res%status = OPT_MAX_FEVAL

      do iter = 1, o%max_iter
         if (ev%stop_flag) then
            res%status = ev%stop_code; exit
         end if

         ! --- identify potentially optimal rectangles ------------------------
         !
         ! Only the best rectangle of each size can be potentially optimal, so
         ! collapse to size classes first.  This turns the selection from
         ! O(nrect^2) -- which becomes the bottleneck once there are tens of
         ! thousands of rectangles -- into O(nrect * nclass) with nclass small.
         nz = 0
         do i = 1, nr
            k = 0
            do j = 1, nz
               if (abs(dsz(i) - dz(j)) <= 1.0e-12_wp * dz(j)) then
                  k = j; exit
               end if
            end do
            if (k == 0) then
               if (nz >= nz_max) cycle
               nz = nz + 1
               dz(nz) = dsz(i); fz(nz) = fv(i); iz(nz) = i
            else if (fv(i) < fz(k)) then
               fz(k) = fv(i); iz(k) = i
            end if
         end do

         ! A class is potentially optimal when a line of some positive slope K
         ! through (d_j, f_j) lies below every other class and reaches at least
         ! eps below the incumbent:  f_j - K d_j <= f_min - eps |f_min|.
         eps_abs = o%direct_eps * abs(fmin)
         npo = 0
         do i = 1, nz
            kleft = zero
            kright = opt_huge
            do j = 1, nz
               if (j == i) cycle
               if (dz(j) < dz(i)) then
                  kleft = max(kleft, (fz(i) - fz(j)) / (dz(i) - dz(j)))
               else if (dz(j) > dz(i)) then
                  kright = min(kright, (fz(j) - fz(i)) / (dz(j) - dz(i)))
               end if
            end do
            if (kright < kleft) cycle
            if (kright >= opt_huge) then
               pot = .true.                      ! largest class: always explored
            else
               pot = (fz(i) - kright * dz(i) <= fmin - eps_abs)
            end if
            if (pot) then
               npo = npo + 1
               po(npo) = iz(i)
            end if
         end do
         if (npo == 0) then
            res%status = OPT_STAGNATED; exit
         end if

         ! --- subdivide each of them -------------------------------------------
         do k = 1, npo
            id = po(k)
            nd = 0
            do i = 1, n                              ! dimensions with longest side
               if (lev(i, id) == minval(lev(:, id))) then
                  nd = nd + 1
                  dims(nd) = i
               end if
            end do
            delta = (one / three)**(minval(lev(:, id)) + 1)

            do i = 1, nd
               cnew = cen(:, id); cnew(dims(i)) = cnew(dims(i)) + delta
               xw = lb + cnew * (ub - lb)
               fplus(i) = ev%f(xw)
               cnew = cen(:, id); cnew(dims(i)) = cnew(dims(i)) - delta
               xw = lb + cnew * (ub - lb)
               fminus(i) = ev%f(xw)
               wmin(i) = min(fplus(i), fminus(i))
            end do
            call order_by(wmin(1:nd), dord(1:nd))

            do i = 1, nd
               j = dims(dord(i))
               lev(j, id) = lev(j, id) + 1           ! the surviving middle third
               ! Snapshot the parent into scratch space.  Passing cen(:,id)
               ! directly would alias the very array push_rect may reallocate,
               ! leaving the dummy argument dangling after move_alloc.
               cb = cen(:, id)
               lbv = lev(:, id)
               call push_rect(cen, fv, dsz, lev, nr, cap, n, &
                              cb, lbv, j, +delta, fplus(dord(i)), o%direct_local)
               call push_rect(cen, fv, dsz, lev, nr, cap, n, &
                              cb, lbv, j, -delta, fminus(dord(i)), o%direct_local)
            end do
            dsz(id) = rect_size(lev(:, id), n, o%direct_local)
            if (ev%stop_flag) exit
         end do

         ibest = minloc(fv(1:nr), dim=1)
         fmin = fv(ibest)
         if (o%verbose >= 2 .and. mod(iter - 1, max(1, o%print_every)) == 0) &
            write (o%unit, '(a,i6,a,i8,a,es20.12,a,i7)') '  pass ', iter, &
            '  nf ', ev%nfev, '  f ', fmin, '  rects ', nr
         if (maxval(dsz(1:nr)) < o%tol_x) then
            res%status = OPT_CONV_X; exit
         end if
         if (nr > 20 * o%max_feval + 1000) then
            res%status = OPT_STAGNATED; exit
         end if
         if (iter == o%max_iter) res%status = OPT_MAX_ITER
      end do

      ibest = minloc(fv(1:nr), dim=1)
      res%x = lb + cen(:, ibest) * (ub - lb)
      res%f = fv(ibest)
      if (ev%fbest < res%f) then
         res%x = ev%xbest; res%f = ev%fbest
      end if
      res%niter = iter
   end subroutine solve_direct

   pure real(wp) function rect_size(lv, n, local) result(d)
      integer, intent(in) :: lv(:), n
      logical, intent(in) :: local
      real(wp) :: side(n)
      integer :: i
      do i = 1, n
         side(i) = (one / three)**lv(i)
      end do
      if (local) then
         d = half * maxval(side)             ! DIRECT-L
      else
         d = half * sqrt(sum(side**2))       ! Jones' original measure
      end if
   end function rect_size

   subroutine push_rect(cen, fv, dsz, lev, nr, cap, n, cbase, lbase, jdim, shift, fval, local)
      real(wp), allocatable, intent(inout) :: cen(:, :), fv(:), dsz(:)
      integer, allocatable, intent(inout)  :: lev(:, :)
      integer, intent(inout) :: nr, cap
      integer, intent(in)    :: n, jdim
      real(wp), intent(in)   :: cbase(:), shift, fval
      integer, intent(in)    :: lbase(:)
      logical, intent(in)    :: local
      real(wp), allocatable :: t2(:, :), t1(:)
      integer, allocatable  :: l2(:, :)

      if (nr + 1 > cap) then                 ! grow by doubling
         allocate (t2(n, 2 * cap)); t2(:, 1:cap) = cen; call move_alloc(t2, cen)
         allocate (l2(n, 2 * cap)); l2(:, 1:cap) = lev; call move_alloc(l2, lev)
         allocate (t1(2 * cap)); t1(1:cap) = fv; call move_alloc(t1, fv)
         allocate (t1(2 * cap)); t1(1:cap) = dsz; call move_alloc(t1, dsz)
         cap = 2 * cap
      end if
      nr = nr + 1
      cen(:, nr) = cbase
      cen(jdim, nr) = cbase(jdim) + shift
      lev(:, nr) = lbase
      fv(nr) = fval
      dsz(nr) = rect_size(lev(:, nr), n, local)
   end subroutine push_rect

   pure subroutine order_by(v, idx)
      real(wp), intent(in) :: v(:)
      integer, intent(out) :: idx(:)
      integer :: i, j, t
      do i = 1, size(v)
         idx(i) = i
      end do
      do i = 2, size(v)
         t = idx(i); j = i - 1
         do while (j >= 1)
            if (v(idx(j)) <= v(t)) exit
            idx(j + 1) = idx(j); j = j - 1
         end do
         idx(j + 1) = t
      end do
   end subroutine order_by

end module fitpar_global_direct
