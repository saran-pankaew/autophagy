!> FitPar -- self-contained dense linear algebra.
!>
!> Deliberately LAPACK-free so the library builds anywhere with one command.
!> All routines are O(n^3) at worst and n is the number of *parameters*, which
!> in practice is small (tens to low hundreds); the objective function, not the
!> algebra, dominates the cost.
module fitpar_linalg
   use fitpar_kinds
   implicit none
   private

   public :: cholesky_factor, cholesky_solve, cholesky_inverse
   public :: jacobi_eigen, sym_pinv, sym_sqrt_inv
   public :: outer_update, norm2v, condest_sym

contains

   !> Euclidean norm, overflow-safe.
   pure real(wp) function norm2v(v)
      real(wp), intent(in) :: v(:)
      real(wp) :: s
      s = maxval(abs(v))
      if (s <= zero) then
         norm2v = zero
      else
         norm2v = s * sqrt(sum((v / s)**2))
      end if
   end function norm2v

   !> In-place Cholesky A = L L^T (lower triangle used and overwritten).
   !> info = 0 on success, k>0 if the matrix was not positive definite at row k.
   pure subroutine cholesky_factor(a, info)
      real(wp), intent(inout) :: a(:, :)
      integer, intent(out)    :: info
      integer  :: i, j, k, n
      real(wp) :: s
      n = size(a, 1)
      info = 0
      do j = 1, n
         s = a(j, j) - sum(a(j, 1:j - 1)**2)
         if (s <= zero) then
            info = j
            return
         end if
         a(j, j) = sqrt(s)
         do i = j + 1, n
            s = a(i, j)
            do k = 1, j - 1
               s = s - a(i, k) * a(j, k)
            end do
            a(i, j) = s / a(j, j)
         end do
      end do
   end subroutine cholesky_factor

   !> Solve L L^T x = b given the factor from cholesky_factor.
   pure subroutine cholesky_solve(l, b, x)
      real(wp), intent(in)  :: l(:, :), b(:)
      real(wp), intent(out) :: x(:)
      integer  :: i, n
      real(wp) :: s
      n = size(b)
      do i = 1, n                              ! forward substitution
         s = b(i) - sum(l(i, 1:i - 1) * x(1:i - 1))
         x(i) = s / l(i, i)
      end do
      do i = n, 1, -1                          ! back substitution
         s = x(i) - sum(l(i + 1:n, i) * x(i + 1:n))
         x(i) = s / l(i, i)
      end do
   end subroutine cholesky_solve

   !> Inverse of a symmetric positive definite matrix (full symmetric result).
   subroutine cholesky_inverse(a, ainv, info)
      real(wp), intent(in)  :: a(:, :)
      real(wp), intent(out) :: ainv(:, :)
      integer, intent(out)  :: info
      real(wp), allocatable :: l(:, :), e(:), c(:)
      integer :: n, j
      n = size(a, 1)
      allocate (l(n, n), e(n), c(n))
      l = a
      call cholesky_factor(l, info)
      if (info /= 0) return
      do j = 1, n
         e = zero; e(j) = one
         call cholesky_solve(l, e, c)
         ainv(:, j) = c
      end do
      ainv = half * (ainv + transpose(ainv))   ! symmetrise against round-off
   end subroutine cholesky_inverse

   !> Cyclic Jacobi eigensolver for real symmetric matrices.
   !> Returns eigenvalues in ascending order and orthonormal eigenvectors in
   !> the columns of v.  Slower than LAPACK but bullet-proof and dependency-free.
   subroutine jacobi_eigen(ain, d, v, info)
      real(wp), intent(in)  :: ain(:, :)
      real(wp), intent(out) :: d(:), v(:, :)
      integer, intent(out)  :: info
      real(wp), allocatable :: a(:, :), b(:), z(:)
      real(wp) :: sm, tresh, g, h, t, theta, c, s, tau, tmp
      integer  :: n, ip, iq, i, j, sweep
      integer, parameter :: max_sweep = 100

      n = size(ain, 1)
      allocate (a(n, n), b(n), z(n))
      a = ain
      info = 0
      v = zero
      do i = 1, n
         v(i, i) = one
      end do
      do i = 1, n
         b(i) = a(i, i); d(i) = a(i, i)
      end do
      z = zero

      do sweep = 1, max_sweep
         sm = zero
         do ip = 1, n - 1
            sm = sm + sum(abs(a(ip, ip + 1:n)))
         end do
         if (sm == zero) exit
         if (sweep < 4) then
            tresh = 0.2_wp * sm / real(n * n, wp)
         else
            tresh = zero
         end if
         do ip = 1, n - 1
            do iq = ip + 1, n
               g = 100.0_wp * abs(a(ip, iq))
               if ((sweep > 4) .and. (abs(d(ip)) + g == abs(d(ip))) &
                   .and. (abs(d(iq)) + g == abs(d(iq)))) then
                  a(ip, iq) = zero
               else if (abs(a(ip, iq)) > tresh) then
                  h = d(iq) - d(ip)
                  if (abs(h) + g == abs(h)) then
                     t = a(ip, iq) / h
                  else
                     theta = half * h / a(ip, iq)
                     t = one / (abs(theta) + sqrt(one + theta**2))
                     if (theta < zero) t = -t
                  end if
                  c = one / sqrt(one + t**2)
                  s = t * c
                  tau = s / (one + c)
                  h = t * a(ip, iq)
                  z(ip) = z(ip) - h; z(iq) = z(iq) + h
                  d(ip) = d(ip) - h; d(iq) = d(iq) + h
                  a(ip, iq) = zero
                  do j = 1, ip - 1
                     g = a(j, ip); h = a(j, iq)
                     a(j, ip) = g - s * (h + g * tau)
                     a(j, iq) = h + s * (g - h * tau)
                  end do
                  do j = ip + 1, iq - 1
                     g = a(ip, j); h = a(j, iq)
                     a(ip, j) = g - s * (h + g * tau)
                     a(j, iq) = h + s * (g - h * tau)
                  end do
                  do j = iq + 1, n
                     g = a(ip, j); h = a(iq, j)
                     a(ip, j) = g - s * (h + g * tau)
                     a(iq, j) = h + s * (g - h * tau)
                  end do
                  do j = 1, n
                     g = v(j, ip); h = v(j, iq)
                     v(j, ip) = g - s * (h + g * tau)
                     v(j, iq) = h + s * (g - h * tau)
                  end do
               end if
            end do
         end do
         b = b + z
         d = b
         z = zero
         if (sweep == max_sweep) info = 1
      end do

      ! ascending sort (selection sort; n is small)
      do i = 1, n - 1
         j = minloc(d(i:n), dim=1) + i - 1
         if (j /= i) then
            tmp = d(i); d(i) = d(j); d(j) = tmp
            do ip = 1, n
               tmp = v(ip, i); v(ip, i) = v(ip, j); v(ip, j) = tmp
            end do
         end if
      end do
   end subroutine jacobi_eigen

   !> Moore-Penrose pseudo-inverse of a symmetric matrix, with diagonal
   !> equilibration and eigenvalue truncation.
   !>
   !> The equilibration is essential and is where naive implementations go
   !> wrong.  For a fit whose parameters differ by six orders of magnitude
   !> (say an amplitude ~ 1e2 and a rate ~ 1e-4) the normal matrix J^T J has a
   !> condition number ~ 1e13 purely because of the choice of units.  Inverting
   !> it directly, or truncating its small eigenvalues, throws away a perfectly
   !> well-determined parameter and returns nonsense error bars.  Scaling to a
   !> unit diagonal first removes that artefact, so only *genuine* degeneracy
   !> is truncated.
   subroutine sym_pinv(a, ainv, rank, rcond_in)
      real(wp), intent(in)           :: a(:, :)
      real(wp), intent(out)          :: ainv(:, :)
      integer, intent(out)           :: rank
      real(wp), intent(in), optional :: rcond_in
      real(wp), allocatable :: d(:), v(:, :), sc(:), as(:, :)
      real(wp) :: rcond, cut
      integer  :: n, i, j, info
      n = size(a, 1)
      rcond = 1.0e-12_wp
      if (present(rcond_in)) rcond = rcond_in
      allocate (d(n), v(n, n), sc(n), as(n, n))

      do i = 1, n
         if (a(i, i) > zero) then
            sc(i) = one / sqrt(a(i, i))
         else
            sc(i) = one
         end if
      end do
      do j = 1, n
         do i = 1, n
            as(i, j) = a(i, j) * sc(i) * sc(j)
         end do
      end do

      call jacobi_eigen(as, d, v, info)
      cut = rcond * maxval(abs(d))
      rank = 0
      ainv = zero
      do i = 1, n
         if (d(i) > cut) then
            rank = rank + 1
            call outer_update(ainv, v(:, i), one / d(i))
         end if
      end do
      do j = 1, n                                  ! undo the equilibration
         do i = 1, n
            ainv(i, j) = ainv(i, j) * sc(i) * sc(j)
         end do
      end do
   end subroutine sym_pinv

   !> C <- C + alpha * u u^T
   pure subroutine outer_update(c, u, alpha)
      real(wp), intent(inout) :: c(:, :)
      real(wp), intent(in)    :: u(:), alpha
      integer :: i
      do i = 1, size(u)
         c(:, i) = c(:, i) + alpha * u * u(i)
      end do
   end subroutine outer_update

   !> B = A^{-1/2} for symmetric positive definite A (used by CMA-ES).
   subroutine sym_sqrt_inv(a, b, info)
      real(wp), intent(in)  :: a(:, :)
      real(wp), intent(out) :: b(:, :)
      integer, intent(out)  :: info
      real(wp), allocatable :: d(:), v(:, :)
      integer :: n, i
      n = size(a, 1)
      allocate (d(n), v(n, n))
      call jacobi_eigen(a, d, v, info)
      if (any(d <= zero)) then
         info = -1
         where (d <= zero) d = opt_eps
      end if
      b = zero
      do i = 1, n
         call outer_update(b, v(:, i), one / sqrt(d(i)))
      end do
   end subroutine sym_sqrt_inv

   !> Cheap 2-norm condition estimate of a symmetric matrix.
   real(wp) function condest_sym(a)
      real(wp), intent(in) :: a(:, :)
      real(wp), allocatable :: d(:), v(:, :)
      integer :: n, info
      n = size(a, 1)
      allocate (d(n), v(n, n))
      call jacobi_eigen(a, d, v, info)
      if (minval(abs(d)) <= opt_tiny) then
         condest_sym = opt_huge
      else
         condest_sym = maxval(abs(d)) / minval(abs(d))
      end if
   end function condest_sym

end module fitpar_linalg
