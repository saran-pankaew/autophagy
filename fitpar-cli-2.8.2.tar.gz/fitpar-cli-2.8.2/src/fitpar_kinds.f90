!> FitPar -- Modern Fortran optimization suite
!> Module: kinds, constants and small numeric helpers.
module fitpar_kinds
   use, intrinsic :: iso_fortran_env, only: real32, real64, int32, int64, &
                                            output_unit, error_unit
   implicit none
   public

   !> Working precision.  Change to real32 only if you know what you are doing;
   !> every algorithm here assumes at least ~1e-16 relative precision.
   integer, parameter :: wp = real64

   real(wp), parameter :: zero  = 0.0_wp
   real(wp), parameter :: half  = 0.5_wp
   real(wp), parameter :: one   = 1.0_wp
   real(wp), parameter :: two   = 2.0_wp
   real(wp), parameter :: three = 3.0_wp
   real(wp), parameter :: ten   = 10.0_wp

   real(wp), parameter :: opt_eps  = epsilon(1.0_wp)
   real(wp), parameter :: opt_tiny = tiny(1.0_wp)
   real(wp), parameter :: opt_huge = huge(1.0_wp)
   real(wp), parameter :: opt_big  = 1.0e100_wp     !< used as "infeasible" value
   real(wp), parameter :: pi       = acos(-1.0_wp)

contains

   !> True when x is neither NaN nor +/-Infinity.
   elemental logical function is_finite(x)
      real(wp), intent(in) :: x
      is_finite = (x == x) .and. (abs(x) <= opt_huge)
   end function is_finite

   !> Safe relative difference, |a-b| / max(1,|a|,|b|).
   elemental real(wp) function reldiff(a, b)
      real(wp), intent(in) :: a, b
      reldiff = abs(a - b) / max(one, abs(a), abs(b))
   end function reldiff

   !> Wall-clock seconds since an arbitrary epoch (monotonic within a run).
   real(wp) function opt_wtime()
      integer(int64) :: c, r
      call system_clock(count=c, count_rate=r)
      if (r > 0_int64) then
         opt_wtime = real(c, wp) / real(r, wp)
      else
         opt_wtime = zero
      end if
   end function opt_wtime

end module fitpar_kinds
