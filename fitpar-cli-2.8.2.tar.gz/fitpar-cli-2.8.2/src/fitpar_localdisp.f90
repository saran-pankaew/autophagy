!> FitPar -- dispatch to a local solver by name/id.
!> Kept in its own module so that both the top-level API and the multistart
!> family can refine a point without circular dependencies.
module fitpar_localdisp
   use fitpar_kinds
   use fitpar_types
   use fitpar_eval
   use fitpar_local_quasi
   use fitpar_local_dfo
   use fitpar_local_newton
   use fitpar_lsq
   use fitpar_lsq_dfogn
   implicit none
   private
   public :: run_local, default_local_for

contains

   !> Sensible local method for a given problem when the user did not choose.
   integer function default_local_for(p) result(id)
      type(opt_problem), intent(in) :: p
      if (p%is_lsq()) then
         id = M_LEVMAR
      else if (associated(p%grad) .or. associated(p%fungrad)) then
         id = M_LBFGSB
      else if (p%n <= 8) then
         id = M_POWELL           ! very accurate without derivatives
      else
         id = M_LBFGSB           ! finite-difference gradients still win at scale
      end if
   end function default_local_for

   subroutine run_local(id, ev, p, o, x, res)
      integer, intent(in)              :: id
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(inout) :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res
      integer :: use_id

      use_id = id
      if (use_id == M_AUTO) use_id = default_local_for(p)
      if ((use_id == M_LEVMAR .or. use_id == M_DFOGN) .and. .not. p%is_lsq()) use_id = M_LBFGSB

      select case (use_id)
      case (M_NELDER_MEAD); call solve_nelder_mead(ev, p, o, x, res)
      case (M_POWELL);      call solve_powell(ev, p, o, x, res)
      case (M_TRUST_NCG);   call solve_trust_ncg(ev, p, o, x, res)
      case (M_CG);          call solve_cg(ev, p, o, x, res)
      case (M_LEVMAR);      call solve_levmar(ev, p, o, x, res)
      case (M_DFOGN);       call solve_dfogn(ev, p, o, x, res)
      case default;         call solve_lbfgsb(ev, p, o, x, res)
      end select
      res%method = method_name(use_id)
   end subroutine run_local

end module fitpar_localdisp
