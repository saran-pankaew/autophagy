!> FitPar -- hybrid global strategies built on top of the local solvers.
!>
!> solve_multistart : sample the box, screen the samples cheaply, then run a
!>   local solver from the most promising ones.  Simple, embarrassingly
!>   parallel in spirit, and surprisingly hard to beat when local searches are
!>   cheap.
!>
!> solve_mlsl : Multi-Level Single Linkage (Rinnooy Kan & Timmer).  The same
!>   idea done properly: a local search is started from a sample point only if
!>   no better sample lies within a critical radius that shrinks as the sample
!>   grows.  Under mild assumptions it finds every local minimum with
!>   probability one while starting only finitely many local searches -- i.e.
!>   it stops wasting effort re-descending into basins it has already found.
!>
!> solve_basinhop : local minimisation interleaved with Metropolis-accepted
!>   perturbations (Wales & Doye).  The objective is effectively replaced by
!>   its "basin envelope", which removes the barriers between minima.  The
!>   perturbation size self-adjusts toward a 50% acceptance rate.  This is the
!>   method of choice for funnel-shaped landscapes such as cluster energies.
module fitpar_global_multi
   use fitpar_kinds
   use fitpar_types
   use fitpar_eval
   use fitpar_rng
   use fitpar_globutil
   use fitpar_localdisp
   implicit none
   private
   public :: solve_multistart, solve_mlsl, solve_basinhop

contains

   subroutine solve_multistart(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(inout) :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      real(wp), allocatable :: lb(:), ub(:), pts(:, :), fs(:), xl(:)
      integer, allocatable  :: ord(:)
      type(opt_options) :: lo
      type(opt_result)  :: lr
      type(rng_t) :: rng
      integer :: n, npts, i, k, local_id, nstart
      real(wp) :: fbest

      n = p%n
      call get_box(p, x, lb, ub)
      call rng%seed(o%seed)
      npts = o%ms_points
      if (npts <= 0) npts = max(20, 10 * n)
      allocate (pts(n, npts), fs(npts), ord(npts), xl(n))

      call sample_lhs(rng, lb, ub, pts)
      pts(:, 1) = x
      call ev%fbatch(pts, fs)
      call rank_index(fs, ord)

      lo = o
      lo%verbose = max(0, o%verbose - 2)
      local_id = method_id(o%local_method)
      if (local_id < 0) local_id = M_AUTO
      nstart = max(1, npts / 4)
      fbest = opt_huge
      res%status = OPT_MAX_FEVAL
      res%x = pts(:, ord(1)); res%f = fs(ord(1))

      do k = 1, nstart
         if (ev%stop_flag) exit
         i = ord(k)
         xl = pts(:, i)
         lo%max_feval = ev%nfev + max(200, ev%budget_left() / max(1, nstart - k + 1))
         call run_local(local_id, ev, p, lo, xl, lr)
         if (lr%f < fbest) then
            fbest = lr%f
            res%x = lr%x; res%f = lr%f
            if (allocated(lr%g)) res%g = lr%g
            res%gnorm = lr%gnorm
         end if
         if (o%verbose >= 2) &
            write (o%unit, '(a,i5,a,i8,a,es20.12,a,es20.12)') '  start ', k, &
            '  nf ', ev%nfev, '  f_local ', lr%f, '  best ', fbest
      end do

      if (ev%fbest < res%f) then
         res%x = ev%xbest; res%f = ev%fbest
      end if
      res%niter = nstart
      if (ev%stop_flag) res%status = ev%stop_code
   end subroutine solve_multistart

   !--------------------------------------------------------------------------

   subroutine solve_mlsl(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(inout) :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      real(wp), allocatable :: lb(:), ub(:), width(:)
      real(wp), allocatable :: sp(:, :), sf(:), mins(:, :), fmins(:), xl(:), u(:)
      integer, allocatable  :: ord(:)
      type(opt_options) :: lo
      type(opt_result)  :: lr
      type(rng_t) :: rng
      integer  :: n, batch, nsamp, nmin, maxmin, maxsamp, i, j, k, it, local_id
      real(wp) :: logr, rk, d2, fbest, sigma_mlsl
      logical  :: start_here

      n = p%n
      call get_box(p, x, lb, ub)
      allocate (width(n)); width = max(ub - lb, opt_tiny)
      call rng%seed(o%seed)

      batch = o%ms_points
      if (batch <= 0) batch = max(10, 4 * n)
      maxsamp = max(batch * 200, 2000)
      maxmin = 200
      allocate (sp(n, maxsamp), sf(maxsamp), ord(maxsamp))
      allocate (mins(n, maxmin), fmins(maxmin), xl(n), u(n))
      nsamp = 0; nmin = 0
      fbest = opt_huge
      sigma_mlsl = 4.0_wp
      lo = o
      lo%verbose = max(0, o%verbose - 2)
      local_id = method_id(o%local_method)
      if (local_id < 0) local_id = M_AUTO
      res%status = OPT_MAX_FEVAL
      res%x = x; res%f = opt_huge

      do it = 1, o%max_iter
         if (ev%stop_flag .or. nsamp + batch > maxsamp) exit

         ! --- add a fresh batch of sample points (unit-box coordinates) -------
         do k = 1, batch
            nsamp = nsamp + 1
            if (nsamp == 1) then
               sp(:, 1) = (x - lb) / width
               call clamp01(sp(:, 1))
            else
               call rng%uniform_v(u)
               sp(:, nsamp) = u
            end if
            xl = lb + sp(:, nsamp) * width
            sf(nsamp) = ev%f(xl)
         end do

         ! --- critical radius (Rinnooy Kan & Timmer, unit-volume box) ---------
         logr = -half * log(pi) + (log_gamma(one + half * real(n, wp)) &
                                   + log(sigma_mlsl) &
                                   + log(log(real(nsamp, wp)) / real(nsamp, wp))) / real(n, wp)
         rk = exp(logr)

         call rank_index(sf(1:nsamp), ord(1:nsamp))

         ! --- single-linkage rule -----------------------------------------------
         do k = 1, nsamp
            i = ord(k)
            if (ev%stop_flag) exit
            start_here = .true.
            do j = 1, nsamp                      ! a better sample nearby?
               if (sf(j) < sf(i)) then
                  d2 = sqrt(sum((sp(:, i) - sp(:, j))**2))
                  if (d2 < rk) then
                     start_here = .false.; exit
                  end if
               end if
            end do
            if (start_here) then
               do j = 1, nmin                    ! already inside a known basin?
                  d2 = sqrt(sum((sp(:, i) - (mins(:, j) - lb) / width)**2))
                  if (d2 < rk) then
                     start_here = .false.; exit
                  end if
               end do
            end if
            if (.not. start_here) cycle

            xl = lb + sp(:, i) * width
            lo%max_feval = ev%nfev + max(200, ev%budget_left() / 4)
            call run_local(local_id, ev, p, lo, xl, lr)
            if (nmin < maxmin) then
               nmin = nmin + 1
               mins(:, nmin) = lr%x
               fmins(nmin) = lr%f
            end if
            if (lr%f < fbest) then
               fbest = lr%f
               res%x = lr%x; res%f = lr%f
               res%gnorm = lr%gnorm
               if (allocated(lr%g)) res%g = lr%g
            end if
            if (o%verbose >= 2) &
               write (o%unit, '(a,i5,a,i8,a,es20.12,a,es12.4)') '  minima ', nmin, &
               '  nf ', ev%nfev, '  best ', fbest, '  r_k ', rk
         end do
         if (it == o%max_iter) res%status = OPT_MAX_ITER
      end do

      if (ev%fbest < res%f) then
         res%x = ev%xbest; res%f = ev%fbest
      end if
      res%niter = nmin
      if (ev%stop_flag) res%status = ev%stop_code
   end subroutine solve_mlsl

   pure subroutine clamp01(v)
      real(wp), intent(inout) :: v(:)
      v = max(zero, min(one, v))
   end subroutine clamp01

   !--------------------------------------------------------------------------

   subroutine solve_basinhop(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(inout) :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      real(wp), allocatable :: lb(:), ub(:), width(:), xcur(:), xtry(:), xbest(:)
      type(opt_options) :: lo
      type(opt_result)  :: lr
      type(rng_t) :: rng
      real(wp) :: fcur, ftry, fbest, step, acc_rate, temp
      integer  :: n, it, i, local_id, nacc, ntry

      n = p%n
      call get_box(p, x, lb, ub)
      allocate (width(n)); width = ub - lb
      allocate (xcur(n), xtry(n), xbest(n))
      call rng%seed(o%seed)
      lo = o
      lo%verbose = max(0, o%verbose - 2)
      local_id = method_id(o%local_method)
      if (local_id < 0) local_id = M_AUTO
      step = o%bh_step
      temp = o%bh_temp

      xcur = x
      call p%clip(xcur)
      lo%max_feval = ev%nfev + max(200, ev%budget_left() / 10)
      call run_local(local_id, ev, p, lo, xcur, lr)
      fcur = lr%f; xcur = lr%x
      xbest = xcur; fbest = fcur
      nacc = 0; ntry = 0
      res%status = OPT_MAX_FEVAL

      do it = 1, o%max_iter
         if (ev%stop_flag) exit
         do i = 1, n                                  ! perturb
            xtry(i) = xcur(i) + step * width(i) * (two * rng%uniform() - one)
         end do
         call p%clip(xtry)
         lo%max_feval = ev%nfev + max(200, ev%budget_left() / 4)
         call run_local(local_id, ev, p, lo, xtry, lr)
         ftry = lr%f
         ntry = ntry + 1

         if (ftry < fcur .or. rng%uniform() < exp(-(ftry - fcur) / max(temp, opt_tiny))) then
            xcur = lr%x; fcur = ftry
            nacc = nacc + 1
         end if
         if (ftry < fbest) then
            fbest = ftry; xbest = lr%x
         end if

         ! adapt the perturbation toward a 50% acceptance rate
         if (mod(it, 10) == 0) then
            acc_rate = real(nacc, wp) / real(max(1, ntry), wp)
            if (acc_rate > 0.5_wp) then
               step = min(step * 1.2_wp, half)
            else
               step = max(step / 1.2_wp, 1.0e-6_wp)
            end if
            nacc = 0; ntry = 0
         end if

         if (o%verbose >= 2 .and. mod(it - 1, max(1, o%print_every)) == 0) &
            write (o%unit, '(a,i5,a,i8,a,es20.12,a,es10.3)') '  hop ', it, &
            '  nf ', ev%nfev, '  best ', fbest, '  step ', step
         if (it == o%max_iter) res%status = OPT_MAX_ITER
      end do

      res%x = xbest; res%f = fbest
      if (ev%fbest < res%f) then
         res%x = ev%xbest; res%f = ev%fbest
      end if
      res%niter = it
      if (ev%stop_flag) res%status = ev%stop_code
   end subroutine solve_basinhop

end module fitpar_global_multi
