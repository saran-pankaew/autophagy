!> FitPar -- nonlinear least squares.
!>
!> For a fitting code this is the routine that matters.  Given residuals
!>
!>     r_i(x) = (y_i - model_i(x)) / sigma_i        i = 1..m
!>
!> it minimises chi^2 = sum r_i^2 and -- just as importantly -- reports what
!> the fit is worth: parameter uncertainties, the covariance matrix and the
!> correlation matrix.  A fit without error bars is a number without a claim.
!>
!> Features beyond a textbook implementation:
!>   * Nielsen's damping update (smooth, no magic factor-of-10 ladder),
!>   * Marquardt diagonal scaling, so badly scaled parameters do not stall,
!>   * optional geodesic acceleration (Transtrum & Sethna 2012), which adds a
!>     second-order correction for one extra residual evaluation and often
!>     halves the iteration count on hard, curved problems,
!>   * box constraints by step projection,
!>   * pseudo-inverse covariance with rank detection, so a degenerate fit
!>     reports honest (large) errors instead of crashing.
module fitpar_lsq
   use fitpar_kinds
   use fitpar_types
   use fitpar_eval
   use fitpar_linalg
   implicit none
   private
   public :: solve_levmar

contains

   subroutine solve_levmar(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      real(wp), allocatable :: r(:), rt(:), rvv(:), jm(:, :), a(:, :), al(:, :)
      real(wp), allocatable :: g(:), delta(:), accel(:), xt(:), dg(:), cov(:, :)
      real(wp), allocatable :: damp(:)
      real(wp) :: chi2, chi2t, lambda, nu, rho, pred, gnorm, dnorm, xn
      real(wp) :: hacc, anorm, vnorm
      integer  :: n, m, iter, i, j, info, ntry
      logical  :: ok, accepted, use_accel

      n = p%n; m = p%m
      allocate (r(m), rt(m), rvv(m), jm(m, n), a(n, n), al(n, n))
      allocate (g(n), delta(n), accel(n), xt(n), dg(n), cov(n, n), damp(n))

      use_accel = .true.                 ! geodesic acceleration (cheap; helps)
      call p%clip(x)
      call ev%residual(x, r, ok)
      if (.not. ok) then
         res%status = OPT_USER_STOP
         res%message = 'residuals could not be evaluated at the start point'
         res%x = x; res%f = half * sum(r**2)
         return
      end if
      chi2 = sum(r**2)

      call ev%jacobian(x, r, jm)
      a = matmul(transpose(jm), jm)
      g = matmul(transpose(jm), r)
      dg = [(a(i, i), i=1, n)]
      lambda = o%lm_lambda0        ! dimensionless; the scale lives in damp(:)
      nu = two
      res%status = OPT_MAX_ITER

      do iter = 1, o%max_iter
         gnorm = maxval(abs(g))
         if (o%verbose >= 2 .and. mod(iter - 1, max(1, o%print_every)) == 0) &
            write (o%unit, '(a,i6,a,i8,a,es20.12,a,es11.3,a,es10.2)') '  it ', iter, &
            '  nf ', ev%nfev, '  chi2 ', chi2, '  |J^Tr| ', gnorm, '  lambda ', lambda
         if (gnorm <= o%tol_g) then
            res%status = OPT_CONV_G; exit
         end if
         if (ev%stop_flag) then
            res%status = ev%stop_code; exit
         end if

         accepted = .false.
         do ntry = 1, 30
            ! --- damped normal equations -------------------------------------
            ! Damping matrix.  lambda is kept dimensionless and the physical
            ! scale is carried by damp(:), so that lm_lambda0 means the same
            ! thing whatever units the parameters happen to have.
            if (o%lm_scaled) then
               do i = 1, n
                  damp(i) = lambda * max(a(i, i), 1.0e-10_wp * maxval(dg) + opt_tiny)
               end do
            else
               damp = lambda * max(maxval(dg), opt_tiny)
            end if
            al = a
            do i = 1, n
               al(i, i) = a(i, i) + damp(i)
            end do
            call cholesky_factor(al, info)
            if (info /= 0) then
               lambda = lambda * nu; nu = two * nu
               cycle
            end if
            call cholesky_solve(al, -g, delta)

            ! --- geodesic acceleration ----------------------------------------
            if (use_accel) then
               vnorm = sqrt(sum(delta**2))
               if (vnorm > opt_tiny) then
                  hacc = 0.1_wp
                  xt = x + hacc * delta
                  call p%clip(xt)
                  call ev%residual(xt, rt, ok)
                  if (ok) then
                     ! directional second derivative of r along delta
                     rvv = (two / hacc) * ((rt - r) / hacc - matmul(jm, delta))
                     call cholesky_solve(al, -matmul(transpose(jm), rvv), accel)
                     accel = half * accel
                     anorm = sqrt(sum(accel**2))
                     if (two * anorm <= 0.75_wp * vnorm) then
                        delta = delta + accel        ! accept the correction
                     end if
                  end if
               end if
            end if

            xt = x + delta
            call p%clip(xt)
            delta = xt - x                            ! the realised step
            call ev%residual(xt, rt, ok)
            if (.not. ok) then
               lambda = lambda * nu; nu = two * nu
               if (ev%stop_flag) exit
               cycle
            end if
            chi2t = sum(rt**2)

            ! predicted decrease of chi^2 (factor 2 from chi2 = 2F)
            pred = sum(damp * delta**2) - dot_product(delta, g)
            if (pred <= zero) pred = opt_tiny
            rho = (chi2 - chi2t) / pred

            if (rho > zero .and. chi2t < chi2) then
               accepted = .true.
               dnorm = maxval(abs(delta))
               xn = max(one, maxval(abs(x)))
               x = xt
               r = rt
               call ev%jacobian(x, r, jm)
               a = matmul(transpose(jm), jm)
               g = matmul(transpose(jm), r)
               dg = [(a(i, i), i=1, n)]
               lambda = max(lambda * max(one / three, one - (two * rho - one)**3), &
                            1.0e-14_wp)
               nu = two
               if (reldiff(chi2, chi2t) <= o%tol_f) then
                  chi2 = chi2t
                  res%status = OPT_CONV_F
                  exit
               end if
               if (dnorm <= o%tol_x * xn) then
                  chi2 = chi2t
                  res%status = OPT_CONV_X
                  exit
               end if
               chi2 = chi2t
               exit
            else
               lambda = lambda * nu
               nu = two * nu
               if (lambda > 1.0e18_wp) exit
            end if
            if (ev%stop_flag) exit
         end do

         if (.not. accepted) then
            if (res%status == OPT_MAX_ITER) res%status = OPT_STAGNATED
            exit
         end if
         if (res%status /= OPT_MAX_ITER) exit
         if (iter == o%max_iter) res%status = OPT_MAX_ITER
      end do

      ! ---------------------------------------------------------------------
      ! results and fit statistics
      ! ---------------------------------------------------------------------
      res%x = x
      res%f = half * chi2
      res%g = g
      res%gnorm = maxval(abs(g))
      res%niter = iter
      res%chi2 = chi2
      res%dof = max(1, m - n)
      res%redchi2 = chi2 / real(res%dof, wp)
      res%rms = sqrt(chi2 / real(m, wp))

      if (o%lm_covar) then
         call sym_pinv(a, cov, res%rank, 1.0e-12_wp)
         call mark_undetermined(a, cov, res)
         if (allocated(res%cov)) deallocate (res%cov)
         if (allocated(res%corr)) deallocate (res%corr)
         if (allocated(res%sigma)) deallocate (res%sigma)
         if (allocated(res%sigma_abs)) deallocate (res%sigma_abs)
         allocate (res%cov(n, n), res%corr(n, n), res%sigma(n), res%sigma_abs(n))
         ! unscaled first: the absolute uncertainties, and the correlations,
         ! which do not depend on the scale (and survive chi2 = 0)
         do i = 1, n
            res%sigma_abs(i) = sqrt(max(cov(i, i), zero))
         end do
         do i = 1, n
            do j = 1, n
               if (res%sigma_abs(i) > zero .and. res%sigma_abs(j) > zero) then
                  res%corr(i, j) = cov(i, j) / (res%sigma_abs(i) * res%sigma_abs(j))
               else
                  res%corr(i, j) = zero
               end if
            end do
         end do
         ! scaled covariance: valid whether or not the residuals were divided
         ! by measurement errors (see the manual, section "error bars")
         cov = cov * res%redchi2
         res%cov = cov
         do i = 1, n
            res%sigma(i) = sqrt(max(cov(i, i), zero))
         end do
         res%has_stats = .true.
      end if
   end subroutine solve_levmar

end module fitpar_lsq
