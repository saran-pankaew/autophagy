!> FitPar -- the evaluation layer.
!>
!> Every solver in this library reaches the user's objective through an
!> evaluator_t.  Centralising that gives us, once and for all:
!>
!>   * exact evaluation counting and hard budget enforcement,
!>   * NaN / Inf quarantine (a bad point is expensive, not fatal),
!>   * automatic finite-difference gradients and Jacobians when the user has
!>     no analytic ones,
!>   * best-point tracking, so an interrupted run still returns its best x,
!>   * a CSV trace of the whole optimisation history.
!>
!> Legacy fitting codes typically scatter these concerns across every routine,
!> or omit them; that is where the "it ran for three days and returned NaN"
!> failure mode comes from.
module fitpar_eval
   use fitpar_kinds
   use fitpar_types
   !$ use omp_lib
   implicit none
   private
   public :: evaluator_t

   type :: evaluator_t
      type(opt_problem), pointer :: p => null()
      type(opt_options), pointer :: o => null()
      integer  :: nfev = 0, ngev = 0
      integer  :: nfail = 0                  !< evaluations that returned junk
      real(wp) :: fbest = opt_huge
      real(wp), allocatable :: xbest(:)
      real(wp), allocatable :: rbest(:)
      logical  :: stop_flag = .false.
      integer  :: stop_code = OPT_SUCCESS
      real(wp) :: t0 = zero
      integer  :: trace_unit = -1
      integer  :: max_conc = 0               !< evaluations allowed in flight at once
   contains
      procedure :: setup      => ev_setup
      procedure :: teardown   => ev_teardown
      procedure :: f          => ev_f
      procedure :: fbatch     => ev_fbatch
      procedure :: grad       => ev_grad
      procedure :: fg         => ev_fg
      procedure :: hessvec    => ev_hessvec
      procedure :: residual   => ev_residual
      procedure :: jacobian   => ev_jacobian
      procedure :: budget_left => ev_budget_left
      procedure :: note       => ev_note
   end type evaluator_t

contains

   subroutine ev_setup(this, p, o)
      class(evaluator_t), intent(inout)     :: this
      type(opt_problem), target, intent(in) :: p
      type(opt_options), target, intent(in) :: o
      integer :: ios
      this%p => p
      this%o => o
      this%nfev = 0; this%ngev = 0; this%nfail = 0
      this%fbest = opt_huge
      this%stop_flag = .false.
      this%stop_code = OPT_SUCCESS
      this%max_conc = o%max_concurrent
      this%t0 = opt_wtime()
      if (allocated(this%xbest)) deallocate (this%xbest)
      if (allocated(this%rbest)) deallocate (this%rbest)
      allocate (this%xbest(p%n)); this%xbest = zero
      if (p%m > 0) allocate (this%rbest(p%m))
      if (len_trim(o%trace_file) > 0) then
         open (newunit=this%trace_unit, file=trim(o%trace_file), status='replace', &
               action='write', iostat=ios)
         if (ios /= 0) then
            this%trace_unit = -1
         else
            write (this%trace_unit, '(a)') '# nfev,f,fbest,time_s'
         end if
      end if
   end subroutine ev_setup

   subroutine ev_teardown(this)
      class(evaluator_t), intent(inout) :: this
      if (this%trace_unit /= -1) then
         close (this%trace_unit)
         this%trace_unit = -1
      end if
   end subroutine ev_teardown

   integer function ev_budget_left(this)
      class(evaluator_t), intent(in) :: this
      ev_budget_left = max(0, this%o%max_feval - this%nfev)
   end function ev_budget_left

   subroutine ev_note(this, text)
      class(evaluator_t), intent(in) :: this
      character(len=*), intent(in)   :: text
      if (this%o%verbose >= 3) write (this%o%unit, '(a,a)') '   [fitpar] ', trim(text)
   end subroutine ev_note

   !> Raw objective evaluation with all the safety netting.
   real(wp) function ev_f(this, x) result(f)
      class(evaluator_t), intent(inout) :: this
      real(wp), intent(in) :: x(:)
      real(wp), allocatable :: xc(:), r(:), g(:)
      integer :: ierr

      allocate (xc(this%p%n))
      xc = x
      call this%p%clip(xc)

      ierr = 0
      if (associated(this%p%fun)) then
         call this%p%fun(xc, f, this%p%ctx, ierr)
      else if (associated(this%p%fungrad)) then
         allocate (g(this%p%n))
         call this%p%fungrad(xc, f, g, this%p%ctx, ierr)
      else if (associated(this%p%res)) then
         allocate (r(this%p%m))
         call this%p%res(xc, r, this%p%ctx, ierr)
         if (ierr == 0) f = half * sum(r**2)
      else
         f = opt_huge; ierr = -1
      end if

      this%nfev = this%nfev + 1

      ! --- quarantine bad values instead of propagating them ----------------
      if (ierr /= 0 .or. .not. is_finite(f)) then
         this%nfail = this%nfail + 1
         f = opt_big
         if (ierr /= 0 .and. ierr /= 1) then
            ! ierr == 1 is the polite "this point is infeasible" code;
            ! anything else is treated as a genuine user abort request.
            this%stop_flag = .true.
            this%stop_code = OPT_USER_STOP
         end if
      else
         if (f < this%fbest) then
            this%fbest = f
            this%xbest = xc
            if (allocated(this%rbest) .and. allocated(r)) this%rbest = r
         end if
      end if

      if (this%trace_unit /= -1) &
         write (this%trace_unit, '(i0,",",es22.14,",",es22.14,",",f12.4)') &
         this%nfev, f, this%fbest, opt_wtime() - this%t0

      ! --- budgets ----------------------------------------------------------
      if (this%nfev >= this%o%max_feval) then
         this%stop_flag = .true.
         if (this%stop_code == OPT_SUCCESS) this%stop_code = OPT_MAX_FEVAL
      end if
      if (this%o%max_time > zero) then
         if (opt_wtime() - this%t0 > this%o%max_time) then
            this%stop_flag = .true.
            if (this%stop_code == OPT_SUCCESS) this%stop_code = OPT_MAX_TIME
         end if
      end if
      if (this%fbest <= this%o%target_f) then
         this%stop_flag = .true.
         this%stop_code = OPT_CONV_TARGET
      end if
   end function ev_f

   !> Evaluate a whole population.  With options%parallel this is the OpenMP
   !> hot spot; the user's objective must then be thread-safe (no saved state,
   !> no shared scratch arrays, no unit-number collisions).
   subroutine ev_fbatch(this, xs, fs)
      class(evaluator_t), intent(inout) :: this
      real(wp), intent(in)  :: xs(:, :)     !< (n, npop)
      real(wp), intent(out) :: fs(:)
      real(wp), allocatable :: xc(:), r(:), g(:)
      integer :: k, npop, ierr, nfail_local, nthr, nrun
      real(wp) :: fk
      logical :: ustop

      npop = size(xs, 2)
      nfail_local = 0
      ustop = .false.

      if (this%o%parallel) then
         ! no more than the budget allows, as the serial loop below: the members
         ! past it are not evaluated (2.8.0; a batch used to overrun max_feval,
         ! and its last generation then differed from a serial run)
         nrun = min(npop, max(0, this%o%max_feval - this%nfev))
         fs = opt_big
         nthr = this%max_conc
         !$ if (nthr <= 0) nthr = omp_get_max_threads()
         if (nthr <= 0) nthr = 1
         nthr = max(1, min(nthr, max(1, nrun)))
         !$omp parallel do default(shared) private(k, xc, r, g, ierr, fk) &
         !$omp num_threads(nthr) &
         !$omp    reduction(+:nfail_local) reduction(.or.:ustop) schedule(dynamic)
         do k = 1, nrun
            allocate (xc(this%p%n))
            xc = xs(:, k)
            call this%p%clip(xc)
            ierr = 0
            if (associated(this%p%fun)) then
               call this%p%fun(xc, fk, this%p%ctx, ierr)
            else if (associated(this%p%fungrad)) then
               allocate (g(this%p%n))
               call this%p%fungrad(xc, fk, g, this%p%ctx, ierr)
               deallocate (g)
            else
               allocate (r(this%p%m))
               call this%p%res(xc, r, this%p%ctx, ierr)
               if (ierr == 0) fk = half * sum(r**2)
               deallocate (r)
            end if
            if (ierr /= 0 .or. .not. is_finite(fk)) then
               fk = opt_big
               nfail_local = nfail_local + 1
               if (ierr /= 0 .and. ierr /= 1) ustop = .true.   ! as in ev_f: a request to stop
            end if
            fs(k) = fk
            deallocate (xc)
         end do
         !$omp end parallel do

         ! bookkeeping is done serially so the counters stay exact
         this%nfev = this%nfev + nrun
         this%nfail = this%nfail + nfail_local
         if (ustop) then
            this%stop_flag = .true.
            this%stop_code = OPT_USER_STOP
         end if
         do k = 1, nrun
            if (fs(k) < this%fbest .and. fs(k) < opt_big) then
               this%fbest = fs(k)
               this%xbest = xs(:, k)
               call this%p%clip(this%xbest)
            end if
            if (this%trace_unit /= -1) &
               write (this%trace_unit, '(i0,",",es22.14,",",es22.14,",",f12.4)') &
               this%nfev - nrun + k, fs(k), this%fbest, opt_wtime() - this%t0
         end do
         if (this%nfev >= this%o%max_feval) then
            this%stop_flag = .true.
            if (this%stop_code == OPT_SUCCESS) this%stop_code = OPT_MAX_FEVAL
         end if
         if (this%o%max_time > zero) then
            if (opt_wtime() - this%t0 > this%o%max_time) then
               this%stop_flag = .true.
               if (this%stop_code == OPT_SUCCESS) this%stop_code = OPT_MAX_TIME
            end if
         end if
         if (this%fbest <= this%o%target_f) then
            this%stop_flag = .true.
            this%stop_code = OPT_CONV_TARGET
         end if
      else
         do k = 1, npop
            fs(k) = this%f(xs(:, k))
            if (this%stop_flag) then
               if (k < npop) fs(k + 1:npop) = opt_big
               exit
            end if
         end do
      end if
   end subroutine ev_fbatch

   !> Automatic finite-difference step: balances truncation against round-off.
   pure real(wp) function fd_h(this, xi, i)
      class(evaluator_t), intent(in) :: this
      real(wp), intent(in) :: xi
      integer, intent(in)  :: i
      real(wp) :: base, typ
      typ = one
      if (allocated(this%p%xscale)) typ = max(abs(this%p%xscale(i)), opt_tiny)
      select case (this%o%fd_order)
      case (1); base = sqrt(opt_eps)
      case (4); base = opt_eps**0.2_wp
      case default; base = opt_eps**(one / three)
      end select
      if (this%o%fd_step > zero) base = this%o%fd_step
      fd_h = base * max(abs(xi), typ)
   end function fd_h

   !> Gradient: analytic if available, otherwise finite differences of the
   !> requested order (1 = forward, 2 = central, 4 = Richardson-extrapolated).
   subroutine ev_grad(this, x, g)
      class(evaluator_t), intent(inout) :: this
      real(wp), intent(in)  :: x(:)
      real(wp), intent(out) :: g(:)
      real(wp), allocatable :: xp(:)
      real(wp) :: h, f0, fp, fm, fp2, fm2
      integer  :: i, ierr, n

      n = this%p%n
      if (associated(this%p%grad)) then
         call this%p%grad(x, g, this%p%ctx, ierr)
         this%ngev = this%ngev + 1
         if (ierr /= 0) then
            this%stop_flag = .true.; this%stop_code = OPT_USER_STOP
         end if
         where (.not. is_finite(g)) g = zero
         return
      end if
      if (associated(this%p%fungrad)) then
         call this%p%fungrad(x, f0, g, this%p%ctx, ierr)
         this%nfev = this%nfev + 1
         this%ngev = this%ngev + 1
         if (ierr /= 0) then
            this%stop_flag = .true.; this%stop_code = OPT_USER_STOP
         end if
         where (.not. is_finite(g)) g = zero
         return
      end if

      allocate (xp(n))
      xp = x
      if (this%o%fd_order == 1) f0 = this%f(x)
      do i = 1, n
         h = fd_h(this, x(i), i)
         select case (this%o%fd_order)
         case (1)
            xp(i) = x(i) + h; fp = this%f(xp); xp(i) = x(i)
            g(i) = (fp - f0) / h
         case (4)
            xp(i) = x(i) + h;       fp = this%f(xp)
            xp(i) = x(i) - h;       fm = this%f(xp)
            xp(i) = x(i) + two * h; fp2 = this%f(xp)
            xp(i) = x(i) - two * h; fm2 = this%f(xp)
            xp(i) = x(i)
            g(i) = (fm2 - 8.0_wp * fm + 8.0_wp * fp - fp2) / (12.0_wp * h)
         case default
            xp(i) = x(i) + h; fp = this%f(xp)
            xp(i) = x(i) - h; fm = this%f(xp)
            xp(i) = x(i)
            g(i) = (fp - fm) / (two * h)
         end select
         if (this%stop_flag) exit
      end do
      this%ngev = this%ngev + 1
      where (.not. is_finite(g)) g = zero
   end subroutine ev_grad

   subroutine ev_fg(this, x, f, g)
      class(evaluator_t), intent(inout) :: this
      real(wp), intent(in)  :: x(:)
      real(wp), intent(out) :: f, g(:)
      integer :: ierr
      if (associated(this%p%fungrad)) then
         call this%p%fungrad(x, f, g, this%p%ctx, ierr)
         this%nfev = this%nfev + 1
         this%ngev = this%ngev + 1
         if (ierr /= 0 .or. .not. is_finite(f)) then
            f = opt_big
            if (ierr /= 0 .and. ierr /= 1) then
               this%stop_flag = .true.; this%stop_code = OPT_USER_STOP
            end if
         else if (f < this%fbest) then
            this%fbest = f; this%xbest = x
         end if
         if (this%nfev >= this%o%max_feval) then
            this%stop_flag = .true.
            if (this%stop_code == OPT_SUCCESS) this%stop_code = OPT_MAX_FEVAL
         end if
         where (.not. is_finite(g)) g = zero
      else
         f = this%f(x)
         call this%grad(x, g)
      end if
   end subroutine ev_fg

   !> Hessian-vector product by central differences of the gradient.
   !> This is what makes truncated-Newton practical without ever forming H.
   subroutine ev_hessvec(this, x, v, hv)
      class(evaluator_t), intent(inout) :: this
      real(wp), intent(in)  :: x(:), v(:)
      real(wp), intent(out) :: hv(:)
      real(wp), allocatable :: gp(:), gm(:), xt(:)
      real(wp) :: h, nv
      integer :: n
      n = this%p%n
      allocate (gp(n), gm(n), xt(n))
      nv = sqrt(sum(v**2))
      if (nv <= opt_tiny) then
         hv = zero; return
      end if
      h = sqrt(opt_eps) * max(one, sqrt(sum(x**2))) / nv
      xt = x + h * v; call this%grad(xt, gp)
      xt = x - h * v; call this%grad(xt, gm)
      hv = (gp - gm) / (two * h)
   end subroutine ev_hessvec

   !> Residual vector (least-squares problems).
   subroutine ev_residual(this, x, r, ok)
      class(evaluator_t), intent(inout) :: this
      real(wp), intent(in)  :: x(:)
      real(wp), intent(out) :: r(:)
      logical, intent(out)  :: ok
      real(wp), allocatable :: xc(:)
      integer :: ierr
      allocate (xc(this%p%n)); xc = x
      call this%p%clip(xc)
      call this%p%res(xc, r, this%p%ctx, ierr)
      this%nfev = this%nfev + 1
      ok = (ierr == 0) .and. all(is_finite(r))
      if (.not. ok) then
         this%nfail = this%nfail + 1
         r = sqrt(opt_big / max(one, real(this%p%m, wp)))
         if (ierr /= 0 .and. ierr /= 1) then
            this%stop_flag = .true.; this%stop_code = OPT_USER_STOP
         end if
      else if (half * sum(r**2) < this%fbest) then
         this%fbest = half * sum(r**2)
         this%xbest = xc
         if (allocated(this%rbest)) this%rbest = r
      end if
      if (this%trace_unit /= -1) &
         write (this%trace_unit, '(i0,",",es22.14,",",es22.14,",",f12.4)') &
         this%nfev, half * sum(r**2), this%fbest, opt_wtime() - this%t0
      if (this%nfev >= this%o%max_feval) then
         this%stop_flag = .true.
         if (this%stop_code == OPT_SUCCESS) this%stop_code = OPT_MAX_FEVAL
      end if
      if (this%o%max_time > zero) then
         if (opt_wtime() - this%t0 > this%o%max_time) then
            this%stop_flag = .true.
            if (this%stop_code == OPT_SUCCESS) this%stop_code = OPT_MAX_TIME
         end if
      end if
   end subroutine ev_residual

   !> Jacobian: analytic if supplied, else forward/central differences of the
   !> residuals (m x n).
   subroutine ev_jacobian(this, x, r0, jm)
      class(evaluator_t), intent(inout) :: this
      real(wp), intent(in)  :: x(:), r0(:)
      real(wp), intent(out) :: jm(:, :)
      real(wp), allocatable :: xp(:), rp(:), rm(:)
      real(wp) :: h
      integer  :: i, n, m, ierr
      logical  :: ok

      n = this%p%n; m = this%p%m
      if (associated(this%p%jac)) then
         call this%p%jac(x, jm, this%p%ctx, ierr)
         this%ngev = this%ngev + 1
         if (ierr /= 0) then
            this%stop_flag = .true.; this%stop_code = OPT_USER_STOP
         end if
         return
      end if

      allocate (xp(n), rp(m), rm(m))
      xp = x
      do i = 1, n
         h = fd_h(this, x(i), i)
         if (this%o%fd_order >= 2) then
            xp(i) = x(i) + h; call this%residual(xp, rp, ok)
            xp(i) = x(i) - h; call this%residual(xp, rm, ok)
            xp(i) = x(i)
            jm(:, i) = (rp - rm) / (two * h)
         else
            xp(i) = x(i) + h; call this%residual(xp, rp, ok)
            xp(i) = x(i)
            jm(:, i) = (rp - r0) / h
         end if
         if (this%stop_flag) then
            if (i < n) jm(:, i + 1:n) = zero
            exit
         end if
      end do
      this%ngev = this%ngev + 1
      where (.not. is_finite(jm)) jm = zero
   end subroutine ev_jacobian

end module fitpar_eval
