!> FitPar -- reproducible pseudo-random numbers and space-filling samplers.
!>
!> Uses xoshiro256** seeded through splitmix64 rather than the intrinsic
!> RANDOM_NUMBER, so that a given seed reproduces bit-for-bit identical runs on
!> every compiler and platform.  That matters: a stochastic optimiser you cannot
!> replay is a stochastic optimiser you cannot debug or publish.
module fitpar_rng
   use fitpar_kinds
   use, intrinsic :: iso_fortran_env, only: error_unit
   implicit none
   private

   public :: rng_t, sample_lhs, sample_halton, sample_uniform_box

   ! splitmix64 constants, written as signed decimals because the hexadecimal
   ! forms overflow a signed 64-bit integer literal.
   integer(int64), parameter :: golden_gamma = -7046029254386353131_int64
   integer(int64), parameter :: smix_c1      = -4658895280553007687_int64
   integer(int64), parameter :: smix_c2      = -7723592293110705685_int64
   ! splitmix64 and xoshiro256** wrap on 64-bit overflow, which standard Fortran
   ! leaves undefined: build with -fwrapv (gfortran).  The first seeding checks
   ! the stream for a fixed seed against its reference and warns once.
   logical, save :: rng_checked = .false.
   integer(int64), parameter :: clock_mix    =  2685821657736338717_int64

   type :: rng_t
      private
      integer(int64) :: s(4) = [1_int64, 2_int64, 3_int64, 4_int64]
      logical        :: has_spare = .false.
      real(wp)       :: spare = zero
   contains
      procedure :: seed     => rng_seed
      procedure :: uniform  => rng_uniform          !< U(0,1)
      procedure :: uniform_v => rng_uniform_v
      procedure :: normal   => rng_normal           !< N(0,1)
      procedure :: normal_v => rng_normal_v
      procedure :: cauchy   => rng_cauchy           !< standard Cauchy (JADE)
      procedure :: randint  => rng_randint          !< uniform integer in [lo,hi]
      procedure :: permute  => rng_permute          !< Fisher-Yates
   end type rng_t

contains

   pure integer(int64) function rotl(x, k)
      integer(int64), intent(in) :: x
      integer, intent(in)        :: k
      rotl = ior(ishft(x, k), ishft(x, k - 64))
   end function rotl

   !> splitmix64 -- used only to expand a single user seed into 256 bits.
   pure subroutine splitmix64(state, out)
      integer(int64), intent(inout) :: state
      integer(int64), intent(out)   :: out
      integer(int64) :: z
      state = state + golden_gamma
      z = state
      z = ieor(z, ishft(z, -30)) * smix_c1
      z = ieor(z, ishft(z, -27)) * smix_c2
      out = ieor(z, ishft(z, -31))
   end subroutine splitmix64

   subroutine rng_seed(this, s)
      class(rng_t), intent(inout) :: this
      integer(int64), intent(in)  :: s
      integer(int64) :: st
      integer :: i
      integer(int64) :: c
      if (.not. rng_checked) call rng_selfcheck()
      st = s
      if (st == 0_int64) then                  ! 0 means "seed from the clock"
         call system_clock(count=c)
         st = ieor(c, clock_mix)
      end if
      do i = 1, 4
         call splitmix64(st, this%s(i))
      end do
      this%has_spare = .false.
   end subroutine rng_seed

   subroutine rng_selfcheck()
      type(rng_t) :: t
      integer(int64), parameter :: ref(3) = [-4725905248023948133_int64, 2398916695208396998_int64, -676359223724682360_int64]
      integer :: i
      rng_checked = .true.
      call t%seed(12345_int64)
      do i = 1, 3
         if (next_u64(t) /= ref(i)) then
            write (error_unit, '(a)') 'FitPar: the random-number generator does not reproduce its reference ' // &
               'stream; build with wrapping integer arithmetic (gfortran -fwrapv). Results will not be ' // &
               'reproducible across builds.'
            return
         end if
      end do
   end subroutine rng_selfcheck

   integer(int64) function next_u64(this)
      class(rng_t), intent(inout) :: this
      integer(int64) :: r, t
      r = rotl(this%s(2) * 5_int64, 7) * 9_int64
      t = ishft(this%s(2), 17)
      this%s(3) = ieor(this%s(3), this%s(1))
      this%s(4) = ieor(this%s(4), this%s(2))
      this%s(2) = ieor(this%s(2), this%s(3))
      this%s(1) = ieor(this%s(1), this%s(4))
      this%s(3) = ieor(this%s(3), t)
      this%s(4) = rotl(this%s(4), 45)
      next_u64 = r
   end function next_u64

   real(wp) function rng_uniform(this)
      class(rng_t), intent(inout) :: this
      integer(int64) :: r
      r = next_u64(this)
      ! top 53 bits -> [0,1)
      rng_uniform = real(ishft(r, -11), wp) * (one / 9007199254740992.0_wp)
   end function rng_uniform

   subroutine rng_uniform_v(this, v)
      class(rng_t), intent(inout) :: this
      real(wp), intent(out)       :: v(:)
      integer :: i
      do i = 1, size(v)
         v(i) = this%uniform()
      end do
   end subroutine rng_uniform_v

   !> Marsaglia polar method with a cached spare deviate.
   real(wp) function rng_normal(this)
      class(rng_t), intent(inout) :: this
      real(wp) :: u, v, s, f
      if (this%has_spare) then
         this%has_spare = .false.
         rng_normal = this%spare
         return
      end if
      do
         u = two * this%uniform() - one
         v = two * this%uniform() - one
         s = u * u + v * v
         if (s > zero .and. s < one) exit
      end do
      f = sqrt(-two * log(s) / s)
      this%spare = v * f
      this%has_spare = .true.
      rng_normal = u * f
   end function rng_normal

   subroutine rng_normal_v(this, v)
      class(rng_t), intent(inout) :: this
      real(wp), intent(out)       :: v(:)
      integer :: i
      do i = 1, size(v)
         v(i) = this%normal()
      end do
   end subroutine rng_normal_v

   real(wp) function rng_cauchy(this)
      class(rng_t), intent(inout) :: this
      rng_cauchy = tan(pi * (this%uniform() - half))
   end function rng_cauchy

   integer function rng_randint(this, lo, hi)
      class(rng_t), intent(inout) :: this
      integer, intent(in)         :: lo, hi
      if (hi <= lo) then
         rng_randint = lo
      else
         rng_randint = lo + int(this%uniform() * real(hi - lo + 1, wp))
         rng_randint = min(hi, max(lo, rng_randint))
      end if
   end function rng_randint

   subroutine rng_permute(this, idx)
      class(rng_t), intent(inout) :: this
      integer, intent(inout)      :: idx(:)
      integer :: i, j, t
      do i = size(idx), 2, -1
         j = this%randint(1, i)
         t = idx(i); idx(i) = idx(j); idx(j) = t
      end do
   end subroutine rng_permute

   !--------------------------------------------------------------------------
   ! Space-filling designs for multistart / MLSL / population initialisation
   !--------------------------------------------------------------------------

   !> Latin hypercube sample: npts points in the box [lb,ub], one per stratum
   !> in every coordinate.  x(n, npts).
   subroutine sample_lhs(rng, lb, ub, x)
      type(rng_t), intent(inout) :: rng
      real(wp), intent(in)       :: lb(:), ub(:)
      real(wp), intent(out)      :: x(:, :)
      integer, allocatable :: perm(:)
      integer  :: n, npts, i, k
      real(wp) :: u
      n = size(lb); npts = size(x, 2)
      allocate (perm(npts))
      do i = 1, n
         perm = [(k, k=1, npts)]
         call rng%permute(perm)
         do k = 1, npts
            u = (real(perm(k) - 1, wp) + rng%uniform()) / real(npts, wp)
            x(i, k) = lb(i) + u * (ub(i) - lb(i))
         end do
      end do
   end subroutine sample_lhs

   !> Halton point (deterministic low-discrepancy).  Good for reproducible
   !> multistart grids up to moderate dimension.
   subroutine sample_halton(idx, lb, ub, x)
      integer, intent(in)   :: idx
      real(wp), intent(in)  :: lb(:), ub(:)
      real(wp), intent(out) :: x(:)
      integer, parameter :: primes(*) = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, &
                                         41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, &
                                         89, 97, 101, 103, 107, 109, 113, 127, 131]
      integer  :: i, n, b, k
      real(wp) :: f, r
      n = size(lb)
      do i = 1, n
         if (i <= size(primes)) then
            b = primes(i)
         else
            b = primes(mod(i - 1, size(primes)) + 1) + 2 * (i / size(primes))
         end if
         f = one; r = zero; k = idx
         do while (k > 0)
            f = f / real(b, wp)
            r = r + f * real(mod(k, b), wp)
            k = k / b
         end do
         x(i) = lb(i) + r * (ub(i) - lb(i))
      end do
   end subroutine sample_halton

   subroutine sample_uniform_box(rng, lb, ub, x)
      type(rng_t), intent(inout) :: rng
      real(wp), intent(in)       :: lb(:), ub(:)
      real(wp), intent(out)      :: x(:)
      integer :: i
      do i = 1, size(lb)
         x(i) = lb(i) + rng%uniform() * (ub(i) - lb(i))
      end do
   end subroutine sample_uniform_box

end module fitpar_rng
