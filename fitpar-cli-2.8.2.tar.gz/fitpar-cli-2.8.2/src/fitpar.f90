!> FitPar -- public interface.
!>
!>     use fitpar
!>     type(opt_problem) :: prob
!>     type(opt_options) :: opts
!>     type(opt_result)  :: res
!>     call prob%init(n, fun=myfun, lb=lo, ub=hi)
!>     opts%method = 'de'
!>     call optimize(prob, x, opts, res)
!>
!> Everything else in the library is reachable through this module.
module fitpar
   use fitpar_kinds
   use fitpar_types
   use fitpar_eval
   use fitpar_linalg
   use fitpar_rng
   use fitpar_localdisp
   use fitpar_local_quasi
   use fitpar_local_dfo
   use fitpar_local_newton
   use fitpar_lsq
   use fitpar_lsq_dfogn
   use fitpar_global_de
   use fitpar_global_cmaes
   use fitpar_global_swarm
   use fitpar_global_direct
   use fitpar_global_multi
   use fitpar_global_foctopus
   use fitpar_global_ga
   use fitpar_global_mac
   use fitpar_local_dfotr
   use fitpar_local_direct_search
   implicit none
   public

   character(len=*), parameter :: fitpar_version = '2.8.2'

contains

   !> Minimise prob starting from x.  On return x holds the best point found
   !> and res carries the full diagnosis.
   subroutine optimize(prob, x, opts, res)
      type(opt_problem), intent(inout)        :: prob
      real(wp), intent(inout)                 :: x(:)
      type(opt_options), intent(in), optional :: opts
      type(opt_result), intent(out)           :: res

      type(opt_options)  :: o
      type(evaluator_t)  :: ev
      type(opt_result)   :: polish_res
      real(wp), allocatable :: xw(:)
      character(len=96)  :: msg
      integer :: id, local_id, npolish
      logical :: ok
      real(wp) :: t0

      if (present(opts)) o = opts
      t0 = opt_wtime()

      ! ---- validate ------------------------------------------------------
      call prob%check(ok, msg)
      if (.not. ok) then
         res%status = OPT_BAD_INPUT
         res%message = msg
         res%x = x
         if (o%verbose >= 1) write (o%unit, '(a,a)') ' fitpar error: ', trim(msg)
         return
      end if
      if (size(x) /= prob%n) then
         res%status = OPT_BAD_INPUT
         res%message = 'x has the wrong length for this problem'
         if (o%verbose >= 1) write (o%unit, '(a)') ' fitpar error: '//trim(res%message)
         return
      end if

      id = method_id(o%method)
      if (id < 0) then
         res%status = OPT_BAD_INPUT
         res%message = 'unknown method "'//trim(o%method)//'"'
         if (o%verbose >= 1) then
            write (o%unit, '(a)') ' fitpar error: '//trim(res%message)
            call list_methods(o%unit)
         end if
         return
      end if
      if (id == M_AUTO) id = default_local_for(prob)
      if ((id == M_LEVMAR .or. id == M_DFOGN) .and. .not. prob%is_lsq()) then
         id = M_LBFGSB
         if (o%verbose >= 1) write (o%unit, '(a)') &
            ' fitpar: Levenberg-Marquardt needs a residual objective; using L-BFGS-B'
      end if

      allocate (xw(prob%n))
      xw = x
      call prob%clip(xw)

      ! The names 'mads' and 'nomad' are the pattern search with a randomly
      ! rotated poll; normalise the alias into the option the solver reads.
      if (id == M_PATTERN) then
         if (index(o%method, 'mad') > 0 .or. index(o%method, 'MAD') > 0 .or. &
             index(o%method, 'Mad') > 0) o%ps_mads = .true.
      end if

      if (o%verbose >= 1) call print_header(prob, o, id)

      ! ---- solve -----------------------------------------------------------
      call ev%setup(prob, o)
      select case (id)
      case (M_NELDER_MEAD); call solve_nelder_mead(ev, prob, o, xw, res)
      case (M_POWELL);      call solve_powell(ev, prob, o, xw, res)
      case (M_LBFGSB);      call solve_lbfgsb(ev, prob, o, xw, res)
      case (M_TRUST_NCG);   call solve_trust_ncg(ev, prob, o, xw, res)
      case (M_CG);          call solve_cg(ev, prob, o, xw, res)
      case (M_LEVMAR);      call solve_levmar(ev, prob, o, xw, res)
      case (M_DFOGN);       call solve_dfogn(ev, prob, o, xw, res)
      case (M_DE);          call solve_de(ev, prob, o, xw, res)
      case (M_PSO);         call solve_pso(ev, prob, o, xw, res)
      case (M_CMAES);       call solve_cmaes(ev, prob, o, xw, res)
      case (M_SA);          call solve_sa(ev, prob, o, xw, res)
      case (M_DIRECT);      call solve_direct(ev, prob, o, xw, res)
      case (M_MLSL);        call solve_mlsl(ev, prob, o, xw, res)
      case (M_MULTISTART);  call solve_multistart(ev, prob, o, xw, res)
      case (M_BASINHOP);    call solve_basinhop(ev, prob, o, xw, res)
      case (M_FOCTOPUS);    call solve_foctopus(ev, prob, o, xw, res)
      case (M_GA);          call solve_ga(ev, prob, o, xw, res)
      case (M_MAC);         call solve_mac(ev, prob, o, xw, res)
      case (M_NEWUOA);      call solve_dfo_tr(ev, prob, o, xw, res, .false.)
      case (M_BOBYQA);      call solve_dfo_tr(ev, prob, o, xw, res, .true.)
      case (M_PATTERN);     call solve_pattern(ev, prob, o, xw, res)
      case (M_BFGS);        call solve_bfgs(ev, prob, o, xw, res)
      case (M_SQP);         call solve_sqp(ev, prob, o, xw, res)
      end select
      res%method = method_name(id)

      ! ---- local polish after a global search --------------------------------
      if (is_global_method(id) .and. o%polish .and. .not. ev%stop_flag) then
         local_id = method_id(o%local_method)
         if (local_id < 0 .or. local_id == M_AUTO) local_id = default_local_for(prob)
         npolish = o%polish_feval
         if (npolish <= 0) npolish = max(500, o%max_feval / 5)
         block
            type(opt_options) :: po
            po = o
            po%max_feval = ev%nfev + npolish
            po%verbose = max(0, o%verbose - 1)
            xw = res%x
            if (o%verbose >= 1) write (o%unit, '(a,a)') ' polishing with ', &
               trim(method_name(local_id))
            call run_local(local_id, ev, prob, po, xw, polish_res)
            if (polish_res%f <= res%f) then
               polish_res%method = trim(method_name(id))//' + '//trim(method_name(local_id))
               polish_res%status = res%status
               res = polish_res
            end if
         end block
      end if

      ! ---- finalise ------------------------------------------------------------
      if (ev%fbest < res%f) then          ! never return worse than what we saw
         res%x = ev%xbest
         res%f = ev%fbest
      end if
      res%nfev = ev%nfev
      res%ngev = ev%ngev
      res%time = opt_wtime() - t0
      res%message = status_message(res%status)
      if (ev%nfail > 0 .and. o%verbose >= 1) &
         write (o%unit, '(a,i0,a)') ' warning: ', ev%nfail, &
         ' evaluations returned NaN/Inf or an error flag and were penalised'
      call ev%teardown()

      x = res%x
      if (o%verbose >= 1) call res%summary(o%unit)
   end subroutine optimize

   !> Convenience wrapper for the common "fit a model to data" case.
   subroutine optimize_lsq(prob, x, opts, res)
      type(opt_problem), intent(inout)        :: prob
      real(wp), intent(inout)                 :: x(:)
      type(opt_options), intent(in), optional :: opts
      type(opt_result), intent(out)           :: res
      type(opt_options) :: o
      if (present(opts)) o = opts
      o%method = 'lm'
      call optimize(prob, x, o, res)
   end subroutine optimize_lsq

   subroutine print_header(prob, o, id)
      type(opt_problem), intent(in) :: prob
      type(opt_options), intent(in) :: o
      integer, intent(in) :: id
      integer :: u
      u = o%unit
      write (u, '(a)') repeat('=', 68)
      write (u, '(a,a,a,a)') ' FitPar ', fitpar_version, '   problem: ', trim(prob%name)
      write (u, '(a,i0,a,i0,a,a)') ' n = ', prob%n, '   residuals = ', prob%m, &
         '   method = ', trim(method_name(id))
      if (prob%bounded()) then
         write (u, '(a)') ' bounds     : yes'
      else
         write (u, '(a)') ' bounds     : none'
      end if
      if (associated(prob%grad) .or. associated(prob%fungrad)) then
         write (u, '(a)') ' gradient   : analytic'
      else if (associated(prob%jac)) then
         write (u, '(a)') ' Jacobian   : analytic'
      else
         write (u, '(a,i0)') ' derivatives: finite difference, order ', o%fd_order
      end if
      write (u, '(a,es9.2,a,es9.2,a,es9.2)') ' tol_f = ', o%tol_f, '  tol_x = ', &
         o%tol_x, '  tol_g = ', o%tol_g
      write (u, '(a,i0,a,i0)') ' max_feval = ', o%max_feval, '   max_iter = ', o%max_iter
      write (u, '(a)') repeat('=', 68)
   end subroutine print_header

   subroutine list_methods(u)
      integer, intent(in) :: u
      write (u, '(a)') ' available methods:'
      write (u, '(a)') '   local : nelder-mead  powell  lbfgsb  trust-ncg  cg  lm'
      write (u, '(a)') '   global: de  pso  cmaes  sa  direct  mlsl  multistart  basinhopping  foctopus  ga  mac'
      write (u, '(a)') '   also:   newuoa  bobyqa  pattern  mads  bfgs  sqp'
      write (u, '(a)') '   auto  : pick automatically from the problem definition'
   end subroutine list_methods

   !> Read options from a namelist file:
   !>
   !>   &fitpar
   !>     method = 'de', max_feval = 50000, tol_f = 1d-12, seed = 42
   !>   /
   !>
   !> Any field left out keeps its default.  Handy for production runs where
   !> the settings should live in the input deck, not in recompiled source.
   subroutine read_options(filename, o, ok)
      character(len=*), intent(in)     :: filename
      type(opt_options), intent(inout) :: o
      logical, intent(out)             :: ok

      character(len=24)  :: method, local_method
      character(len=256) :: trace_file
      real(wp) :: tol_f, tol_x, tol_g, max_time, target_f, fd_step
      real(wp) :: nm_step, lm_lambda0, de_f, de_cr, de_pbest, cma_sigma0
      real(wp) :: sa_t0, sa_rt, direct_eps, bh_step, bh_temp
      real(wp) :: pso_w, pso_c1, pso_c2
      integer  :: max_feval, max_iter, verbose, print_every, popsize, restarts
      integer  :: fd_order, lbfgs_memory, sa_ns, sa_nt, ms_points, polish_feval
      integer  :: foc_nsamp, foc_zoom, foc_zmin, foc_zmax
      real(wp) :: foc_zin, foc_zout
      integer  :: ga_tournament
      real(wp) :: dfo_rhobeg, dfo_rhoend, ps_mesh, ga_pcross, ga_pmut, ga_elite
      logical  :: ps_mads
      integer  :: foc_adaptive
      integer  :: stall_iter, pso_neighbours
      integer(int64) :: seed
      logical  :: parallel, polish, nm_adaptive, lm_scaled, lm_covar
      logical  :: de_adaptive, de_lpsr, cma_ipop, direct_local, foc_classic
      real(wp) :: foc_msigma
      integer  :: u, ios

      namelist /fitpar_nml/ method, local_method, trace_file, tol_f, tol_x, tol_g, &
         max_time, target_f, fd_step, nm_step, lm_lambda0, de_f, de_cr, de_pbest, &
         cma_sigma0, sa_t0, sa_rt, direct_eps, bh_step, bh_temp, pso_w, pso_c1, &
         pso_c2, max_feval, max_iter, verbose, print_every, popsize, restarts, &
         fd_order, lbfgs_memory, sa_ns, sa_nt, ms_points, polish_feval, stall_iter, &
         pso_neighbours, seed, parallel, polish, nm_adaptive, lm_scaled, lm_covar, &
         de_adaptive, de_lpsr, cma_ipop, direct_local, foc_classic, foc_nsamp, &
         foc_zoom, foc_zin, foc_zout, foc_zmin, foc_zmax, foc_msigma, &
         dfo_rhobeg, dfo_rhoend, ps_mesh, ps_mads, ga_pcross, ga_pmut, &
         ga_elite, ga_tournament

      ! start from the current values so that a partial namelist is a patch
      method = o%method; local_method = o%local_method; trace_file = o%trace_file
      tol_f = o%tol_f; tol_x = o%tol_x; tol_g = o%tol_g
      max_time = o%max_time; target_f = o%target_f; fd_step = o%fd_step
      nm_step = o%nm_step; lm_lambda0 = o%lm_lambda0
      de_f = o%de_f; de_cr = o%de_cr; de_pbest = o%de_pbest
      cma_sigma0 = o%cma_sigma0; sa_t0 = o%sa_t0; sa_rt = o%sa_rt
      direct_eps = o%direct_eps; bh_step = o%bh_step; bh_temp = o%bh_temp
      pso_w = o%pso_w; pso_c1 = o%pso_c1; pso_c2 = o%pso_c2
      max_feval = o%max_feval; max_iter = o%max_iter; verbose = o%verbose
      print_every = o%print_every; popsize = o%popsize; restarts = o%restarts
      fd_order = o%fd_order; lbfgs_memory = o%lbfgs_memory
      sa_ns = o%sa_ns; sa_nt = o%sa_nt; ms_points = o%ms_points
      polish_feval = o%polish_feval; stall_iter = o%stall_iter
      pso_neighbours = o%pso_neighbours; seed = o%seed
      parallel = o%parallel; polish = o%polish; nm_adaptive = o%nm_adaptive
      lm_scaled = o%lm_scaled; lm_covar = o%lm_covar
      de_adaptive = o%de_adaptive; de_lpsr = o%de_lpsr
      cma_ipop = o%cma_ipop; direct_local = o%direct_local
      foc_classic = o%foc_classic; foc_nsamp = o%foc_nsamp
      foc_zoom = o%foc_zoom; foc_zin = o%foc_zin; foc_zout = o%foc_zout
      foc_zmin = o%foc_zmin; foc_zmax = o%foc_zmax; foc_msigma = o%foc_msigma
      dfo_rhobeg = o%dfo_rhobeg; dfo_rhoend = o%dfo_rhoend
      ps_mesh = o%ps_mesh; ps_mads = o%ps_mads
      ga_pcross = o%ga_pcross; ga_pmut = o%ga_pmut; ga_elite = o%ga_elite
      ga_tournament = o%ga_tournament

      ok = .false.
      open (newunit=u, file=filename, status='old', action='read', iostat=ios)
      if (ios /= 0) return
      read (u, nml=fitpar_nml, iostat=ios)
      close (u)
      if (ios /= 0) return

      o%method = method; o%local_method = local_method; o%trace_file = trace_file
      o%tol_f = tol_f; o%tol_x = tol_x; o%tol_g = tol_g
      o%max_time = max_time; o%target_f = target_f; o%fd_step = fd_step
      o%nm_step = nm_step; o%lm_lambda0 = lm_lambda0
      o%de_f = de_f; o%de_cr = de_cr; o%de_pbest = de_pbest
      o%cma_sigma0 = cma_sigma0; o%sa_t0 = sa_t0; o%sa_rt = sa_rt
      o%direct_eps = direct_eps; o%bh_step = bh_step; o%bh_temp = bh_temp
      o%pso_w = pso_w; o%pso_c1 = pso_c1; o%pso_c2 = pso_c2
      o%max_feval = max_feval; o%max_iter = max_iter; o%verbose = verbose
      o%print_every = print_every; o%popsize = popsize; o%restarts = restarts
      o%fd_order = fd_order; o%lbfgs_memory = lbfgs_memory
      o%sa_ns = sa_ns; o%sa_nt = sa_nt; o%ms_points = ms_points
      o%polish_feval = polish_feval; o%stall_iter = stall_iter
      o%pso_neighbours = pso_neighbours; o%seed = seed
      o%parallel = parallel; o%polish = polish; o%nm_adaptive = nm_adaptive
      o%lm_scaled = lm_scaled; o%lm_covar = lm_covar
      o%de_adaptive = de_adaptive; o%de_lpsr = de_lpsr
      o%cma_ipop = cma_ipop; o%direct_local = direct_local
      o%foc_classic = foc_classic; o%foc_nsamp = foc_nsamp
      o%foc_zoom = foc_zoom; o%foc_zin = foc_zin; o%foc_zout = foc_zout
      o%foc_zmin = foc_zmin; o%foc_zmax = foc_zmax; o%foc_msigma = foc_msigma
      o%dfo_rhobeg = dfo_rhobeg; o%dfo_rhoend = dfo_rhoend
      o%ps_mesh = ps_mesh; o%ps_mads = ps_mads
      o%ga_pcross = ga_pcross; o%ga_pmut = ga_pmut; o%ga_elite = ga_elite
      o%ga_tournament = ga_tournament
      ok = .true.
   end subroutine read_options

   !> Print the correlation matrix of a completed least-squares fit.
   !> Entries near +/-1 mean the data cannot separate those two parameters:
   !> the fit may look excellent and still be meaningless.
   subroutine print_correlations(res, unit, threshold)
      type(opt_result), intent(in)   :: res
      integer, intent(in), optional  :: unit
      real(wp), intent(in), optional :: threshold
      integer :: u, i, j, n
      real(wp) :: thr
      u = output_unit; thr = 0.95_wp
      if (present(unit)) u = unit
      if (present(threshold)) thr = threshold
      if (.not. res%has_stats) then
         write (u, '(a)') ' no fit statistics available (least-squares runs only)'
         return
      end if
      n = size(res%x)
      write (u, '(a)') ' parameter correlation matrix:'
      do i = 1, n
         write (u, '(4x,i3,2x,*(f8.4))') i, (res%corr(i, j), j=1, n)
      end do
      do i = 1, n - 1
         do j = i + 1, n
            if (abs(res%corr(i, j)) >= thr) &
               write (u, '(a,i0,a,i0,a,f7.4,a)') ' warning: parameters ', i, ' and ', j, &
               ' are correlated at ', res%corr(i, j), ' -- they are not independently determined'
         end do
      end do
      if (res%rank < n) write (u, '(a,i0,a,i0,a)') ' warning: normal matrix rank ', &
         res%rank, ' < ', n, ' -- the model is over-parameterised for this data'
   end subroutine print_correlations

end module fitpar
