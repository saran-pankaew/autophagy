!> FitPar -- limited-memory quasi-Newton and nonlinear conjugate gradients.
!>
!> solve_lbfgsb: limited-memory BFGS with box constraints, handled by gradient
!> projection: at each iteration the variables sitting on a bound with a
!> gradient pushing further out are frozen, the two-loop recursion is applied
!> on the free subspace only, and the step is taken along the projected path.
!> Memory pairs violating the curvature condition are discarded, which keeps
!> the implicit inverse Hessian positive definite.
!>
!> This is the workhorse: for a smooth objective with an accurate gradient it
!> converges superlinearly and costs O(m*n) memory, m ~ 10.
module fitpar_local_quasi
   use fitpar_kinds
   use fitpar_types
   use fitpar_eval
   use fitpar_linesearch
   implicit none
   private
   public :: solve_lbfgsb, solve_cg

contains

   subroutine solve_lbfgsb(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      real(wp), allocatable :: g(:), gp(:), d(:), q(:), xnew(:), gnew(:)
      real(wp), allocatable :: s(:, :), y(:, :), rho(:), alpha_l(:)
      logical, allocatable  :: free(:)
      real(wp) :: f, fnew, alpha, gnorm, fprev, sty, yty, gamma, beta_c
      integer  :: n, mem, iter, k, idx, npairs, head, info, nstall
      logical  :: bounded

      n = p%n
      mem = max(3, o%lbfgs_memory)
      bounded = p%bounded()
      allocate (g(n), gp(n), d(n), q(n), xnew(n), gnew(n), free(n))
      allocate (s(n, mem), y(n, mem), rho(mem), alpha_l(mem))
      npairs = 0; head = 0; nstall = 0

      call p%clip(x)
      call ev%fg(x, f, g)
      fprev = f
      res%status = OPT_MAX_ITER

      do iter = 1, o%max_iter
         ! --- projected gradient and active-set detection --------------------
         call active_set(p, x, g, free, bounded)
         gp = g
         where (.not. free) gp = zero
         gnorm = maxval(abs(gp))
         if (o%verbose >= 2 .and. mod(iter - 1, max(1, o%print_every)) == 0) &
            write (o%unit, '(a,i6,a,i8,a,es20.12,a,es11.3)') '  it ', iter, &
            '  nf ', ev%nfev, '  f ', f, '  |Pg| ', gnorm

         if (gnorm <= o%tol_g) then
            res%status = OPT_CONV_G; exit
         end if
         if (ev%stop_flag) then
            res%status = ev%stop_code; exit
         end if

         ! --- two-loop recursion on the free subspace ------------------------
         q = -gp
         do k = 1, npairs
            idx = modulo(head - k, mem) + 1
            alpha_l(idx) = rho(idx) * dot_product(s(:, idx), q)
            q = q - alpha_l(idx) * y(:, idx)
         end do
         if (npairs > 0) then
            idx = modulo(head - 1, mem) + 1
            sty = dot_product(s(:, idx), y(:, idx))
            yty = dot_product(y(:, idx), y(:, idx))
            gamma = sty / max(yty, opt_tiny)
            q = gamma * q
         end if
         do k = npairs, 1, -1
            idx = modulo(head - k, mem) + 1
            beta_c = rho(idx) * dot_product(y(:, idx), q)
            q = q + s(:, idx) * (alpha_l(idx) - beta_c)
         end do
         d = q
         where (.not. free) d = zero

         if (dot_product(d, gp) >= zero .or. all(abs(d) <= opt_tiny)) then
            d = -gp                       ! restart on a bad direction
            npairs = 0; head = 0
         end if

         ! --- step ------------------------------------------------------------
         alpha = one
         if (iter == 1) alpha = min(one, one / max(maxval(abs(d)), opt_tiny))
         if (bounded) then
            call projected_search(ev, p, x, f, g, d, alpha, xnew, fnew, info)
            if (info == 0) call ev%grad(xnew, gnew)
         else
            call wolfe_search(ev, x, f, g, d, alpha, xnew, fnew, gnew, info)
         end if

         if (info == 2 .or. info == 3) then      ! line search failed
            if (npairs > 0) then                 ! purge memory and retry once
               npairs = 0; head = 0
               d = -gp; alpha = one / max(maxval(abs(gp)), opt_tiny)
               if (bounded) then
                  call projected_search(ev, p, x, f, g, d, alpha, xnew, fnew, info)
                  if (info == 0) call ev%grad(xnew, gnew)
               else
                  call wolfe_search(ev, x, f, g, d, alpha, xnew, fnew, gnew, info)
               end if
            end if
            if (info /= 0) then
               res%status = OPT_STAGNATED; exit
            end if
         end if
         if (info == 4) then
            if (fnew < f) then
               x = xnew; f = fnew
            end if
            res%status = ev%stop_code; exit
         end if

         ! --- memory update ----------------------------------------------------
         head = modulo(head, mem) + 1
         s(:, head) = xnew - x
         y(:, head) = gnew - g
         sty = dot_product(s(:, head), y(:, head))
         if (sty > 1.0e-10_wp * sqrt(sum(s(:, head)**2) * sum(y(:, head)**2))) then
            rho(head) = one / sty
            npairs = min(npairs + 1, mem)
         else
            head = modulo(head - 2 + mem, mem) + 1   ! reject this pair
         end if

         ! --- convergence tests -------------------------------------------------
         if (reldiff(f, fnew) <= o%tol_f .and. iter > 1) then
            x = xnew; f = fnew; g = gnew
            res%status = OPT_CONV_F; exit
         end if
         if (maxval(abs(xnew - x)) <= o%tol_x * max(one, maxval(abs(x)))) then
            x = xnew; f = fnew; g = gnew
            res%status = OPT_CONV_X; exit
         end if
         if (fnew >= fprev - opt_tiny) then
            nstall = nstall + 1
         else
            nstall = 0
         end if
         fprev = fnew
         x = xnew; f = fnew; g = gnew
         if (o%stall_iter > 0 .and. nstall >= o%stall_iter) then
            res%status = OPT_STAGNATED; exit
         end if
         if (iter == o%max_iter) res%status = OPT_MAX_ITER
      end do

      call active_set(p, x, g, free, bounded)
      gp = g; where (.not. free) gp = zero
      res%x = x; res%f = f; res%g = g
      res%gnorm = maxval(abs(gp))
      res%niter = iter
   end subroutine solve_lbfgsb

   !> Freeze variables pressed against a bound by the gradient.
   pure subroutine active_set(p, x, g, free, bounded)
      type(opt_problem), intent(in) :: p
      real(wp), intent(in)  :: x(:), g(:)
      logical, intent(out)  :: free(:)
      logical, intent(in)   :: bounded
      real(wp) :: tolb
      integer  :: i
      free = .true.
      if (.not. bounded) return
      do i = 1, size(x)
         tolb = 1.0e-10_wp * max(one, abs(p%lb(i)), abs(p%ub(i)))
         if (x(i) <= p%lb(i) + tolb .and. g(i) > zero) free(i) = .false.
         if (x(i) >= p%ub(i) - tolb .and. g(i) < zero) free(i) = .false.
      end do
   end subroutine active_set

   !> Polak-Ribiere+ nonlinear CG with strong Wolfe steps and automatic
   !> restarts.  Cheaper per iteration than L-BFGS and useful when n is very
   !> large; bounds are enforced by clipping only, so prefer L-BFGS-B if the
   !> solution sits on a bound.
   subroutine solve_cg(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      real(wp), allocatable :: g(:), gold(:), d(:), xnew(:), gnew(:)
      real(wp) :: f, fnew, alpha, beta, gnorm, denom
      integer  :: n, iter, info

      n = p%n
      allocate (g(n), gold(n), d(n), xnew(n), gnew(n))
      call p%clip(x)
      call ev%fg(x, f, g)
      d = -g
      res%status = OPT_MAX_ITER

      do iter = 1, o%max_iter
         gnorm = maxval(abs(g))
         if (o%verbose >= 2 .and. mod(iter - 1, max(1, o%print_every)) == 0) &
            write (o%unit, '(a,i6,a,i8,a,es20.12,a,es11.3)') '  it ', iter, &
            '  nf ', ev%nfev, '  f ', f, '  |g|  ', gnorm
         if (gnorm <= o%tol_g) then
            res%status = OPT_CONV_G; exit
         end if
         if (ev%stop_flag) then
            res%status = ev%stop_code; exit
         end if

         alpha = one
         if (iter == 1) alpha = one / max(maxval(abs(d)), opt_tiny)
         call wolfe_search(ev, x, f, g, d, alpha, xnew, fnew, gnew, info, &
                           c2_in=0.1_wp)
         if (info == 2 .or. info == 3) then
            d = -g
            alpha = one / max(maxval(abs(g)), opt_tiny)
            call wolfe_search(ev, x, f, g, d, alpha, xnew, fnew, gnew, info, &
                              c2_in=0.1_wp)
            if (info /= 0) then
               res%status = OPT_STAGNATED; exit
            end if
         end if

         if (reldiff(f, fnew) <= o%tol_f) then
            x = xnew; f = fnew; g = gnew
            res%status = OPT_CONV_F; exit
         end if

         gold = g
         x = xnew; f = fnew; g = gnew
         call p%clip(x)
         denom = dot_product(gold, gold)
         if (denom <= opt_tiny) then
            beta = zero
         else
            beta = max(zero, dot_product(g, g - gold) / denom)   ! PR+
         end if
         if (mod(iter, n) == 0) beta = zero                      ! periodic restart
         d = -g + beta * d
         if (dot_product(d, g) >= zero) d = -g
         if (ev%stop_flag) then
            res%status = ev%stop_code; exit
         end if
      end do

      res%x = x; res%f = f; res%g = g
      res%gnorm = maxval(abs(g))
      res%niter = iter
   end subroutine solve_cg

end module fitpar_local_quasi
