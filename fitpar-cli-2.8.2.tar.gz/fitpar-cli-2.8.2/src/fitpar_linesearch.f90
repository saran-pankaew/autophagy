!> FitPar -- line searches.
!>
!> Two are provided:
!>
!>   wolfe_search      strong Wolfe conditions with safeguarded polynomial
!>                     interpolation (Nocedal & Wright, Alg. 3.5/3.6).  This is
!>                     what quasi-Newton methods need: the curvature condition
!>                     is what keeps the L-BFGS memory positive definite.
!>
!>   projected_search  Armijo backtracking along the *projected* path
!>                     P(x + a d), for box-constrained problems where the
!>                     unconstrained Wolfe conditions are not meaningful.
module fitpar_linesearch
   use fitpar_kinds
   use fitpar_types
   use fitpar_eval
   implicit none
   private
   public :: wolfe_search, projected_search

   integer, parameter :: max_ls = 40

contains

   !> Returns alpha satisfying the strong Wolfe conditions along d.
   !> info: 0 ok, 1 iteration limit, 2 not a descent direction,
   !>       3 step collapsed to zero, 4 evaluation budget hit.
   subroutine wolfe_search(ev, x0, f0, g0, d, alpha, xn, fn, gn, info, &
                           c1_in, c2_in, alpha_max_in)
      type(evaluator_t), intent(inout) :: ev
      real(wp), intent(in)    :: x0(:), f0, g0(:), d(:)
      real(wp), intent(inout) :: alpha            !< in: initial guess, out: accepted
      real(wp), intent(out)   :: xn(:), fn, gn(:)
      integer, intent(out)    :: info
      real(wp), intent(in), optional :: c1_in, c2_in, alpha_max_in

      real(wp) :: c1, c2, amax, phi0, dphi0
      real(wp) :: a, a_prev, phi, phi_prev, dphi, dphi_prev
      real(wp) :: a_lo, a_hi, phi_lo, phi_hi, dphi_lo, at, denom
      integer  :: it

      c1 = 1.0e-4_wp; c2 = 0.9_wp; amax = 1.0e3_wp
      if (present(c1_in)) c1 = c1_in
      if (present(c2_in)) c2 = c2_in
      if (present(alpha_max_in)) amax = alpha_max_in

      phi0 = f0
      dphi0 = dot_product(g0, d)
      xn = x0; fn = f0; gn = g0
      if (dphi0 >= zero) then
         info = 2; alpha = zero; return
      end if

      a = max(min(alpha, amax), 1.0e-16_wp)
      a_prev = zero; phi_prev = phi0; dphi_prev = dphi0
      info = 1

      ! ---- bracketing phase -------------------------------------------------
      do it = 1, max_ls
         xn = x0 + a * d
         call ev%fg(xn, phi, gn)
         if (ev%stop_flag) then
            fn = phi; alpha = a; info = 4; return
         end if
         dphi = dot_product(gn, d)

         if (phi > phi0 + c1 * a * dphi0 .or. (it > 1 .and. phi >= phi_prev)) then
            a_lo = a_prev; phi_lo = phi_prev; dphi_lo = dphi_prev
            a_hi = a;      phi_hi = phi
            exit
         end if
         if (abs(dphi) <= -c2 * dphi0) then          ! strong Wolfe satisfied
            alpha = a; fn = phi; info = 0; return
         end if
         if (dphi >= zero) then
            a_lo = a;      phi_lo = phi;      dphi_lo = dphi
            a_hi = a_prev; phi_hi = phi_prev
            exit
         end if
         a_prev = a; phi_prev = phi; dphi_prev = dphi
         a = min(two * a, amax)
         if (a >= amax) then                          ! accept the largest step
            xn = x0 + a * d
            call ev%fg(xn, phi, gn)
            alpha = a; fn = phi; info = 0; return
         end if
         if (it == max_ls) then
            a_lo = zero; phi_lo = phi0; dphi_lo = dphi0
            a_hi = a;    phi_hi = phi
         end if
      end do

      ! ---- zoom phase -------------------------------------------------------
      do it = 1, max_ls
         if (abs(a_hi - a_lo) < 1.0e-16_wp * max(one, abs(a_lo))) then
            info = 3; exit
         end if
         ! safeguarded quadratic interpolation, bisection fallback
         denom = phi_hi - phi_lo - dphi_lo * (a_hi - a_lo)
         if (abs(denom) > opt_tiny) then
            at = a_lo - half * dphi_lo * (a_hi - a_lo)**2 / denom
         else
            at = half * (a_lo + a_hi)
         end if
         if ((at - min(a_lo, a_hi)) < 0.1_wp * abs(a_hi - a_lo) .or. &
             (max(a_lo, a_hi) - at) < 0.1_wp * abs(a_hi - a_lo) .or. &
             .not. is_finite(at)) at = half * (a_lo + a_hi)

         xn = x0 + at * d
         call ev%fg(xn, phi, gn)
         if (ev%stop_flag) then
            alpha = at; fn = phi; info = 4; return
         end if
         dphi = dot_product(gn, d)

         if (phi > phi0 + c1 * at * dphi0 .or. phi >= phi_lo) then
            a_hi = at; phi_hi = phi
         else
            if (abs(dphi) <= -c2 * dphi0) then
               alpha = at; fn = phi; info = 0; return
            end if
            if (dphi * (a_hi - a_lo) >= zero) then
               a_hi = a_lo; phi_hi = phi_lo
            end if
            a_lo = at; phi_lo = phi; dphi_lo = dphi
         end if
      end do

      ! fall back on the best bracket end that actually decreased f
      alpha = a_lo
      xn = x0 + alpha * d
      call ev%fg(xn, fn, gn)
      if (fn > f0) then
         alpha = zero; xn = x0; fn = f0; gn = g0
         if (info /= 4) info = 3
      end if
   end subroutine wolfe_search

   !> Armijo backtracking along the projected path P(x + a d).
   !> Used when bounds are active: the projected path is piecewise linear, so
   !> the sufficient-decrease test is written against the realised step.
   subroutine projected_search(ev, p, x0, f0, g0, d, alpha, xn, fn, info, c1_in)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      real(wp), intent(in)    :: x0(:), f0, g0(:), d(:)
      real(wp), intent(inout) :: alpha
      real(wp), intent(out)   :: xn(:), fn
      integer, intent(out)    :: info
      real(wp), intent(in), optional :: c1_in
      real(wp) :: c1, a, gs
      integer  :: it

      c1 = 1.0e-4_wp
      if (present(c1_in)) c1 = c1_in
      a = max(alpha, 1.0e-16_wp)
      info = 1
      do it = 1, max_ls
         xn = x0 + a * d
         call p%clip(xn)
         fn = ev%f(xn)
         gs = dot_product(g0, xn - x0)
         if (fn <= f0 + c1 * gs .and. fn < f0) then
            alpha = a; info = 0; return
         end if
         if (ev%stop_flag) then
            alpha = a; info = 4; return
         end if
         a = half * a
         if (a * maxval(abs(d)) < 1.0e-18_wp) exit
      end do
      alpha = zero; xn = x0; fn = f0; info = 3
   end subroutine projected_search

end module fitpar_linesearch
