!> Derivative-free Gauss-Newton for bound-constrained nonlinear least squares
!> (method 'dfogn').  Own implementation after C. Cartis and L. Roberts, "A
!> derivative-free Gauss-Newton method", Math. Program. Comput. 11 (2019).
!>
!> Every residual gets a linear model r(xk + s) ~ r(xk) + J s, interpolated on
!> n + 1 points: the current iterate and n others.  Each iteration takes a
!> trust-region Gauss-Newton step (Levenberg-Marquardt parameter chosen so the
!> step fits the radius, then projected on the box), evaluates it, and swaps it
!> into the point set by the Lagrange-polynomial-and-distance rule.  So a model
!> of all m residuals costs n + 1 evaluations at the start and one per iteration
!> after that: far fewer than a finite-difference Jacobian per iteration.
!> Bounded coordinates are scaled to [0, 1]; unbounded ones by xscale, else by
!> the magnitude of the start value.  dfogn_starts > 1 restarts it from
!> uniform points in the box (-1: until the budget is spent).  Fit statistics
!> come from the model Jacobian at the best point, with no extra evaluation.
module fitpar_lsq_dfogn
   use fitpar_kinds
   use fitpar_types
   use fitpar_eval
   use fitpar_linalg
   use fitpar_rng
   implicit none
   private
   public :: solve_dfogn

contains

   subroutine solve_dfogn(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res
      integer  :: n, m, j, i, start, nstarts, iters, iter_all
      real(wp), allocatable :: a(:), w(:), ulo(:), uhi(:), xs0(:), xr(:), jr(:, :), jbest(:, :)
      real(wp), allocatable :: xbest(:), rb(:), cov(:, :), gm(:, :)
      real(wp) :: fr, fbest, rhobeg, rhoend
      type(rng_t) :: rng
      logical :: bnd, ok

      n = p%n; m = p%m
      allocate (a(n), w(n), ulo(n), uhi(n), xs0(n), xr(n), jr(m, n), jbest(m, n), xbest(n), rb(m))
      call p%clip(x)
      bnd = allocated(p%lb) .and. allocated(p%ub)
      do j = 1, n
         if (bnd) then
            if (abs(p%lb(j)) < 0.5_wp * opt_huge .and. abs(p%ub(j)) < 0.5_wp * opt_huge .and. p%ub(j) > p%lb(j)) then
               a(j) = p%lb(j); w(j) = p%ub(j) - p%lb(j); ulo(j) = zero; uhi(j) = one; cycle
            end if
         end if
         ! unbounded: the magnitude of the start value, or xscale where the user set
         ! it (FitPar fills xscale with ones when it is not given)
         w(j) = abs(x(j))
         if (allocated(p%xscale)) then
            if (p%xscale(j) > zero .and. (p%xscale(j) /= one .or. w(j) <= zero)) w(j) = p%xscale(j)
         end if
         if (w(j) <= zero) w(j) = one
         a(j) = x(j) - half * w(j); ulo(j) = -opt_huge; uhi(j) = opt_huge
      end do
      rhobeg = o%dfo_rhobeg; if (rhobeg <= zero) rhobeg = 0.1_wp
      rhoend = o%dfo_rhoend; if (rhoend <= zero) rhoend = 1.0e-10_wp
      nstarts = max(1, o%dfogn_starts); if (o%dfogn_starts < 0) nstarts = huge(1)
      call rng%seed(o%seed)
      fbest = opt_huge; xbest = x; jbest = zero; xs0 = x; iter_all = 0
      do start = 1, nstarts
         call one_run(xs0, xr, fr, jr, iters)
         iter_all = iter_all + iters
         if (fr < fbest) then
            fbest = fr; xbest = xr; jbest = jr
         end if
         if (ev%stop_flag .or. ev%fbest <= o%target_f) exit
         if (ev%budget_left() < n + 2) exit
         do j = 1, n                                    ! the next start: uniform in the (scaled) box
            xs0(j) = a(j) + rng%uniform() * w(j)
         end do
      end do

      ! ---- results and fit statistics (one-sigma differences, or the model Jacobian)
      x = xbest
      call ev%residual(x, rb, ok)                        ! one evaluation: the residuals at the best point
      res%x = x; res%f = half * sum(rb**2); res%niter = iter_all
      res%chi2 = sum(rb**2); res%dof = max(1, m - n)
      res%redchi2 = res%chi2 / real(res%dof, wp); res%rms = sqrt(res%chi2 / real(m, wp))
      if (allocated(res%g)) deallocate (res%g)
      allocate (res%g(n)); res%g = matmul(transpose(jbest), rb); res%gnorm = maxval(abs(res%g))
      if (ev%fbest <= o%target_f) then
         res%status = OPT_CONV_TARGET
      else if (ev%stop_flag) then
         res%status = ev%stop_code
      else
         res%status = OPT_CONV_X
      end if
      if (o%lm_covar) then
         if (o%dfogn_stats_fd .and. ok) call sigma_jacobian(x, rb, jbest)
         allocate (gm(n, n), cov(n, n))
         gm = matmul(transpose(jbest), jbest)
         call sym_pinv(gm, cov, res%rank, 1.0e-12_wp)
         call mark_undetermined(gm, cov, res)
         if (allocated(res%cov)) deallocate (res%cov)
         if (allocated(res%corr)) deallocate (res%corr)
         if (allocated(res%sigma)) deallocate (res%sigma)
         if (allocated(res%sigma_abs)) deallocate (res%sigma_abs)
         allocate (res%cov(n, n), res%corr(n, n), res%sigma(n), res%sigma_abs(n))
         ! unscaled first: absolute uncertainties and the correlations (2.8.2)
         do i = 1, n
            res%sigma_abs(i) = sqrt(max(cov(i, i), zero))
         end do
         do i = 1, n
            do j = 1, n
               res%corr(i, j) = zero
               if (res%sigma_abs(i) > zero .and. res%sigma_abs(j) > zero) &
                  res%corr(i, j) = cov(i, j) / (res%sigma_abs(i) * res%sigma_abs(j))
            end do
         end do
         cov = cov * res%redchi2
         res%cov = cov
         do i = 1, n
            res%sigma(i) = sqrt(max(cov(i, i), zero))
         end do
         res%has_stats = .true.
      end if

   contains

      !> Jacobian for the error bars, column by column: a central difference with
      !> a step h_j chosen so that |r(x + h_j e_j) - r(x)| is about sqrt(chi2/dof),
      !> i.e. a step of about one standard error.  A model that prints only a few
      !> digits is noisy far below that scale, and the interpolation model of a
      !> converged run, built on points 1e-9 apart, measures that noise instead of
      !> the slope.  A column whose evaluations fail keeps its model value.
      subroutine sigma_jacobian(xc, r0, jout)
         real(wp), intent(in)    :: xc(:), r0(:)
         real(wp), intent(inout) :: jout(:, :)
         real(wp) :: u(n), ut(n), rp(m), rm(m), h, hs, d, tgt
         integer  :: j, tries
         logical  :: okp, okm
         if (ev%budget_left() < 3 * n + 1 .or. ev%stop_flag) return
         ! the step changes the residuals by about one standard error: by
         ! sqrt(chi2/dof), or by dfogn_stats_dr when that is set (1 for
         ! residuals divided by true standard deviations)
         tgt = o%dfogn_stats_dr
         if (tgt <= zero) tgt = sqrt(sum(r0**2) / real(max(1, m - n), wp))
         ! an exact fit has no scatter to measure the step by: take residuals
         ! to be in units of their standard deviations (2.8.2)
         if (tgt < 1.0e-6_wp) tgt = one
         u = (xc - a) / w
         do j = 1, n
            if (ev%stop_flag) return
            d = norm2(jout(:, j)) * w(j)               ! |dr/du_j| from the model
            h = 1.0e-3_wp
            if (d > zero .and. d < opt_huge) h = tgt / d
            h = min(max(h, 1.0e-10_wp), 0.25_wp)
            okp = .false.
            do tries = 1, 8
               hs = signed_step(u(j), h, ulo(j), uhi(j))
               ut = u; ut(j) = u(j) + hs
               call ev%residual(a + ut * w, rp, okp)
               if (.not. okp .or. ev%stop_flag) exit
               d = norm2(rp - r0)
               if (d >= 0.3_wp * tgt .and. d <= 3.0_wp * tgt) exit
               if (d <= zero) then
                  h = 1000.0_wp * h
               else
                  h = h * min(1000.0_wp, max(1.0e-3_wp, tgt / d))
               end if
               h = min(max(h, 1.0e-12_wp), half)
               if (abs(hs) >= half .and. d < 0.3_wp * tgt) exit   ! no longer step fits the box
            end do
            if (.not. okp) cycle
            ut(j) = u(j) - hs
            okm = .false.
            if (ut(j) >= ulo(j) .and. ut(j) <= uhi(j) .and. .not. ev%stop_flag) &
               call ev%residual(a + ut * w, rm, okm)
            if (okm) then
               jout(:, j) = (rp - rm) / (two * hs * w(j))
            else
               jout(:, j) = (rp - r0) / (hs * w(j))
            end if
         end do
      end subroutine sigma_jacobian

      !> +h if it stays in [lo, hi], else -h, else the longer way to a bound.
      pure function signed_step(u0, h, lo, hi) result(hs)
         real(wp), intent(in) :: u0, h, lo, hi
         real(wp) :: hs
         if (u0 + h <= hi) then
            hs = h
         else if (u0 - h >= lo) then
            hs = -h
         else if (hi - u0 >= u0 - lo) then
            hs = hi - u0
         else
            hs = lo - u0
         end if
      end function signed_step

      !> One local run from x0: returns the best point, its chi2 and the model
      !> Jacobian there (in x units).
      subroutine one_run(x0, xout, fout, jout, it)
         real(wp), intent(in)  :: x0(:)
         real(wp), intent(out) :: xout(:), fout, jout(:, :)
         integer, intent(out)  :: it
         real(wp) :: y(n, n + 1), f(m, n + 1), fv(n + 1), dmat(n, n), lu(n, n), jm(m, n), gg(n, n)
         real(wp) :: gv(n), s(n), u0(n), un(n), rn(m), c(n), z(n), e(n)
         real(wp) :: delta, rho, fk, pred, ratio, ns, fn, wt, bestwt, dist, dfar, dmin
         integer  :: piv(n), idx(n), k, t, i2, jj, info, far, nn, hopeless, stall
         logical  :: okr, repair
         u0 = min(max((x0 - a) / w, ulo), uhi)
         y(:, 1) = u0; call resid(u0, f(:, 1), okr); fv(1) = sum(f(:, 1)**2)
         nn = 1
         do i2 = 1, n                                   ! coordinate steps into the box
            if (ev%stop_flag) exit
            y(:, i2 + 1) = u0
            if (u0(i2) + rhobeg <= uhi(i2)) then
               y(i2, i2 + 1) = u0(i2) + rhobeg
            else
               y(i2, i2 + 1) = u0(i2) - rhobeg
            end if
            call resid(y(:, i2 + 1), f(:, i2 + 1), okr); fv(i2 + 1) = sum(f(:, i2 + 1)**2); nn = nn + 1
         end do
         k = minloc(fv(1:nn), 1); it = 0
         if (nn < n + 1) then
            xout = a + y(:, k) * w; fout = fv(k); jout = zero; return
         end if
         delta = rhobeg; rho = rhobeg; hopeless = 0; stall = 0; repair = .false.
         do
            if (ev%stop_flag .or. ev%fbest <= o%target_f) exit
            it = it + 1
            if (it > o%max_iter) exit
            call build_model(k, y, f, idx, dmat, lu, piv, jm, info)
            if (info /= 0) exit
            fk = fv(k)
            if (o%verbose >= 2 .and. mod(it - 1, max(1, o%print_every)) == 0) &
               write (o%unit, '(a,i6,a,i8,a,es20.12,a,es10.2,a,es10.2)') '  it ', it, '  nf ', ev%nfev, &
               '  chi2 ', fk, '  delta ', delta, '  rho ', rho
            gg = matmul(transpose(jm), jm)
            gv = matmul(transpose(jm), f(:, k))
            ! multistart: a run whose model minimum stays above the best earlier
            ! run's value is in a worse basin; end it and spend the rest elsewhere
            if (fbest < opt_huge .and. it > 10) then
               if (gn_floor(gg, gv, fk) > two * fbest) then
                  hopeless = hopeless + 1
                  if (hopeless >= 3) exit
               else
                  hopeless = 0
               end if
            end if
            call tr_solve(gg, gv, delta, s)             ! Levenberg-Marquardt / More-Sorensen
            call box_refine(jm, f(:, k), y(:, k), ulo, uhi, delta, s)   ! active bounds
            s = min(max(y(:, k) + s, ulo), uhi) - y(:, k)     ! the box
            pred = fk - sum((f(:, k) + matmul(jm, s))**2)
            if (o%dfogn_pred_tol > zero .and. pred >= zero .and. pred < two * o%dfogn_pred_tol &
                .and. delta <= 10.0_wp * rho) exit      ! the model can gain no more than wanted
            ns = norm2(s)
            ! a step onto (or next to) a point of the set gains nothing new: with a
            ! noisy objective (a program that prints few digits) the model can keep
            ! proposing the same point, so treat it as a short step
            dmin = opt_huge
            do i2 = 1, n + 1
               if (i2 /= k) dmin = min(dmin, norm2(y(:, k) + s - y(:, i2)))
            end do
            if (dmin < 0.1_wp * rho) repair = .true.
            if (ns < half * rho .or. pred <= zero .or. repair) then
               repair = .false.
               ! step too short to spend an evaluation on: repair the geometry or shrink rho
               far = idx(1); dfar = zero; t = 1
               do i2 = 1, n
                  dist = norm2(y(:, idx(i2)) - y(:, k))
                  if (dist > dfar) then; dfar = dist; far = idx(i2); t = i2; end if
               end do
               if (dfar > two * delta) then
                  e = zero; e(t) = one
                  call lu_solve(lu, piv, e, z, .true.)       ! row t of D^-1: gradient of its Lagrange polynomial
                  z = z / max(norm2(z), tiny(one))
                  un = min(max(y(:, k) + delta * z, ulo), uhi)
                  if (norm2(un - y(:, k)) < 1.0e-14_wp) un = min(max(y(:, k) - delta * z, ulo), uhi)
                  y(:, far) = un; call resid(un, f(:, far), okr); fv(far) = sum(f(:, far)**2)
                  if (fv(far) < fv(k)) k = far
                  cycle
               end if
               if (rho <= rhoend) exit
               call shrink_rho(rho, delta, rhoend)
               cycle
            end if
            un = y(:, k) + s
            call resid(un, rn, okr); fn = sum(rn**2)
            ratio = (fk - fn) / pred
            ! no decrease for many evaluations in a row: the objective is noisy at
            ! this scale (or flat); stop rather than spend the budget on noise
            if (fn < fk - 1.0e-14_wp * abs(fk)) then
               stall = 0
            else
               stall = stall + 1
               if (stall >= 10 * (n + 1) .and. rho <= 1.0e3_wp * rhoend) exit
               if (stall >= 50 * (n + 1)) exit
            end if
            if (ratio < 0.1_wp) then
               delta = max(half * delta, rho)
            else if (ratio <= 0.7_wp) then
               delta = max(half * delta, ns, rho)
            else
               delta = min(max(two * ns, delta), 1.0e10_wp)
            end if
            ! the point to replace: largest |Lagrange value| weighted by distance
            call lu_solve(lu, piv, un - y(:, k), c, .false.)
            bestwt = -one; t = k
            do i2 = 0, n
               if (i2 == 0) then
                  jj = k; if (fn >= fk) cycle
                  wt = abs(one - sum(c))
               else
                  jj = idx(i2); wt = abs(c(i2))
               end if
               if (fn < fk) then
                  dist = norm2(y(:, jj) - un)
               else
                  dist = norm2(y(:, jj) - y(:, k))
               end if
               wt = wt * max(one, (dist / delta)**2)**2
               if (wt > bestwt) then; bestwt = wt; t = jj; end if
            end do
            y(:, t) = un; f(:, t) = rn; fv(t) = fn
            if (fn < fk) k = t
            if (ratio < 0.1_wp .and. delta <= rho) then
               dfar = zero
               do i2 = 1, n + 1
                  if (i2 /= k) dfar = max(dfar, norm2(y(:, i2) - y(:, k)))
               end do
               if (dfar <= two * delta) then
                  if (rho <= rhoend) exit
                  call shrink_rho(rho, delta, rhoend)
               else
                  repair = .true.                       ! next: move the far point in (geometry step)
               end if
            end if
         end do
         k = minloc(fv, 1)
         xout = a + y(:, k) * w; fout = fv(k)
         call build_model(k, y, f, idx, dmat, lu, piv, jm, info)
         do jj = 1, n
            jout(:, jj) = jm(:, jj) / w(jj)             ! d r / d x = (d r / d u) / w
         end do
      end subroutine one_run

      subroutine resid(u, r, okr)
         real(wp), intent(in)  :: u(:)
         real(wp), intent(out) :: r(:)
         logical, intent(out)  :: okr
         call ev%residual(a + min(max(u, ulo), uhi) * w, r, okr)
      end subroutine resid

   end subroutine solve_dfogn

   !> Trust-region Gauss-Newton step: min |r + J s| subject to |s| <= delta, with
   !> G = J^T J and g = J^T r.  The Gauss-Newton step if it fits; otherwise the
   !> Levenberg-Marquardt parameter by safeguarded Newton iteration on
   !> 1/|s(lam)| = 1/delta (More and Sorensen), one Cholesky factorisation each.
   subroutine tr_solve(g, gv, delta, s)
      real(wp), intent(in)  :: g(:, :), gv(:), delta
      real(wp), intent(out) :: s(:)
      real(wp) :: a(size(gv), size(gv)), q(size(gv)), lam, lo, hi, ns, nq, tr
      integer  :: n, i, it, info
      n = size(gv)
      tr = zero
      do i = 1, n
         tr = tr + g(i, i)
      end do
      lam = 1.0e-12_wp * max(tr / n, tiny(one)); lo = zero; hi = opt_huge
      do it = 1, 40
         a = g
         do i = 1, n
            a(i, i) = a(i, i) + lam
         end do
         call cholesky_factor(a, info)
         if (info /= 0) then                            ! not positive definite at this lam
            lo = lam; lam = max(10.0_wp * lam, 1.0e-8_wp * max(tr / n, tiny(one))); cycle
         end if
         call cholesky_solve(a, -gv, s)
         ns = norm2(s)
         if (it == 1 .and. ns <= delta) return          ! the Gauss-Newton step fits
         if (abs(ns - delta) <= 0.1_wp * delta) return
         if (ns > delta) then
            lo = lam
         else
            hi = lam
         end if
         do i = 1, n                                    ! q = L^-1 s
            q(i) = (s(i) - sum(a(i, 1:i - 1) * q(1:i - 1))) / a(i, i)
         end do
         nq = norm2(q)
         lam = lam + (ns / nq)**2 * (ns - delta) / delta
         if (lam <= lo .or. lam >= hi) lam = merge(half * (lo + hi), 10.0_wp * max(lo, tiny(one)), hi < opt_huge)
      end do
      if (ns > delta) s = s * (delta / ns)
   end subroutine tr_solve

   !> Active-set refinement of a trust-region step in a box: variables the step
   !> would push out of the box are fixed on their bound, and the step is
   !> re-solved for the free ones with the fixed part folded into the residual
   !> and the radius that is left.  Repeated until no new variable is fixed.
   subroutine box_refine(jm, r, y, ulo, uhi, delta, s)
      real(wp), intent(in)    :: jm(:, :), r(:), y(:), ulo(:), uhi(:), delta
      real(wp), intent(inout) :: s(:)
      logical  :: free(size(s)), newly
      integer  :: n, j, pass, nf, fi(size(s))
      real(wp) :: rr(size(r)), rad
      real(wp), allocatable :: jf(:, :), sf(:)
      n = size(s); free = .true.
      do pass = 1, n
         newly = .false.
         do j = 1, n
            if (.not. free(j)) cycle
            if (y(j) + s(j) < ulo(j)) then
               s(j) = ulo(j) - y(j); free(j) = .false.; newly = .true.
            else if (y(j) + s(j) > uhi(j)) then
               s(j) = uhi(j) - y(j); free(j) = .false.; newly = .true.
            end if
         end do
         if (.not. newly) exit
         nf = 0
         do j = 1, n
            if (free(j)) then
               nf = nf + 1; fi(nf) = j
            end if
         end do
         if (nf == 0) exit
         rr = r + matmul(jm, merge(s, zero, .not. free))
         rad = sqrt(max(delta**2 - sum(merge(s, zero, .not. free)**2), (0.01_wp * delta)**2))
         allocate (jf(size(r), nf), sf(nf))
         jf = jm(:, fi(1:nf))
         call tr_solve(matmul(transpose(jf), jf), matmul(transpose(jf), rr), rad, sf)
         s(fi(1:nf)) = sf
         deallocate (jf, sf)
      end do
      s = min(max(y + s, ulo), uhi) - y
   end subroutine box_refine

   !> Minimum of the Gauss-Newton model |r + J s|^2 over all s: fk - g^T G^-1 g
   !> (with a small ridge for a singular G).
   function gn_floor(g, gv, fk) result(fl)
      real(wp), intent(in) :: g(:, :), gv(:), fk
      real(wp) :: fl, a(size(gv), size(gv)), sv(size(gv)), tr
      integer  :: i, info
      tr = zero
      do i = 1, size(gv)
         tr = tr + g(i, i)
      end do
      a = g
      do i = 1, size(gv)
         a(i, i) = a(i, i) + 1.0e-10_wp * max(tr / size(gv), tiny(one))
      end do
      call cholesky_factor(a, info)
      if (info /= 0) then
         fl = -opt_huge; return                         ! no conclusion
      end if
      call cholesky_solve(a, gv, sv)
      fl = fk - dot_product(gv, sv)
   end function gn_floor

   !> The lower trust-region bound, reduced as in BOBYQA / DFO-GN.
   pure subroutine shrink_rho(rho, delta, rhoend)
      real(wp), intent(inout) :: rho, delta
      real(wp), intent(in)    :: rhoend
      if (rho <= 16.0_wp * rhoend) then
         rho = rhoend
      else if (rho <= 250.0_wp * rhoend) then
         rho = sqrt(rho * rhoend)
      else
         rho = 0.1_wp * rho
      end if
      delta = max(half * delta, rho)
   end subroutine shrink_rho

   !> Interpolation model: D = [y_i - y_k], J = dR D^-1 (via LU of D).
   subroutine build_model(k, y, f, idx, dmat, lu, piv, jm, info)
      integer, intent(in)   :: k
      real(wp), intent(in)  :: y(:, :), f(:, :)
      integer, intent(out)  :: idx(:), piv(:), info
      real(wp), intent(out) :: dmat(:, :), lu(:, :), jm(:, :)
      integer :: i, j, n, m
      real(wp) :: rowv(size(y, 1)), sol(size(y, 1))
      n = size(y, 1); m = size(f, 1); j = 0
      do i = 1, n + 1
         if (i == k) cycle
         j = j + 1; idx(j) = i
         dmat(:, j) = y(:, i) - y(:, k)
      end do
      lu = dmat
      call lu_factor(lu, piv, info)
      if (info /= 0) return
      do i = 1, m                                        ! row i of J: D^T J(i,:)^T = dR(i,:)^T
         do j = 1, n
            rowv(j) = f(i, idx(j)) - f(i, k)
         end do
         call lu_solve(lu, piv, rowv, sol, .true.)
         jm(i, :) = sol
      end do
   end subroutine build_model

   !> LU factorisation with partial pivoting, in place.
   pure subroutine lu_factor(a, piv, info)
      real(wp), intent(inout) :: a(:, :)
      integer, intent(out)    :: piv(:), info
      integer :: n, i, j, p
      real(wp) :: tmp(size(a, 2))
      n = size(a, 1); info = 0
      do j = 1, n
         p = j - 1 + maxloc(abs(a(j:n, j)), 1); piv(j) = p
         if (abs(a(p, j)) <= tiny(one) * 1.0e10_wp) then
            info = j; return
         end if
         if (p /= j) then
            tmp = a(j, :); a(j, :) = a(p, :); a(p, :) = tmp
         end if
         do i = j + 1, n
            a(i, j) = a(i, j) / a(j, j)
            a(i, j + 1:n) = a(i, j + 1:n) - a(i, j) * a(j, j + 1:n)
         end do
      end do
   end subroutine lu_factor

   !> Solve A x = b (trans = .false.) or A^T x = b (trans = .true.) from lu_factor.
   pure subroutine lu_solve(lu, piv, b, x, trans)
      real(wp), intent(in)  :: lu(:, :), b(:)
      integer, intent(in)   :: piv(:)
      real(wp), intent(out) :: x(:)
      logical, intent(in)   :: trans
      integer :: n, i
      real(wp) :: t
      n = size(b); x = b
      if (.not. trans) then
         do i = 1, n
            t = x(i); x(i) = x(piv(i)); x(piv(i)) = t
         end do
         do i = 2, n
            x(i) = x(i) - dot_product(lu(i, 1:i - 1), x(1:i - 1))
         end do
         do i = n, 1, -1
            x(i) = (x(i) - dot_product(lu(i, i + 1:n), x(i + 1:n))) / lu(i, i)
         end do
      else
         do i = 1, n                                    ! U^T z = b
            x(i) = (x(i) - dot_product(lu(1:i - 1, i), x(1:i - 1))) / lu(i, i)
         end do
         do i = n - 1, 1, -1                            ! L^T y = z
            x(i) = x(i) - dot_product(lu(i + 1:n, i), x(i + 1:n))
         end do
         do i = n, 1, -1
            t = x(i); x(i) = x(piv(i)); x(piv(i)) = t
         end do
      end if
   end subroutine lu_solve

end module fitpar_lsq_dfogn
