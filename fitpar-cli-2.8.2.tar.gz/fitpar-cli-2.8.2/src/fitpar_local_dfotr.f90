!> FitPar -- model-based derivative-free trust-region optimisation.
!>
!> solve_dfo_tr implements the method of Powell's NEWUOA (unconstrained) and
!> BOBYQA (bound-constrained): maintain an interpolation set of m points,
!> build a quadratic model that interpolates f on it, minimise the model in a
!> trust region, and update the set with the new point.  The two differ here
!> only in whether the trust-region step is projected onto the bounds, which
!> is the distinction Powell draws between them; `bobyqa` is the default.
!>
!> The defining feature is the model update.  With m = 2n+1 points a full
!> quadratic (1 + n + n(n+1)/2 coefficients) is under-determined, so the
!> Hessian is not fitted from scratch each iteration.  Instead the change in
!> the Hessian is made as small as possible in the Frobenius norm subject to
!> the new interpolation conditions -- the minimum-change update that gives
!> the method its efficiency on expensive objectives: each iteration costs one
!> evaluation, not O(n^2).  The resulting least-change problem is the KKT
!> system of a quadratic program, solved here directly via the W matrix
!> (Powell's notation) rather than through his incrementally updated inverse.
!> That costs O(m^3) linear algebra per iteration instead of O(m^2), which is
!> irrelevant whenever an evaluation costs more than a matrix factorisation --
!> the regime the method exists for -- and it makes the code an order of
!> magnitude shorter and auditable.
!>
!> This is a reimplementation of the published method, not a translation of
!> Powell's Fortran 77.  It reproduces the algorithm's structure and its
!> behaviour on the standard tests; it does not reproduce his code's every
!> numerical safeguard.  For a certified reference implementation use PDFO.
module fitpar_local_dfotr
   use fitpar_kinds
   use fitpar_types
   use fitpar_eval
   use fitpar_linalg
   use fitpar_globutil
   implicit none
   private
   public :: solve_dfo_tr, dfo_probe_model

contains

   subroutine solve_dfo_tr(ev, p, o, x, res, bounded)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res
      logical, intent(in)              :: bounded      !< .true. = BOBYQA

      real(wp), allocatable :: y(:, :), fy(:), lb(:), ub(:), xb(:)
      real(wp), allocatable :: gq(:), hq(:, :), d(:), xnew(:), xopt(:)
      integer  :: n, m, i, j, k, iter, kopt, knew, info
      real(wp) :: rho, delta, rhobeg, rhoend, fopt, fnew, pred, ared, ratio
      real(wp) :: dist, worst, t
      real(wp), allocatable :: lagv(:)
      real(wp) :: far, best, lsc, lval
      real(wp), allocatable :: lsol(:, :), lz(:, :)
      real(wp), allocatable :: cand(:), trial(:)
      integer  :: nfail, kfar, jthin, sgn

      n = p%n
      call get_box(p, x, lb, ub)
      if (.not. bounded) then                       ! NEWUOA: ignore the box
         lb = -opt_huge; ub = opt_huge
      end if
      m = 2 * n + 1                                 ! Powell's recommended size
      allocate (y(n, m), fy(m), xb(n), gq(n), hq(n, n), d(n), xnew(n), xopt(n), lagv(m))
      allocate (cand(n), trial(n), lsol(m + n + 1, m), lz(n, m))

      ! --- initial trust-region radii -------------------------------------
      rhobeg = o%dfo_rhobeg
      if (rhobeg <= zero) then
         rhobeg = 0.1_wp * maxval(ub - lb)
         if (.not. bounded .or. rhobeg <= zero) rhobeg = 0.1_wp * max(one, maxval(abs(x)))
      end if
      rhoend = o%dfo_rhoend
      if (rhoend <= zero) rhoend = max(1.0e-10_wp, o%tol_x)
      rhobeg = max(rhobeg, two * rhoend)

      ! --- initial interpolation set: the centre and +/- rhobeg per axis ---
      xb = min(max(x, lb), ub)
      y(:, 1) = xb
      do i = 1, n
         y(:, 2 * i) = xb;     y(i, 2 * i)     = min(xb(i) + rhobeg, ub(i))
         y(:, 2 * i + 1) = xb; y(i, 2 * i + 1) = max(xb(i) - rhobeg, lb(i))
         if (y(i, 2 * i) == xb(i))     y(i, 2 * i)     = min(xb(i) + half * rhobeg, ub(i))
         if (y(i, 2 * i + 1) == xb(i)) y(i, 2 * i + 1) = max(xb(i) - half * rhobeg, lb(i))
      end do
      do k = 1, m
         fy(k) = ev%f(y(:, k))
         if (ev%stop_flag) exit
      end do
      kopt = minloc(fy, dim=1)
      xopt = y(:, kopt); fopt = fy(kopt)
      rho = rhobeg; delta = rhobeg; nfail = 0
      res%status = OPT_MAX_FEVAL

      ! =====================================================================
      do iter = 1, o%max_iter
         if (ev%stop_flag) then
            res%status = ev%stop_code; exit
         end if

         call build_model(y, fy, xopt, gq, hq, info)
         if (info /= 0) then                        ! degenerate set: re-seed it
            call refresh_set(y, fy, xopt, rho, lb, ub, ev, kopt, fopt)
            if (ev%stop_flag) cycle
            xopt = y(:, kopt); fopt = fy(kopt)
            cycle
         end if

         call tr_step(gq, hq, delta, xopt, lb, ub, d, pred)

         if (norm2v(d) < half * rho .or. pred <= zero) then
            ! The step is too short to trust: shrink rho, or stop.
            if (rho <= rhoend) then
               res%status = OPT_CONV_X; exit
            end if
            delta = max(half * rho, rhoend)
            rho = max(0.1_wp * rho, rhoend)
            call refresh_set(y, fy, xopt, rho, lb, ub, ev, kopt, fopt)
            if (.not. ev%stop_flag) then
               xopt = y(:, kopt); fopt = fy(kopt)
            end if
            cycle
         end if

         xnew = min(max(xopt + d, lb), ub)
         fnew = ev%f(xnew)
         if (ev%stop_flag) then
            res%status = ev%stop_code
            if (fnew < fopt) then
               fopt = fnew; xopt = xnew
            end if
            exit
         end if
         ared = fopt - fnew
         ratio = ared / max(pred, opt_tiny)

         ! --- is a poor step the model's fault or the radius's? ---------------
         ! Powell asks this before every contraction, and it is the difference
         ! between a trust region that converges and one that collapses.  If
         ! the interpolation set still has a point well outside the current
         ! region, the model there is an extrapolation and the poor ratio says
         ! nothing about delta.  Replace that point by a geometry point at
         ! distance delta and leave delta alone.  Without this the radius is
         ! contracted on every bad model, rho follows it down, and the method
         ! crawls: measured on Rosenbrock-10, rho reached 1e-4 while f was
         ! still 3.
         if (ratio <= 0.1_wp) then
            far = zero; kfar = 0
            do k = 1, m
               if (k == kopt) cycle
               dist = norm2v(y(:, k) - xopt)
               if (dist > far) then
                  far = dist; kfar = k
               end if
            end do
            if (kfar > 0 .and. far > two * delta) then
               ! Where to put the replacement point.  Powell maximises the
               ! Lagrange polynomial of the point being dropped over the trust
               ! region; the maximiser is the position that improves the
               ! conditioning of the set the most.  Coordinate directions alone
               ! are not enough -- on a rotated problem the informative
               ! directions are not the axes, and using them was why the
               ! axis-aligned ellipsoid was solved in 528 evaluations while the
               ! rotated one was not solved at all.  Here the candidates are
               ! the directions towards the existing points as well as the
               ! axes, which costs no objective evaluations.
               call lagrange_coeffs(y, xopt, lsol, lz, lsc, info)
               if (info /= 0) then
                  delta = half * delta
                  cycle
               end if
               best = -one
               xnew = xopt
               do k = 0, m
                  if (k == 0) then
                     cand = d / max(norm2v(d), opt_tiny)
                  else
                     if (k == kopt) cycle
                     cand = y(:, k) - xopt
                     t = norm2v(cand)
                     if (t <= opt_tiny) cycle
                     cand = cand / t
                  end if
                  do sgn = 1, -1, -2
                     trial = xopt + real(sgn, wp) * delta * cand
                     call p%clip(trial)
                     lval = lagrange_value(lsol, lz, lsc, xopt, trial, kfar)
                     if (abs(lval) > best) then
                        best = abs(lagv(kfar)); xnew = trial
                     end if
                  end do
               end do
               do j = 1, n
                  trial = xopt; trial(j) = xopt(j) + delta
                  call p%clip(trial)
                  call lagrange_at(y, xopt, trial, lagv, info)
                  if (info == 0 .and. abs(lagv(kfar)) > best) then
                     best = abs(lagv(kfar)); xnew = trial
                  end if
               end do
               call p%clip(xnew)
               fnew = ev%f(xnew)
               if (ev%stop_flag) then
                  res%status = ev%stop_code; exit
               end if
               y(:, kfar) = xnew; fy(kfar) = fnew
               if (fnew < fopt) then
                  fopt = fnew; xopt = xnew; kopt = kfar
               end if
               nfail = 0
               cycle                               ! delta untouched
            end if
         end if

         ! --- trust-region radius --------------------------------------------
         if (ratio <= 0.1_wp) then
            delta = half * norm2v(d)
         else if (ratio <= 0.7_wp) then
            delta = max(half * delta, norm2v(d))
         else
            delta = max(delta, two * norm2v(d))
         end if
         ! Powell's rho-reduction phase.  delta is not allowed below rho, so
         ! without this the trust region never resolves finer than the initial
         ! interpolation spacing and the method crawls: rho is the resolution
         ! of the model, delta only the length of the step taken within it.
         if (delta <= 1.5_wp * rho) then
            delta = rho
            ! A step at the smallest scale that only *just* improves has also
            ! exhausted that resolution.  Counting only ratio <= 0 as failure
            ! leaves rho fixed forever while the method inches along in steps
            ! of length rho: the run then converges, but a hundred times more
            ! slowly than it should.
            if (ratio <= 0.1_wp) then
               nfail = nfail + 1
            else
               nfail = 0
            end if
            if (nfail >= 3) then
               if (rho <= rhoend) then
                  res%status = OPT_CONV_X; exit
               end if
               ! Reduce the resolution and carry on with the same points.
               ! Rebuilding the interpolation set here -- as an earlier version
               ! did -- throws away every bit of curvature the run has learned
               ! and pays 2n+1 evaluations for the privilege; the set contracts
               ! on its own as new points arrive near the incumbent.
               rho = max(0.1_wp * rho, rhoend)
               delta = rho
               nfail = 0
               cycle
            end if
         else
            nfail = 0
         end if

         ! --- which interpolation point to drop -------------------------------
         ! Powell weights distance from the new centre by its fourth power; the
         ! far points carry the least information about the local model.
         ! Which point to drop.  Distance alone is not enough: a set can be
         ! spread out and still be badly poised -- nearly coplanar, say -- and
         ! then the model is meaningless however well the linear algebra
         ! behaves.  Powell weights the distance by the k-th Lagrange
         ! polynomial evaluated at the new point, which is exactly how much
         ! the replacement improves the conditioning of the interpolation.
         ! Dropping that factor was the defect here: measured on Rosenbrock-10
         ! it is the difference between f = 3.9 and f = 1e-9.
         ! The Lagrange weights cost a second O(m^3) factorisation with m
         ! right-hand sides, and on a step that improved the incumbent they
         ! change nothing: the farthest point is then a safe drop.  Ask for
         ! them only when the step failed, which is when a badly poised set is
         ! the plausible explanation.  Measured on the rotated instances this
         ! is most of the method's wall-clock cost.
         info = -1
         if (ratio <= 0.1_wp) call lagrange_at(y, xopt, xnew, lagv, info)
         knew = 0; worst = -one
         do k = 1, m
            if (k == kopt) cycle
            dist = norm2v(y(:, k) - xopt)
            t = (max(dist, rho) / max(delta, rho))**4
            if (info == 0) t = t * abs(lagv(k))
            if (t > worst) then
               worst = t; knew = k
            end if
         end do
         if (knew == 0) knew = merge(2, 1, kopt == 1)
         y(:, knew) = xnew; fy(knew) = fnew

         if (fnew < fopt) then
            fopt = fnew; xopt = xnew; kopt = knew
         end if

         if (abs(ared) <= o%tol_f * (abs(fopt) + one) .and. rho <= rhoend) then
            res%status = OPT_CONV_F; exit
         end if
      end do

      res%x = ev%xbest; res%f = ev%fbest
      res%niter = iter
      if (allocated(res%g)) deallocate (res%g)
      allocate (res%g(n)); res%g = zero
   end subroutine solve_dfo_tr

   !> Quadratic model around xopt by minimum-Frobenius-norm interpolation.
   !> Solves the KKT system  [A  e  Y^T; e^T 0 0; Y 0 0] [lam; c; g] = [f; 0; 0]
   !> with A_kl = (y_k.y_l)^2/2, from which H = sum_k lam_k y_k y_k^T.
   !> Exposed for the model-accuracy test in test/; not part of the solver API.
   subroutine dfo_probe_model(y, fy, xc, g, h, info)
      real(wp), intent(in)  :: y(:, :), fy(:), xc(:)
      real(wp), intent(out) :: g(:), h(:, :)
      integer, intent(out)  :: info
      call build_model(y, fy, xc, g, h, info)
   end subroutine dfo_probe_model

   subroutine build_model(y, fy, xc, g, h, info)
      real(wp), intent(in)  :: y(:, :), fy(:), xc(:)
      real(wp), intent(out) :: g(:), h(:, :)
      integer, intent(out)  :: info
      real(wp), allocatable :: w(:, :), rhs(:), sol(:), z(:, :)
      real(wp) :: sc, fsc, fmid
      integer :: n, m, k, l, nt, i, j
      n = size(y, 1); m = size(y, 2); nt = m + n + 1
      allocate (w(nt, nt), rhs(nt), sol(nt), z(n, m))
      do k = 1, m
         z(:, k) = y(:, k) - xc                   ! shift to the model centre
      end do

      ! --- scale the displacements to unit radius -------------------------
      ! The quadratic block of the KKT matrix carries (z.z)^2, i.e. it scales
      ! as rho^4, while the constraint block is exactly 1.  At rho = 1e-4 the
      ! entries already span sixteen orders of magnitude and the solve
      ! returns a meaningless model, so the trust region stops working
      ! precisely when it starts to converge.  Working in scaled coordinates
      ! z/sc keeps the matrix at a fixed conditioning for every rho; the
      ! gradient and Hessian are unscaled again at the end.
      sc = zero
      do k = 1, m
         sc = max(sc, norm2v(z(:, k)))
      end do
      if (sc <= zero) then
         info = -1; return
      end if
      z = z / sc

      ! The same argument applies to f: only differences matter, so centre
      ! and scale them too.
      fmid = fy(1)
      fsc = maxval(fy) - minval(fy)
      if (fsc <= zero) fsc = one

      w = zero
      do k = 1, m
         do l = 1, m
            w(k, l) = half * dot_product(z(:, k), z(:, l))**2
         end do
         w(k, m + 1) = one
         w(m + 1, k) = one
         w(k, m + 2:nt) = z(:, k)
         w(m + 2:nt, k) = z(:, k)
      end do
      rhs = zero
      rhs(1:m) = (fy - fmid) / fsc
      call solve_dense(w, rhs, sol, info)
      if (info /= 0) return
      g = sol(m + 2:nt) * (fsc / sc)
      h = zero
      do k = 1, m
         call outer_update(h, z(:, k), sol(k))
      end do
      h = h * (fsc / (sc * sc))
   end subroutine build_model

   !> Values at xnew of the m Lagrange polynomials of the interpolation set.
   !> L_k is the model that interpolates e_k, so |L_k(xnew)| measures how
   !> strongly point k can be replaced by xnew without degrading the set.
   !> Coefficients of the m Lagrange polynomials of the set.  These depend on
   !> the interpolation points only, so the factorisation is done once and the
   !> polynomials are then evaluated wherever needed at O(mn) each.  Rebuilding
   !> and refactorising the KKT system per candidate point -- as a first
   !> version did -- made the geometry search dominate the run time.
   subroutine lagrange_coeffs(y, xc, sol, z, sc, info)
      real(wp), intent(in)  :: y(:, :), xc(:)
      real(wp), intent(out) :: sol(:, :), z(:, :), sc
      integer, intent(out)  :: info
      real(wp), allocatable :: w(:, :), rhs(:, :)
      integer :: n, m, k, l, nt
      n = size(y, 1); m = size(y, 2); nt = m + n + 1
      allocate (w(nt, nt), rhs(nt, m))
      do k = 1, m
         z(:, k) = y(:, k) - xc
      end do
      sc = zero
      do k = 1, m
         sc = max(sc, norm2v(z(:, k)))
      end do
      if (sc <= zero) then
         info = -1; return
      end if
      z = z / sc
      w = zero
      do k = 1, m
         do l = 1, m
            w(k, l) = half * dot_product(z(:, k), z(:, l))**2
         end do
         w(k, m + 1) = one
         w(m + 1, k) = one
         w(k, m + 2:nt) = z(:, k)
         w(m + 2:nt, k) = z(:, k)
      end do
      rhs = zero
      do k = 1, m
         rhs(k, k) = one
      end do
      call solve_dense_multi(w, rhs, sol, info)
   end subroutine lagrange_coeffs

   !> Value of the k-th Lagrange polynomial at a point, given the coefficients.
   pure real(wp) function lagrange_value(sol, z, sc, xc, xp, k) result(q)
      real(wp), intent(in) :: sol(:, :), z(:, :), sc, xc(:), xp(:)
      integer, intent(in)  :: k
      real(wp) :: zn(size(xc))
      integer  :: l, m, nt
      m = size(z, 2); nt = size(sol, 1)
      zn = (xp - xc) / sc
      q = sol(m + 1, k) + dot_product(sol(m + 2:nt, k), zn)
      do l = 1, m
         q = q + half * sol(l, k) * dot_product(z(:, l), zn)**2
      end do
   end function lagrange_value

   subroutine lagrange_at(y, xc, xnew, lagv, info)
      real(wp), intent(in)  :: y(:, :), xc(:), xnew(:)
      real(wp), intent(out) :: lagv(:)
      integer, intent(out)  :: info
      real(wp), allocatable :: w(:, :), rhs(:, :), sol(:, :), z(:, :), zn(:)
      real(wp) :: sc, q
      integer  :: n, m, k, l, nt
      n = size(y, 1); m = size(y, 2); nt = m + n + 1
      allocate (w(nt, nt), rhs(nt, m), sol(nt, m), z(n, m), zn(n))
      do k = 1, m
         z(:, k) = y(:, k) - xc
      end do
      sc = zero
      do k = 1, m
         sc = max(sc, norm2v(z(:, k)))
      end do
      if (sc <= zero) then
         info = -1; return
      end if
      z = z / sc
      zn = (xnew - xc) / sc
      w = zero
      do k = 1, m
         do l = 1, m
            w(k, l) = half * dot_product(z(:, k), z(:, l))**2
         end do
         w(k, m + 1) = one
         w(m + 1, k) = one
         w(k, m + 2:nt) = z(:, k)
         w(m + 2:nt, k) = z(:, k)
      end do
      rhs = zero
      do k = 1, m
         rhs(k, k) = one                          ! L_k interpolates e_k
      end do
      call solve_dense_multi(w, rhs, sol, info)
      if (info /= 0) return
      do k = 1, m
         q = sol(m + 1, k) + dot_product(sol(m + 2:nt, k), zn)
         do l = 1, m
            q = q + half * sol(l, k) * dot_product(z(:, l), zn)**2
         end do
         lagv(k) = q
      end do
   end subroutine lagrange_at

   !> Truncated-CG (Steihaug) step on the model, projected onto the bounds.
   subroutine tr_step(g, h, delta, xc, lb, ub, d, pred)
      real(wp), intent(in)  :: g(:), h(:, :), delta, xc(:), lb(:), ub(:)
      real(wp), intent(out) :: d(:), pred
      real(wp), allocatable :: r(:), pv(:), hp(:), dn(:)
      real(wp) :: rr, rr0, alpha, beta, php, dd, tau, a, b, c
      integer  :: n, it
      n = size(g)
      allocate (r(n), pv(n), hp(n), dn(n))
      d = zero; r = -g; pv = r; rr = dot_product(r, r); rr0 = rr
      pred = zero
      if (rr0 <= zero) return
      do it = 1, 2 * n + 10
         hp = matmul(h, pv)
         php = dot_product(pv, hp)
         if (php <= zero) then                     ! negative curvature: to the edge
            call to_boundary(d, pv, delta, tau)
            d = d + tau * pv
            exit
         end if
         alpha = rr / php
         dn = d + alpha * pv
         if (norm2v(dn) >= delta) then
            call to_boundary(d, pv, delta, tau)
            d = d + tau * pv
            exit
         end if
         d = dn
         r = r - alpha * hp
         beta = dot_product(r, r) / rr
         rr = dot_product(r, r)
         if (rr <= 1.0e-12_wp * rr0) exit
         pv = r + beta * pv
      end do
      ! project onto the box, then report the model decrease actually offered
      dn = min(max(xc + d, lb), ub) - xc
      d = dn
      pred = -(dot_product(g, d) + half * dot_product(d, matmul(h, d)))
   end subroutine tr_step

   pure subroutine to_boundary(d, pv, delta, tau)
      real(wp), intent(in)  :: d(:), pv(:), delta
      real(wp), intent(out) :: tau
      real(wp) :: a, b, c, disc
      a = dot_product(pv, pv); b = two * dot_product(d, pv)
      c = dot_product(d, d) - delta**2
      disc = max(b * b - 4.0_wp * a * c, zero)
      tau = (-b + sqrt(disc)) / (two * max(a, opt_tiny))
   end subroutine to_boundary

   !> Rebuild a degenerate or over-contracted interpolation set at radius rho.
   subroutine refresh_set(y, fy, xc, rho, lb, ub, ev, kopt, fopt)
      real(wp), intent(inout) :: y(:, :), fy(:)
      real(wp), intent(in)    :: xc(:), rho, lb(:), ub(:)
      type(evaluator_t), intent(inout) :: ev
      integer, intent(inout)  :: kopt
      real(wp), intent(inout) :: fopt
      integer :: n, i, k
      n = size(y, 1)
      y(:, 1) = xc
      fy(1) = ev%f(y(:, 1))
      do i = 1, n
         y(:, 2 * i) = xc;     y(i, 2 * i)     = min(xc(i) + rho, ub(i))
         y(:, 2 * i + 1) = xc; y(i, 2 * i + 1) = max(xc(i) - rho, lb(i))
         if (y(i, 2 * i) == xc(i))     y(i, 2 * i)     = min(xc(i) + half * rho, ub(i))
         if (y(i, 2 * i + 1) == xc(i)) y(i, 2 * i + 1) = max(xc(i) - half * rho, lb(i))
         fy(2 * i) = ev%f(y(:, 2 * i))
         if (ev%stop_flag) return
         fy(2 * i + 1) = ev%f(y(:, 2 * i + 1))
         if (ev%stop_flag) return
      end do
      kopt = minloc(fy, dim=1)
      fopt = fy(kopt)
   end subroutine refresh_set

   !> Dense symmetric-indefinite solve by Gaussian elimination with partial
   !> pivoting (the KKT matrix above is symmetric but not definite).
   !> Gaussian elimination with partial pivoting and several right-hand sides;
   !> one factorisation serves all m Lagrange polynomials.
   subroutine solve_dense_multi(a, b, x, info)
      real(wp), intent(in)  :: a(:, :), b(:, :)
      real(wp), intent(out) :: x(:, :)
      integer, intent(out)  :: info
      real(wp), allocatable :: mm(:, :)
      real(wp) :: piv, t
      integer  :: n, nr, i, j, k, ip
      n = size(a, 1); nr = size(b, 2); info = 0
      allocate (mm(n, n + nr))
      mm(:, 1:n) = a; mm(:, n + 1:n + nr) = b
      do k = 1, n
         ip = k; piv = abs(mm(k, k))
         do i = k + 1, n
            if (abs(mm(i, k)) > piv) then
               piv = abs(mm(i, k)); ip = i
            end if
         end do
         if (piv <= 1.0e-14_wp * maxval(abs(a))) then
            info = k; return
         end if
         if (ip /= k) then
            do j = k, n + nr
               t = mm(k, j); mm(k, j) = mm(ip, j); mm(ip, j) = t
            end do
         end if
         do i = k + 1, n
            t = mm(i, k) / mm(k, k)
            if (t /= zero) mm(i, k:n + nr) = mm(i, k:n + nr) - t * mm(k, k:n + nr)
         end do
      end do
      do j = 1, nr
         do i = n, 1, -1
            x(i, j) = (mm(i, n + j) - dot_product(mm(i, i + 1:n), x(i + 1:n, j))) / mm(i, i)
         end do
      end do
   end subroutine solve_dense_multi

   subroutine solve_dense(a, b, x, info)
      real(wp), intent(in)  :: a(:, :), b(:)
      real(wp), intent(out) :: x(:)
      integer, intent(out)  :: info
      real(wp), allocatable :: m(:, :)
      real(wp) :: piv, t
      integer  :: n, i, j, k, ip
      n = size(b); info = 0
      allocate (m(n, n + 1))
      m(:, 1:n) = a; m(:, n + 1) = b
      do k = 1, n
         ip = k; piv = abs(m(k, k))
         do i = k + 1, n
            if (abs(m(i, k)) > piv) then
               piv = abs(m(i, k)); ip = i
            end if
         end do
         if (piv <= 1.0e-14_wp * maxval(abs(a))) then
            info = k; return
         end if
         if (ip /= k) then
            do j = k, n + 1
               t = m(k, j); m(k, j) = m(ip, j); m(ip, j) = t
            end do
         end if
         do i = k + 1, n
            t = m(i, k) / m(k, k)
            if (t /= zero) m(i, k:n + 1) = m(i, k:n + 1) - t * m(k, k:n + 1)
         end do
      end do
      do i = n, 1, -1
         x(i) = (m(i, n + 1) - dot_product(m(i, i + 1:n), x(i + 1:n))) / m(i, i)
      end do
   end subroutine solve_dense

end module fitpar_local_dfotr
