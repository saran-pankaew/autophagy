!> FOCTOPUS -- adaptive zoom random search, in two variants.
!>
!> The CLASSIC path (foc_classic = .true.) is a faithful port of the user's
!> original algorithm: sample a batch of nsamp uniform points from a box
!> centred on the incumbent with half-width msigma*sigma, where
!>
!>       sigma(zoom) = sigma0 / nsamp**(zoom/n)
!>
!> A batch that improves the incumbent moves there and WIDENS the box
!> (zoom - zout); one that does not NARROWS it (zoom + zin).  The run ends
!> when zoom exceeds zmax; with budget remaining it restarts from a fresh
!> point (the incumbent is never lost).  Five defects of the original
!> standalone module are absent from this port -- see compat/foctopus.f90
!> for the list -- and the batch minimum is found with minloc rather than a
!> full sort, since only the minimum was ever used.
!>
!> The ENHANCED path (default) keeps the batch-sample / move-or-contract
!> soul of the algorithm and repairs its one structural waste: the original
!> extracted a single bit per batch (improved or not) plus one argmin, and
!> discarded every other evaluation.  Four changes, each standard and each
!> individually measurable:
!>
!>   1. Weighted recombination.  The new centre is a log-rank-weighted mean
!>      of the best mu = lambda/2 points, not the single argmin.
!>   2. Cumulative step-size control.  The integer zoom counter becomes a
!>      continuous scale s driven by an evolution path: consecutive moves in
!>      the same direction lengthen the path and grow s, moves that cancel
!>      shrink it.  This is the same information the zoom counter used --
!>      did the batch help -- extracted with its sign and magnitude intact.
!>   3. Full covariance learning.  The sampling box becomes an ellipsoid
!>      whose shape is learned by a rank-mu update, so the search aligns
!>      itself with curved valleys.  (A cheaper separable variant was tried
!>      and failed completely on non-axis-aligned valleys; the full matrix
!>      is the one that works.)
!>   4. Mirrored sampling with IPOP restarts.  Points are drawn in +/-
!>      pairs, halving sampling noise in the mean; each restart doubles the
!>      batch, trading depth for breadth exactly when depth has failed.
!>
!> The enhanced path is, deliberately, a Cholesky-based CMA-ES with mirrored
!> sampling grown out of foctopus' own control structure; foc_zmax keeps its
!> classic meaning as the terminal resolution, translated to a floor on s.
module fitpar_global_foctopus
   use fitpar_kinds
   use fitpar_types
   use fitpar_eval
   use fitpar_linalg
   use fitpar_rng
   use fitpar_globutil
   implicit none
   private
   public :: solve_foctopus

contains

   subroutine solve_foctopus(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      if (o%foc_classic) then
         call foctopus_classic(ev, p, o, x, res)
      else
         call foctopus_enhanced(ev, p, o, x, res)
      end if
      res%x = ev%xbest
      res%f = ev%fbest
      ! a time limit, a stop from the objective or a reached target ends the
      ! search from outside; say so rather than how the last run ended (2.8.0)
      if (ev%stop_flag) then
         if (ev%stop_code == OPT_MAX_TIME .or. ev%stop_code == OPT_USER_STOP .or. &
             ev%stop_code == OPT_CONV_TARGET) res%status = ev%stop_code
      end if
   end subroutine solve_foctopus

   ! ==========================================================================
   !  CLASSIC
   ! ==========================================================================
   subroutine foctopus_classic(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      type(rng_t) :: rng
      real(wp), allocatable :: lb(:), ub(:), sig0(:), sigx(:), plo(:), phi(:)
      real(wp), allocatable :: pc(:), u(:), fs(:), xs(:, :)
      integer  :: n, ns, i, j, zmin, zmax, kb, nb, nrun, kfail, nhist, nfhist
      real(wp) :: zoom, zin, zout
      real(wp) :: fp, ms, mid, gold, gnew, dz, used, dsum, ratio
      real(wp) :: ghist, gnow, rate, gproj, gtarget

      n = p%n
      call get_box(p, x, lb, ub)
      call rng%seed(o%seed)

      ns = o%foc_nsamp
      if (ns <= 0) ns = max(2, min(500, 10 * n))
      zin  = max(1.0e-3_wp, o%foc_zin)
      zout = max(1.0e-3_wp, o%foc_zout)
      zmin = o%foc_zmin
      zmax = o%foc_zmax
      ms   = o%foc_msigma
      if (ms <= zero) ms = three

      allocate (sig0(n), sigx(n), plo(n), phi(n), pc(n), u(n), fs(ns), xs(n, ns))
      res%status = OPT_MAX_FEVAL
      res%niter = 0
      nrun = 0

      restart: do
         nrun = nrun + 1
         if (nrun == 1) then
            pc = x
         else
            call rng%uniform_v(u)              ! fresh start; incumbent is kept
            pc = lb + u * (ub - lb)            ! by the evaluator, so restarts
         end if                                ! can only improve the answer
         call p%clip(pc)
         zoom = real(o%foc_zoom, wp)
         do j = 1, n
            sig0(j) = max(ub(j) - pc(j), pc(j) - lb(j)) / ms
            if (sig0(j) <= zero) sig0(j) = max(one, abs(pc(j)))
         end do
         if (allocated(o%foc_sigma0)) then
            if (size(o%foc_sigma0) >= n) then
               where (o%foc_sigma0(1:n) > zero) sig0 = o%foc_sigma0(1:n)
            end if
         end if
         fp = ev%f(pc)
         kfail = 0
         ghist = -one; nhist = 0; nfhist = 0
         if (ev%stop_flag) exit restart

         do while (zoom <= real(zmax, wp))
            res%niter = res%niter + 1
            sigx = sig0 * real(ns, wp)**(-zoom / real(n, wp))
            do j = 1, n
               plo(j) = max(pc(j) - ms * sigx(j), lb(j))
               phi(j) = min(pc(j) + ms * sigx(j), ub(j))   ! MIN: both edges zoom
               if (phi(j) < plo(j)) then
                  mid = half * (plo(j) + phi(j))
                  plo(j) = mid; phi(j) = mid
               end if
            end do

            ! never start a sample we cannot afford: no slot of fs stays unset
            nb = min(ns, max(1, ev%budget_left()))
            do i = 1, nb
               call rng%uniform_v(u)
               xs(:, i) = plo * (one - u) + phi * u
            end do
            call ev%fbatch(xs(:, 1:nb), fs(1:nb))

            kb = minloc(fs(1:nb), dim=1)

            ! --- mode 5: set the scale from the measured distance ------------
            if (o%foc_adaptive == 5) then
               dsum = zero
               do i = 1, nb
                  dsum = dsum + abs(fs(i) - fp)
               end do
               dsum = dsum / real(max(nb, 1), wp)          ! D: typical change at this scale
               gold = fp - o%foc_fstar
               if (dsum > zero .and. gold > zero) then
                  ratio = o%foc_scale_c * sqrt(gold / dsum)   ! wanted sigma / current sigma
                  ratio = max(one / o%foc_scale_clamp, min(o%foc_scale_clamp, ratio))
                  zoom = max(real(zmin, wp), zoom - real(n, wp) * log(ratio) / log(real(ns, wp)))
               end if
               if (fs(kb) < fp) then
                  fp = fs(kb); pc = xs(:, kb)
               end if
               if (ev%stop_flag) exit restart
               if (res%niter >= o%max_iter) then
                  res%status = OPT_MAX_ITER; exit restart
               end if
               cycle
            end if

            if (fs(kb) < fp) then
               if (o%foc_adaptive >= 3) then
                  ! Widen in proportion to how much was gained.  A batch that
                  ! closed a large part of the remaining gap says the current
                  ! scale is productive and may even be too small, so step back
                  ! further; a marginal gain says we are near the resolution of
                  ! this scale, so step back barely at all.  This is the
                  ! classic success->widen rule with the magnitude measured
                  ! rather than fixed.
                  gold = fp - o%foc_fstar
                  gnew = fs(kb) - o%foc_fstar
                  if (gold > zero .and. gnew > zero .and. gnew < gold) then
                     dz = (real(n, wp) / (o%foc_gap_power * log(real(ns, wp)))) &
                          * log(gold / gnew)
                     dz = max(zero, min(o%foc_dz_max, dz))
                     if (o%foc_damp > zero) then
                        used = one - real(ev%budget_left(), wp) / real(max(o%max_feval, 1), wp)
                        dz = dz * max(zero, one - used)**o%foc_damp
                     end if
                     zoom = max(real(zmin, wp), zoom - zout * dz)
                  else
                     zoom = max(real(zmin, wp), zoom - zout)
                  end if
               else if (o%foc_adaptive > 0) then
                  ! The gap ratio measures the contraction of the distance to
                  ! the optimum; match the sampling scale to it instead of
                  ! stepping by a tuned constant.
                  gold = fp - o%foc_fstar
                  gnew = fs(kb) - o%foc_fstar
                  if (gold > zero .and. gnew > zero) then
                     dz = -(real(n, wp) / (o%foc_gap_power * log(real(ns, wp)))) &
                          * log(gnew / gold)
                     dz = max(-o%foc_dz_max, min(o%foc_dz_max, dz))
                     zoom = max(real(zmin, wp), zoom + dz)
                  else
                     zoom = max(real(zmin, wp), zoom - zout)
                  end if
               else
                  zoom = max(real(zmin, wp), zoom - zout)
               end if
               fp = fs(kb)
               pc = xs(:, kb)
               kfail = 0
            else
               kfail = kfail + 1
               ! No improvement carries no distance information.  Mode 2 widens
               ! here instead of narrowing: with mode 1 both branches contract,
               ! so the scale collapses monotonically and a run that has not
               ! yet found the basin cannot get back out.
               if (o%foc_adaptive == 2) then
                  zoom = max(real(zmin, wp), zoom - zout)
               else if (o%foc_adaptive == 4) then
                  ! Stagnation is evidence about the scale, and the evidence
                  ! accumulates.  One failed batch can be sampling luck; a run
                  ! of them says the scale is too large, so the narrowing step
                  ! grows with the number of consecutive failures.
                  zoom = zoom + zin * min(o%foc_dz_max, real(kfail, wp))
               else
                  zoom = zoom + zin
               end if
            end if
            if (ev%stop_flag) exit restart
            if (res%niter >= o%max_iter) then
               res%status = OPT_MAX_ITER
               exit restart
            end if

            ! --- give up on a run the gap says cannot finish -----------------
            if (o%foc_gap_stop .and. o%max_feval > 0) then
               nhist = nhist + 1
               if (nhist > o%foc_gap_window) then
                  gnow = max(fp - o%foc_fstar, opt_tiny)
                  if (ghist > zero .and. gnow < ghist .and. ev%budget_left() > 0) then
                     ! log-linear decay rate per evaluation over the window
                     rate = log(gnow / ghist) / real(max(ev%nfev - nfhist, 1), wp)
                     gproj = gnow * exp(rate * real(ev%budget_left(), wp))
                     gtarget = max(o%target_f - o%foc_fstar, opt_tiny)
                     if (log10(gproj / gtarget) > o%foc_gap_slack) exit    ! restart
                  else if (ghist > zero .and. gnow >= ghist) then
                     exit                                   ! no progress at all
                  end if
                  ghist = gnow; nfhist = ev%nfev; nhist = 0
               else if (nhist == 1) then
                  ghist = max(fp - o%foc_fstar, opt_tiny); nfhist = ev%nfev
               end if
            end if
         end do

         res%status = OPT_CONV_X                       ! zoomed out of resolution
         if (o%restarts > 0 .and. nrun >= o%restarts) exit restart
         if (ev%budget_left() <= ns) exit restart
      end do restart
   end subroutine foctopus_classic

   ! ==========================================================================
   !  ENHANCED
   ! ==========================================================================
   subroutine foctopus_enhanced(ev, p, o, x, res)
      type(evaluator_t), intent(inout) :: ev
      type(opt_problem), intent(in)    :: p
      type(opt_options), intent(in)    :: o
      real(wp), intent(inout)          :: x(:)
      type(opt_result), intent(inout)  :: res

      type(rng_t) :: rng
      real(wp), allocatable :: lb(:), ub(:), sig0(:), m(:), mold(:), ps(:)
      real(wp), allocatable :: c(:, :), l(:, :), z(:), y(:), w(:), delta(:)
      real(wp), allocatable :: xs(:, :), ys(:, :), fs(:), wts(:)
      integer, allocatable  :: idx(:)
      integer  :: n, lam, lam0, mu, i, j, k, info, nrun, gen, stall, info2, nsel
      real(wp) :: cc, c1, hsig
      real(wp), allocatable :: pc(:), cinv(:, :)
      integer, allocatable  :: sel(:)
      logical, allocatable  :: used(:)
      real(wp) :: ms, s, mueff, cs, ds, cmu, chin, frun, arg, dmax, dmin
      integer  :: nprobe, noisy, quiet, nev
      real(wp) :: d2(3), sig_n, spread, pat, fpq(2)
      real(wp), allocatable :: xp2(:, :)
      ! niching state (used only when o%foc_niche)
      real(wp), allocatable :: ax(:, :), af(:), qx(:, :), qs(:, :), sx(:, :), rox(:, :), rof(:)
      real(wp), allocatable :: sig_niche(:), run_bx(:), tx(:)
      integer  :: na, ahead, nq, nseen, nro, n_niche, n_unprod, ib
      logical  :: niche_run, niche_active
      ! NBIPOP and surrogate state (used only when the option is on)
      real(wp) :: bip_large_fe, bip_small_fe, bip_run_best, sig_scale, bip_u
      integer  :: lam_large, run_fe0, nsur, shead, sur_cap
      logical  :: small_run, best_small, use_probe
      real(wp), allocatable :: sx_(:, :), sf_(:)
      real(wp) :: run_bf

      n = p%n
      call get_box(p, x, lb, ub)
      call rng%seed(o%seed)

      ms = o%foc_msigma
      if (ms <= zero) ms = three
      lam0 = o%foc_nsamp
      if (lam0 <= 0) lam0 = 4 + int(three * log(real(max(n, 2), wp)))
      lam0 = max(6, lam0 + mod(lam0, 2))            ! even, for mirrored pairs
      chin = sqrt(real(n, wp)) * (one - one / (4.0_wp * n) + one / (21.0_wp * n * n))

      allocate (sig0(n), m(n), mold(n), ps(n), delta(n), z(n), y(n), w(n))
      allocate (c(n, n), l(n, n), pc(n), cinv(n, n))
      res%status = OPT_MAX_FEVAL
      res%niter = 0
      lam = lam0
      nrun = 0
      niche_run = .false.
      if (o%foc_niche) then
         allocate (ax(n, o%foc_niche_archive), af(o%foc_niche_archive), qx(n, max(1, o%foc_niche_max)), &
                   qs(n, max(1, o%foc_niche_max)), sx(n, 200), rox(n, 500), rof(500), sig_niche(n), &
                   run_bx(n), tx(n))
         na = 0; ahead = 0; nq = 0; nseen = 0; nro = 0; n_niche = 0; n_unprod = 0
         niche_active = .true.
      end if

      use_probe = o%foc_noise_probe .and. .not. o%foc_surrogate
      bip_large_fe = zero; bip_small_fe = zero; lam_large = lam0; best_small = .false.
      run_fe0 = 0; sig_scale = one; small_run = .false.; nsur = 0; shead = 0
      if (o%foc_surrogate) then
         sur_cap = max(3000, 2 * (1 + 2 * n + n * (n - 1) / 2))
         allocate (sx_(n, sur_cap), sf_(sur_cap))
      end if
      restart: do
         nrun = nrun + 1
         niche_run = .false.; small_run = .false.
         if (nrun == 1) then
            m = x
         else if (o%foc_niche .and. niche_active .and. nq > 0) then
            m = qx(:, 1); sig_niche = qs(:, 1)          ! local run in a confirmed valley
            qx(:, 1:nq - 1) = qx(:, 2:nq); qs(:, 1:nq - 1) = qs(:, 2:nq); nq = nq - 1
            niche_run = .true.; n_niche = n_niche + 1
         else if (o%foc_nbipop) then
            if (bip_small_fe < merge(2.0_wp, 0.5_wp, best_small) * bip_large_fe) then
               bip_u = rng%uniform()                  ! small-population regime
               lam = int(lam0 * (half * real(lam_large, wp) / real(lam0, wp))**(bip_u * bip_u))
               lam = max(lam0, lam + mod(lam, 2))
               sig_scale = ten**(-2.0_wp * rng%uniform()); small_run = .true.
            else                                      ! large-population regime (IPOP)
               lam_large = min(2 * lam_large, 64 * lam0); lam = lam_large
            end if
            call rng%uniform_v(z)
            m = lb + z * (ub - lb)
         else
            lam = min(2 * lam, 64 * lam0)            ! IPOP: double the batch
            call rng%uniform_v(z)
            m = lb + z * (ub - lb)
         end if
         call p%clip(m)
         mu = lam / 2
         if (allocated(xs)) deallocate (xs, ys, fs, idx, wts)
         allocate (xs(n, lam), ys(n, lam), fs(lam), idx(lam), wts(mu))
         if (allocated(sel)) deallocate (sel, used)
         allocate (sel(lam), used((lam + 1) / 2))

         do i = 1, mu                                 ! log-rank weights
            wts(i) = log(real(mu, wp) + half) - log(real(i, wp))
         end do
         wts = wts / sum(wts)
         mueff = one / sum(wts**2)
         cs  = (mueff + two) / (real(n, wp) + mueff + 5.0_wp)
         ds  = one + cs + two * max(zero, sqrt((mueff - one) / real(n + 1, wp)) - one)
         cc  = (4.0_wp + mueff / real(n, wp)) / (real(n, wp) + 4.0_wp + two * mueff / real(n, wp))
         c1  = two / ((real(n, wp) + 1.3_wp)**2 + mueff)
         if (.not. o%foc_rank_one) c1 = zero
         cmu = min(one - c1 - 1.0e-8_wp, &
                   two * (mueff - two + one / mueff) / (real(n + 2, wp)**2 + mueff))
         pc = zero

         do j = 1, n
            sig0(j) = max(ub(j) - m(j), m(j) - lb(j)) / ms
            if (sig0(j) <= zero) sig0(j) = max(one, abs(m(j)))
         end do
         if (allocated(o%foc_sigma0)) then
            if (size(o%foc_sigma0) >= n) then
               where (o%foc_sigma0(1:n) > zero) sig0 = o%foc_sigma0(1:n)
            end if
         end if
         if (niche_run) sig0 = min(sig0, sig_niche)
         if (small_run) sig0 = sig0 * sig_scale
         if (o%foc_nbipop .and. nrun > 1) run_fe0 = ev%nfev
         bip_run_best = opt_huge; nsur = 0; shead = 0
         if (o%foc_niche) then
            run_bf = opt_huge; run_bx = m
         end if
         c = zero
         do j = 1, n
            c(j, j) = sig0(j)**2
         end do
         s = one
         ps = zero
         frun = opt_huge
         stall = 0
         gen = 0
         nprobe = 0; noisy = 0; quiet = 0; d2 = 0.0_wp
         if (allocated(xp2)) deallocate (xp2)
         allocate (xp2(n, 2))

         run: do
            gen = gen + 1
            res%niter = res%niter + 1

            ! --- factor the shape; add jitter if round-off spoilt it ---------
            l = c
            call cholesky_factor(l, info)
            if (info /= 0) then
               do k = 1, 3
                  do j = 1, n
                     c(j, j) = c(j, j) * (one + 1.0e-8_wp * ten**k) + opt_eps
                  end do
                  l = c
                  call cholesky_factor(l, info)
                  if (info == 0) exit
               end do
               if (info /= 0) exit run                ! irreparable: restart
            end if

            ! --- mirrored batch ---------------------------------------------
            do k = 1, mu
               call rng%normal_v(z)
               do i = 1, n                            ! y = L z, lower part only
                  y(i) = dot_product(l(i, 1:i), z(1:i))
               end do
               xs(:, 2 * k - 1) = m + s * y
               xs(:, 2 * k)     = m - s * y
            end do
            do k = 1, lam
               call p%clip(xs(:, k))
               ys(:, k) = (xs(:, k) - m) / s          ! as evaluated, post-clip
            end do
            if (o%foc_surrogate .and. nsur >= n + 2) then
               call sur_eval()
               if (ev%stop_flag) exit restart
            else
               call ev%fbatch(xs, fs)
               if (ev%stop_flag) exit restart
               if (o%foc_surrogate) then
                  do k = 1, lam
                     call sur_push(xs(:, k), fs(k))
                  end do
               end if
            end if
            if (o%foc_nbipop) bip_run_best = min(bip_run_best, minval(fs))
            if (o%foc_niche) then                     ! archive: generation best
               ib = minloc(fs, 1)
               ahead = mod(ahead, o%foc_niche_archive) + 1
               ax(:, ahead) = xs(:, ib); af(ahead) = fs(ib); na = min(na + 1, o%foc_niche_archive)
               if (fs(ib) < run_bf) then
                  run_bf = fs(ib); run_bx = xs(:, ib)
               end if
            end if

            ! --- adaptive restart patience: the noise probe --------------------
            ! A pair m +/- 0.01 s L z, with the batch's own m, s and L.  In a
            ! mirrored difference the curvature cancels, so on a smooth surface
            ! its difference is ~1/100 of the batch's pair differences; when
            ! noise or ruggedness below the step drives the ranking the two are
            ! comparable.  Two alarms in a row shorten the stall patience to
            ! foc_noise_patience; two quiet probes restore it.  The alarm never
            ! ends a run by itself.
            nev = o%foc_noise_every
            if (nev <= 0) nev = max(5, nint(real(n, wp) / 10.0_wp))
            if (use_probe) then
               if (mod(gen, nev) == 0) then
                  call rng%normal_v(z)
                  do i = 1, n
                     y(i) = dot_product(l(i, 1:i), z(1:i))
                  end do
                  xp2(:, 1) = m + 0.01_wp * s * y
                  xp2(:, 2) = m - 0.01_wp * s * y
                  call p%clip(xp2(:, 1)); call p%clip(xp2(:, 2))
                  call ev%fbatch(xp2, fpq)
                  if (ev%stop_flag) exit restart
                  nprobe = nprobe + 1
                  d2(mod(nprobe - 1, 3) + 1) = 0.5_wp * (fpq(1) - fpq(2))**2
                  if (nprobe >= 3) then
                     sig_n = sqrt(sum(d2) / 3.0_wp)
                     spread = 0.0_wp
                     do k = 1, lam / 2
                        spread = spread + 0.5_wp * (fs(2*k - 1) - fs(2*k))**2
                     end do
                     spread = sqrt(spread / real(lam / 2, wp))
                     if (sig_n > o%foc_noise_ratio * spread) then
                        noisy = noisy + 1; quiet = 0
                     else
                        quiet = quiet + 1
                        if (quiet >= 2) noisy = 0
                     end if
                  end if
               end if
            end if

            ! --- weighted recombination over the best mu ---------------------
            call rank_index(fs, idx)
            ! With mirrored sampling the pair (2k-1, 2k) is x = m +/- s*y.  If
            ! both members enter the weighted mean their contributions cancel
            ! to first order, which throws away exactly the information the
            ! mirroring was meant to sharpen.  Keep the better of each pair.
            if (o%foc_mirrored_select) then
               used = .false.
               nsel = 0
               do i = 1, lam
                  k = (idx(i) + 1) / 2                ! pair index
                  if (used(k)) cycle
                  used(k) = .true.
                  nsel = nsel + 1
                  sel(nsel) = idx(i)
                  if (nsel == mu) exit
               end do
               do i = nsel + 1, mu                    ! pad if a pair was clipped
                  sel(i) = idx(i)
               end do
               idx(1:mu) = sel(1:mu)
            end if
            mold = m
            m = zero
            do i = 1, mu
               m = m + wts(i) * xs(:, idx(i))
            end do
            call p%clip(m)
            delta = (m - mold) / s

            ! --- cumulative step-size control (the zoom counter, grown up) ---
            ! The path is a SUM over generations, so every term must live in
            ! the same frame.  L^-1 delta and C^(-1/2) delta have equal norm
            ! for a fixed C, but they differ by an orthogonal factor that
            ! changes with C -- so accumulating L^-1 delta adds vectors
            ! expressed in a coordinate system that rotates underneath the
            ! sum.  The symmetric inverse square root is the one CSA is
            ! derived for.
            call sym_sqrt_inv(c, cinv, info2)
            if (info2 == 0) then
               w = matmul(cinv, delta)
            else
               call forward_solve(l, delta, w)        ! fall back on Cholesky
            end if
            ps = (one - cs) * ps + sqrt(cs * (two - cs) * mueff) * w
            arg = (cs / ds) * (norm2v(ps) / chin - one)
            s = s * exp(max(-one, min(one, arg)))

            ! --- evolution path for the rank-one term -------------------------
            ! A direction the search keeps moving in over several generations
            ! is information the rank-mu update cannot see, because it only
            ! ever looks at one batch.  hsig suppresses the update when the
            ! step-size path is unusually long, which is what stops the
            ! variance from exploding early in a run.
            hsig = zero
            if (norm2v(ps) / sqrt(one - (one - cs)**(2 * gen)) / chin &
                < 1.4_wp + two / real(n + 1, wp)) hsig = one
            pc = (one - cc) * pc + hsig * sqrt(cc * (two - cc) * mueff) * delta

            ! --- covariance: rank-one plus rank-mu ---------------------------
            c = (one - c1 - cmu + (one - hsig) * c1 * cc * (two - cc)) * c
            call outer_update(c, pc, c1)
            do i = 1, mu
               call outer_update(c, ys(:, idx(i)), cmu * wts(i))
            end do

            ! --- run termination ---------------------------------------------
            if (fs(idx(1)) < frun - max(abs(frun) * 1.0e-12_wp, o%foc_tol_fun) - opt_tiny) then
               frun = fs(idx(1))
               stall = 0
            else
               stall = stall + 1
            end if
            dmax = maxval([(c(j, j), j=1, n)])
            dmin = minval([(c(j, j), j=1, n)])
            if (s * sqrt(dmax) <= scale_floor(sig0, lam, n, o)) then
               res%status = OPT_CONV_X
               exit run
            end if
            if (dmax > 1.0e14_wp * max(dmin, opt_tiny)) exit run
            pat = 1.0_wp
            if (use_probe .and. noisy >= 2) pat = o%foc_noise_patience
            if (stall > nint(pat * (60.0_wp + 20.0_wp * n / real(lam, wp)))) then
               res%status = OPT_STAGNATED
               exit run
            end if
            if (res%niter >= o%max_iter) then
               res%status = OPT_MAX_ITER
               exit restart
            end if
         end do run

         if (o%foc_niche) then
            call niche_after_run()
            if (ev%stop_flag) exit restart
         end if
         if (o%foc_nbipop .and. .not. niche_run) then  ! charge the run to its regime
            if (small_run) then
               bip_small_fe = bip_small_fe + real(ev%nfev - run_fe0, wp)
            else
               bip_large_fe = bip_large_fe + real(ev%nfev - run_fe0, wp)
            end if
            if (bip_run_best <= ev%fbest) best_small = small_run
         end if
         if (o%restarts > 0 .and. nrun >= o%restarts) exit restart
         if (ev%budget_left() <= 3 * lam) exit restart
      end do restart
      if (o%foc_niche) call niche_collect()

   contains

      !> After a run: record its optimum; judge a niche run; propose new niches.
      subroutine niche_after_run()
         real(wp), allocatable :: aa(:, :), ff(:), zz(:, :), dnb(:), scl(:)
         integer,  allocatable :: ord(:)
         integer  :: i2, jj, kk, t, nn, ncand, ilo
         real(wp) :: thr, fhi, ft, dd, dmin2, pos
         logical  :: worse, far
         if (run_bf < opt_huge .and. nro < size(rof)) then
            nro = nro + 1; rox(:, nro) = run_bx; rof(nro) = run_bf
         end if
         if (niche_run) then
            if (run_bf > ev%fbest + max(1.0e-6_wp, 1.0e-6_wp * abs(ev%fbest))) then
               n_unprod = n_unprod + 1
               if (n_unprod >= o%foc_niche_giveup) then
                  niche_active = .false.; nq = 0
               end if
            end if
         end if
         if (.not. niche_active .or. niche_run .or. nq > 0 .or. na <= 5) return
         nn = na
         allocate (aa(n, nn), ff(nn), ord(nn), zz(n, nn), dnb(nn), scl(n))
         call sort_index(af(1:nn), ord)
         aa = ax(:, ord); ff = af(ord)
         scl = merge(ub - lb, one, ub > lb)
         do i2 = 1, nn
            zz(:, i2) = (aa(:, i2) - lb) / scl
         end do
         dnb = opt_huge
         do i2 = 2, nn                                 ! nearest better, in box units
            dmin2 = opt_huge
            do jj = 1, i2 - 1
               dd = sum((zz(:, jj) - zz(:, i2))**2)
               if (dd < dmin2) dmin2 = dd
            end do
            dnb(i2) = sqrt(dmin2)
         end do
         thr = o%foc_niche_phi * sum(dnb(2:nn)) / real(nn - 1, wp)
         pos = 0.9_wp * real(nn - 1, wp); ilo = int(pos)
         fhi = ff(ilo + 1) + (pos - ilo) * (ff(min(ilo + 2, nn)) - ff(ilo + 1))
         ncand = 0
         do i2 = 2, nn
            if (dnb(i2) <= thr) cycle
            if (ff(i2) - ff(1) > o%foc_niche_depth * max(fhi - ff(1), 1.0e-300_wp)) cycle
            far = .true.
            do kk = 1, nseen
               if (norm2(zz(:, i2) - (sx(:, kk) - lb) / scl) <= half * dnb(i2)) far = .false.
            end do
            if (.not. far) cycle
            ncand = ncand + 1
            if (ncand > 3 * o%foc_niche_max) exit
            if (nq >= o%foc_niche_max .or. ev%budget_left() <= 3 * lam) exit
            worse = .false.                            ! hill-valley test
            do t = 1, o%foc_niche_hv
               tx = min(max(aa(:, 1) + real(t, wp) / real(o%foc_niche_hv + 1, wp) * (aa(:, i2) - aa(:, 1)), lb), ub)
               ft = ev%f(tx)
               if (ev%stop_flag) return
               if (ft > max(ff(1), ff(i2))) then
                  worse = .true.; exit
               end if
            end do
            if (worse) then
               nq = nq + 1; qx(:, nq) = aa(:, i2); qs(:, nq) = max(dnb(i2) * scl / three, 1.0e-12_wp)
               if (nseen < size(sx, 2)) then
                  nseen = nseen + 1; sx(:, nseen) = aa(:, i2)
               end if
            end if
         end do
      end subroutine niche_after_run

      !> Distinct run optima, best first (normalised distance > 1e-3).
      subroutine niche_collect()
         integer, allocatable :: ord(:)
         real(wp), allocatable :: scl(:), keepx(:, :), keepf(:)
         integer :: i2, k2, nk
         logical :: new
         res%niche_runs = n_niche
         allocate (ord(max(1, nro)), scl(n), keepx(n, max(1, nro)), keepf(max(1, nro)))
         scl = merge(ub - lb, one, ub > lb)
         nk = 0
         if (nro > 0) call sort_index(rof(1:nro), ord(1:nro))
         do i2 = 1, nro
            new = .true.
            do k2 = 1, nk
               if (norm2((rox(:, ord(i2)) - keepx(:, k2)) / scl) <= 1.0e-3_wp) new = .false.
            end do
            if (new) then
               nk = nk + 1; keepx(:, nk) = rox(:, ord(i2)); keepf(nk) = rof(ord(i2))
            end if
         end do
         res%nopt = nk
         if (allocated(res%xopt)) deallocate (res%xopt, res%fopt)
         allocate (res%xopt(n, nk), res%fopt(nk))
         if (nk > 0) then
            res%xopt = keepx(:, 1:nk); res%fopt = keepf(1:nk)
         end if
      end subroutine niche_collect

      !> Stable index sort (insertion; called once per run on at most a few
      !> thousand values).
      pure subroutine sort_index(v, idx)
         real(wp), intent(in) :: v(:)
         integer, intent(out) :: idx(:)
         integer :: i2, j2, t2
         do i2 = 1, size(v)
            idx(i2) = i2
         end do
         do i2 = 2, size(v)
            t2 = idx(i2); j2 = i2 - 1
            do while (j2 >= 1)
               if (v(idx(j2)) <= v(t2)) exit
               idx(j2 + 1) = idx(j2); j2 = j2 - 1
            end do
            idx(j2 + 1) = t2
         end do
      end subroutine sort_index

      subroutine sur_push(xv, fv)
         real(wp), intent(in) :: xv(:), fv
         shead = mod(shead, sur_cap) + 1
         sx_(:, shead) = xv; sf_(shead) = fv; nsur = min(nsur + 1, sur_cap)
      end subroutine sur_push

      integer function sur_recent(i2)
         integer, intent(in) :: i2
         sur_recent = modulo(shead - i2, sur_cap) + 1
      end function sur_recent

      integer function sur_np(kind)
         integer, intent(in) :: kind
         sur_np = 1 + n
         if (kind >= 1) sur_np = sur_np + n
         if (kind >= 2) sur_np = sur_np + n * (n - 1) / 2
      end function sur_np

      subroutine sur_features(xv, kind, phi)
         real(wp), intent(in) :: xv(:)
         integer, intent(in) :: kind
         real(wp), intent(out) :: phi(:)
         real(wp) :: zz(n)
         integer :: i2, j2, q
         call forward_solve(l, (xv - m) / s, zz)       ! whitened by the current distribution
         phi(1) = one; phi(2:n + 1) = zz; q = n + 1
         if (kind >= 1) then
            phi(q + 1:q + n) = zz**2; q = q + n
         end if
         if (kind >= 2) then
            do i2 = 1, n
               do j2 = i2 + 1, n
                  q = q + 1; phi(q) = zz(i2) * zz(j2)
               end do
            end do
         end if
      end subroutine sur_features

      subroutine sur_fit(kind, coef)
         integer, intent(in) :: kind
         real(wp), intent(out) :: coef(:)
         real(wp), allocatable :: g(:, :), rhs(:), phi(:), yv(:)
         integer :: np, win, i2, j2, info2
         real(wp) :: tr
         np = sur_np(kind)
         win = min(nsur, max(int(1.5_wp * np), 2 * lam))
         allocate (g(np, np), rhs(np), phi(np), yv(np))
         g = zero; rhs = zero
         do i2 = 1, win
            j2 = sur_recent(i2)
            call sur_features(sx_(:, j2), kind, phi)
            do info2 = 1, np
               g(info2:, info2) = g(info2:, info2) + phi(info2:) * phi(info2)
            end do
            rhs = rhs + sf_(j2) * phi
         end do
         tr = zero
         do i2 = 1, np
            tr = tr + g(i2, i2)
         end do
         do i2 = 1, np
            g(i2, i2) = g(i2, i2) + 1.0e-10_wp * tr / np + tiny(one)
         end do
         call cholesky_factor(g, info2)
         if (info2 /= 0) then
            coef = zero; coef(1) = sum(sf_(1:nsur)) / nsur; return
         end if
         call forward_solve(g, rhs, yv)
         do i2 = np, 1, -1
            coef(i2) = (yv(i2) - dot_product(g(i2 + 1:np, i2), coef(i2 + 1:np))) / g(i2, i2)
         end do
      end subroutine sur_fit

      subroutine sur_eval()
         integer :: kind, np, kk, i2, k2, nev, nval, jr, cc, dd, j3, ordr(lam), idr(lam)
         real(wp), allocatable :: coef(:), phi(:), va(:), vb(:), rr(:)
         real(wp) :: pred(lam), tau, med, worst, t, ft
         logical :: done(lam)
         kind = 0
         if (nsur >= 1.1_wp * sur_np(1)) kind = 1
         if (nsur >= 1.1_wp * sur_np(2) .and. sur_np(2) <= 1000) kind = 2
         np = sur_np(kind)
         allocate (coef(np), phi(np))
         call sur_fit(kind, coef)
         do k2 = 1, lam
            call sur_features(xs(:, k2), kind, phi); pred(k2) = dot_product(coef, phi)
         end do
         call sort_index(pred, ordr)
         done = .false.
         kk = min(lam, max(o%foc_sur_kmin, ceiling(0.1_wp * lam), o%foc_sur_round))
         do
            do i2 = 1, kk
               k2 = ordr(i2)
               if (done(k2)) cycle
               ft = ev%f(xs(:, k2)); fs(k2) = ft; done(k2) = .true.
               call sur_push(xs(:, k2), ft)
               if (ev%stop_flag) return
            end do
            if (kk >= lam) exit
            nev = count(done); nval = min(nsur, nev + 10)
            allocate (va(nval), vb(nval))
            do i2 = 1, nval
               jr = sur_recent(i2)
               call sur_features(sx_(:, jr), kind, phi); va(i2) = dot_product(coef, phi); vb(i2) = sf_(jr)
            end do
            cc = 0; dd = 0
            do i2 = 1, nval
               do j3 = i2 + 1, nval
                  t = sign(one, va(i2) - va(j3)) * sign(one, vb(i2) - vb(j3))
                  if (va(i2) == va(j3) .or. vb(i2) == vb(j3)) t = zero
                  if (t > zero) cc = cc + 1
                  if (t < zero) dd = dd + 1
               end do
            end do
            deallocate (va, vb)
            tau = one
            if (cc + dd > 0) tau = real(cc - dd, wp) / real(cc + dd, wp)
            if (tau >= o%foc_sur_tau) exit
            kk = min(lam, kk + max(1, ceiling(half * kk), o%foc_sur_round))
            call sur_fit(kind, coef)
            do k2 = 1, lam
               call sur_features(xs(:, k2), kind, phi); pred(k2) = dot_product(coef, phi)
            end do
            call sort_index(pred, idr); i2 = 0
            do k2 = 1, lam
               if (done(k2)) then
                  i2 = i2 + 1; ordr(i2) = k2
               end if
            end do
            do k2 = 1, lam
               if (.not. done(idr(k2))) then
                  i2 = i2 + 1; ordr(i2) = idr(k2)
               end if
            end do
         end do
         if (.not. all(done)) then                     ! model values, ranked after
            nev = count(done)
            allocate (rr(nev)); i2 = 0
            do k2 = 1, lam
               if (done(k2)) then
                  i2 = i2 + 1; rr(i2) = fs(k2) - pred(k2)
               end if
            end do
            call sort_index(rr, idr(1:nev))
            if (mod(nev, 2) == 1) then
               med = rr(idr((nev + 1) / 2))
            else
               med = half * (rr(idr(nev / 2)) + rr(idr(nev / 2 + 1)))
            end if
            worst = maxval(fs, mask=done)
            do k2 = 1, lam
               if (.not. done(k2)) fs(k2) = max(pred(k2) + med, worst + 1.0e-12_wp * (one + abs(worst)))
            end do
         end if
      end subroutine sur_eval
   end subroutine foctopus_enhanced

   !> Terminal resolution: the classic run stopped when the box had contracted
   !> by nsamp**(zmax/n); the same floor is applied to the continuous scale.
   !> Terminal search scale.
   !>
   !> The classic algorithm stops when the box has contracted by
   !> lambda**(zmax/n), and this port inherited that.  The exponent carries a
   !> 1/n, so a fixed zmax means the floor rises with dimension: for a batch of
   !> 16 it is 5e-7 of the box at n=30 and 4e-3 at n=65.  Above roughly n=55
   !> that is coarser than the accuracy a caller is likely to ask for, and the
   !> run then stops short of the target for a reason that has nothing to do
   !> with the search -- measured on Ackley, 20/20 successes at n=55 and 0/20
   !> at n=65, with every run stalled at 3.3e-8 against a 1e-8 target.
   !>
   !> The default is now a fixed fraction of the initial spread, independent of
   !> n.  foc_legacy_floor restores the old rule for reproducing earlier runs.
   pure real(wp) function scale_floor(sig0, lam, n, o)
      real(wp), intent(in) :: sig0(:)
      integer, intent(in)  :: lam, n
      type(opt_options), intent(in) :: o
      if (o%foc_legacy_floor) then
         scale_floor = maxval(sig0) * real(max(lam, 2), wp)**(-real(o%foc_zmax, wp) / real(n, wp))
      else
         scale_floor = maxval(sig0) * o%foc_tol_scale
      end if
      scale_floor = max(scale_floor, 1.0e-16_wp * max(one, maxval(sig0)))
   end function scale_floor

   !> Solve L w = b for lower-triangular L (only the lower part of L is valid).
   pure subroutine forward_solve(l, b, w)
      real(wp), intent(in)  :: l(:, :), b(:)
      real(wp), intent(out) :: w(:)
      integer :: i
      do i = 1, size(b)
         w(i) = (b(i) - dot_product(l(i, 1:i - 1), w(1:i - 1))) / l(i, i)
      end do
   end subroutine forward_solve

end module fitpar_global_foctopus
